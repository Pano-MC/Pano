function _page($$payload) {
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BVOeF0bZ.js.map
