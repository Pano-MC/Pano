import { a7 as slot, a6 as bind_props, t as pop, p as push } from './index2-BSgs6Xxn.js';
import { M as MainLayout } from './0-otK6z0N6.js';
import './runtime-BGFZ81nX.js';
import './ErrorAlert-CWi-wjrX.js';
import './client-DcSItIJ-.js';
import './variables-CdsVAjOE.js';
import './attributes-BEm38Kz9.js';
import './ToastContainer-DLmocSoA.js';
import './language.util-BLtc8Hqp.js';
import './index3-DyoisQP2.js';

function _layout($$payload, $$props) {
  push();
  let data = $$props["data"];
  MainLayout($$payload, {
    stepInfo: data.stepInfo,
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {});
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { data });
  pop();
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-D62qiV7E.js.map
