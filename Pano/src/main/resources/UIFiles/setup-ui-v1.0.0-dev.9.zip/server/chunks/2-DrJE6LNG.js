const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-vUj0rFU1.js')).default;
const imports = ["_app/immutable/nodes/2.BcuVe7jx.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/IDhAg-ze.js","_app/immutable/chunks/7jf5PQtN.js","_app/immutable/chunks/DdzATYwP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-DrJE6LNG.js.map
