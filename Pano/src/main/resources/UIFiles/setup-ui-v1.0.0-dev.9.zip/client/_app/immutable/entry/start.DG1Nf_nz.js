import{a as t}from"../chunks/7jf5PQtN.js";export{t as start};
