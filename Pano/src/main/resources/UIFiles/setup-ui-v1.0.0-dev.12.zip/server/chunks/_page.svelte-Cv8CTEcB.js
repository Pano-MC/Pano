import { a6 as bind_props, t as pop, aa as ensure_array_like, a8 as store_get, a9 as unsubscribe_stores, p as push, ab as stringify } from './index2-BSgs6Xxn.js';
import { e as escape_html } from './client-DcSItIJ-.js';
import { a as attr } from './attributes-BEm38Kz9.js';
import { L as Languages, c as currentLanguage, l as languageLoading } from './language.util-BUy5RBbb.js';
import { $ as $format } from './runtime-BGFZ81nX.js';

function Beginning($$payload, $$props) {
  push();
  var $$store_subs;
  let disabled;
  let stepInfo = $$props["stepInfo"];
  disabled = !!stepInfo.error;
  const each_array = ensure_array_like(Object.keys(store_get($$store_subs ??= {}, "$Languages", Languages)));
  $$payload.out += `<div${attr("class", [disabled ? "opacity-50" : ""].filter(Boolean).join(" "))}><div class="animate__animated animate__slideInUp"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("welcome-title"))}</h4> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("welcome-description"))}</p></div> <ul class="list-group mb-3"><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let language = each_array[index];
    $$payload.out += `<li class="list-group-item"><input class="form-check-input me-1" type="radio" name="langSelectionRadio" value=""${attr("id", `lang${stringify(language)}Radio`)}${attr("aria-checked", store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage) === store_get($$store_subs ??= {}, "$Languages", Languages)[language])}${attr("checked", store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage) === store_get($$store_subs ??= {}, "$Languages", Languages)[language], true)}${attr("disabled", store_get($$store_subs ??= {}, "$languageLoading", languageLoading), true)}> <label class="form-check-label"${attr("for", `lang${stringify(language)}Radio`)}>${escape_html(store_get($$store_subs ??= {}, "$Languages", Languages)[language].name)}</label></li>`;
  }
  $$payload.out += `<!--]--></ul> <div class="row justify-content-end"><div class="col-6"><div class="animate__animated animate__zoomIn"><button${attr("class", `btn btn-secondary w-100 ${stringify([disabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", disabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("start-button"))}</button></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { stepInfo });
  pop();
}
function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  Beginning($$payload, { stepInfo: data.stepInfo });
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cv8CTEcB.js.map
