const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cv8CTEcB.js')).default;
const imports = ["_app/immutable/nodes/2.DaBUOsMl.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/ChbjmrqQ.js","_app/immutable/chunks/CIb4a6eU.js","_app/immutable/chunks/B1hgWaGM.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-BGl57g5Z.js.map
