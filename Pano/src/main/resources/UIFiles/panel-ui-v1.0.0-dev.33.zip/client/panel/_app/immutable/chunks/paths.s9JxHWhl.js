var s;const e=((s=globalThis.__sveltekit_oonl4h)==null?void 0:s.base)??"/panel";var a;const l=((a=globalThis.__sveltekit_oonl4h)==null?void 0:a.assets)??e;export{l as a,e as b};
