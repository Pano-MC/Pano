import{b as a}from"../chunks/entry.ctKUEvpQ.js";export{a as start};
