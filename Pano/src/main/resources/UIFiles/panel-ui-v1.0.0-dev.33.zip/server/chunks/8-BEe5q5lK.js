const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CfyWTmuf.js')).default;
const imports = ["_app/immutable/nodes/8.Dm4GmQBZ.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.DqEd6fBr.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/stores.tFMcbqsI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-BEe5q5lK.js.map
