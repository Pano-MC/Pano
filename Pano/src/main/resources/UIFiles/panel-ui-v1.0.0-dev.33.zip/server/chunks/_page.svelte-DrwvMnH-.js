import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { S as ServerMonitoring } from './30-BbAodGo6.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(ServerMonitoring, "ServerMonitoring").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DrwvMnH-.js.map
