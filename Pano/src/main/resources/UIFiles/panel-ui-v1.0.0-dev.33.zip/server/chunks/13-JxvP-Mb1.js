import { l as load } from './Addons-BnP7WxB_.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardFilters-CshGiVuB.js';
import './NoContent-Cd8O1sR9.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-B7mn5Z0Z.js')).default;
const universal_id = "src/routes/addons/+page.js";
const imports = ["_app/immutable/nodes/13.CRyYWD8r.js","_app/immutable/chunks/Addons.5zNJtL8u.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.BcLP9wjQ.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/api.util.DDsI6mPX.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/tooltip.util.TBv8o-3d.js","_app/immutable/chunks/ToastContainer.CV1NjUOz.js","_app/immutable/chunks/runtime.DqEd6fBr.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.CjMNuYL-.js","_app/immutable/chunks/CardFilters.DPYRZmdH.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.CeqVQ04J.js","_app/immutable/chunks/NoContent.D6CyBr9v.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=13-JxvP-Mb1.js.map
