import { c as create_ssr_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user, selectedServer } = parentData;
  if (!hasPermission(Permissions.MANAGE_SERVERS, user)) {
    throw redirect(302, "/");
  }
  if (!selectedServer) {
    throw redirect(302, "/");
  }
  return parentData;
}
const ServerLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-q4Yx-D2O.js')).default;
const universal_id = "src/routes/server/+layout.js";
const imports = ["_app/immutable/nodes/7.DXjX0lSB.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.C_nZSOWe.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/index.BcLP9wjQ.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ServerLayout as S, _7 as _ };
//# sourceMappingURL=7-DofEy2Q5.js.map
