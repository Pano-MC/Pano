const index = 45;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DYnCqbzh.js')).default;
const imports = ["_app/immutable/nodes/45.CvhIOdQD.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/paths.s9JxHWhl.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=45-BT0d6HL4.js.map
