import { l as load$1, M as Modes } from './PostEditor-Bfzr3GZ6.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CNgXF1Vs.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';
import './paths-C6LjEmZF.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 28;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DJiP1lES.js')).default;
const universal_id = "src/routes/posts/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/28.DoTiBJMn.js","_app/immutable/chunks/PostEditor.DXI1HxcB.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.BcLP9wjQ.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/api.util.DDsI6mPX.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/runtime.DqEd6fBr.js","_app/immutable/chunks/tooltip.util.TBv8o-3d.js","_app/immutable/chunks/ConfirmDeletePostModal.LokS7a0b.js","_app/immutable/chunks/ToastContainer.CV1NjUOz.js","_app/immutable/chunks/AddEditPostCategoryModal.DX3lm1h6.js","_app/immutable/chunks/Editor.Daro0T7f.js","_app/immutable/chunks/NoContent.D6CyBr9v.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardMenuItem.DaXHUHHY.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=28-DU-Zg2XZ.js.map
