import { c as create_ssr_component, a as subscribe, e as escape } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { p as page } from './stores-BDx4Az-R.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_PLATFORM_SETTINGS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
function matching(path, pathName, startsWith = false) {
  return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
}
const SettingsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  let $_, $$unsubscribe__;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_page();
  $$unsubscribe__();
  return ` <div class="container vstack gap-3"><div class="row justify-content-around"><div class="col-auto"> <div class="nav nav-pills d-flex flex-row justify-content-center"><a class="${[
    "nav-item nav-link",
    matching($page.url.pathname, base + "/settings") ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/settings"}">${escape($_("components.settings-layout.website"))}</a> <a class="${[
    "nav-item nav-link",
    matching($page.url.pathname, base + "/settings/platform", true) ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/settings/platform"}">${escape($_("components.settings-layout.platform"))}</a> <a class="${[
    "nav-item nav-link position-relative",
    matching($page.url.pathname, base + "/settings/updates", true) ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/settings/updates"}">${escape($_("components.settings-layout.updates"))} <span class="position-absolute top-0 start-100 translate-middle p-2 bg-danger rounded-circle" data-svelte-h="svelte-1o2527k"></span></a> <a class="${[
    "nav-item nav-link",
    matching($page.url.pathname, base + "/settings/about", true) ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/settings/about"}">${escape($_("components.settings-layout.about"))}</a></div></div></div> ${slots.default ? slots.default({}) : ``} </div>`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 9;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DtEalPpU.js')).default;
const universal_id = "src/routes/settings/+layout.js";
const imports = ["_app/immutable/nodes/9.BVIrjhd5.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.C_nZSOWe.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/index.BcLP9wjQ.js","_app/immutable/chunks/runtime.DqEd6fBr.js"];
const stylesheets = [];
const fonts = [];

var _9 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { SettingsLayout as S, _9 as _ };
//# sourceMappingURL=9-C4fdBK9n.js.map
