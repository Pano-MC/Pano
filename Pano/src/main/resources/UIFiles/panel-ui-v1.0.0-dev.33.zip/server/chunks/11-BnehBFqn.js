import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_VIEW, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const ViewLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `  <article class="container"> <nav>${validate_component(CardMenu, "CardMenu").$$render($$result, {}, {}, {
    default: () => {
      return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view" }, {}, {
        default: () => {
          return `Temalar`;
        }
      })} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view/theme-options" }, {}, {
        default: () => {
          return `Tema Seçenekleri`;
        }
      })}`;
    }
  })}</nav> ${slots.default ? slots.default({}) : ``} </article>`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-9Mx4MrSD.js')).default;
const universal_id = "src/routes/view/+layout.js";
const imports = ["_app/immutable/nodes/11.guukb6ig.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.C_nZSOWe.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/index.BcLP9wjQ.js","_app/immutable/chunks/CardMenuItem.DaXHUHHY.js"];
const stylesheets = [];
const fonts = [];

var _11 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ViewLayout as V, _11 as _ };
//# sourceMappingURL=11-BnehBFqn.js.map
