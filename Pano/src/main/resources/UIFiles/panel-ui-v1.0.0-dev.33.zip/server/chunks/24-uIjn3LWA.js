import { l as load$1, M as Modes } from './PermissionGroupDetail-BOEtqrZx.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 24;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DDA_vum0.js')).default;
const universal_id = "src/routes/players/perm-groups/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/24.BsMXY_Wg.js","_app/immutable/chunks/PermissionGroupDetail.B1UJ9lZ4.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/index.BcLP9wjQ.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/api.util.DDsI6mPX.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/runtime.DqEd6fBr.js","_app/immutable/chunks/tooltip.util.TBv8o-3d.js","_app/immutable/chunks/ToastContainer.CV1NjUOz.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=24-uIjn3LWA.js.map
