import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, d as add_attribute } from './ssr-ffuobYCI.js';
import { b as ApiUtil, c as PANO_WEBSITE_URL } from './api.util-Cb5EDErE.js';
import { $ as $format } from './runtime-DMBi37QM.js';

async function load(event) {
  const { parent } = event;
  await parent();
  return await ApiUtil.get({
    path: "/api/panel/settings/about",
    request: event
  });
}
function getDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname;
  } catch (e) {
    return url.replace(/^https?:\/\//, "");
  }
}
const About = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.settings.about.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <div class="card"><div class="card-body"><h5 class="card-title" data-svelte-h="svelte-1apllct">Pano Platform Info</h5> <form class="animate__animated animate__fadeIn"><div class="row"><label class="col-md-6 col-form-label" for="panoVersion">${escape($_("pages.settings.about.version"))}</label> <div class="col-md-6 col-form-label"><span aria-describedby="panoVersion" id="panoVersion">${escape(data.platformVersion)}</span></div></div> <div class="row"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.release"))}</label> <div class="col-md-6 col-form-label"><span aria-describedby="panoRelease" id="panoRelease">${escape(data.platformStage)}</span></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.website"))}</label> <div class="col-md-6 col-form-label"><a aria-describedby="panoWebsite"${add_attribute("href", PANO_WEBSITE_URL, 0)} id="panoWebsite" target="_blank">${escape(getDomain(PANO_WEBSITE_URL))} <i class="fa-solid fa-up-right-from-square ms-2"></i></a></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.discord"))}</label> <div class="col-md-6 col-form-label"><a aria-describedby="panoWebsite" href="${escape(PANO_WEBSITE_URL, true) + "/discord"}" id="panoWebsite" target="_blank">${escape(getDomain(PANO_WEBSITE_URL))}/discord <i class="fa-solid fa-up-right-from-square ms-2"></i></a></div></div></form></div></div> <div class="card"><div class="card-body animate__animated animate__fadeIn"><h5 class="card-title animate__animated animate__heartBeat animate__slower d-inline-block">${escape($_("pages.settings.about.open-source-licenses"))} ❤️</h5>  <details data-svelte-h="svelte-16hhkyh"><summary class="h6 text-primary">Title</summary> <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia quisquam
        assumenda dolor eligendi fugit, architecto ab vero possimus minus
        consequatur delectus aut quam voluptatem debitis ullam ea voluptate
        inventore rem!</p></details></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 35;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Da-KG6L3.js')).default;
const universal_id = "src/routes/settings/about/+page.js";
const imports = ["_app/immutable/nodes/35.DQjzZJOS.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/api.util.DDsI6mPX.js","_app/immutable/chunks/stores.tFMcbqsI.js","_app/immutable/chunks/entry.ctKUEvpQ.js","_app/immutable/chunks/paths.s9JxHWhl.js","_app/immutable/chunks/runtime.DqEd6fBr.js"];
const stylesheets = [];
const fonts = [];

var _35 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { About as A, _35 as _ };
//# sourceMappingURL=35-Dmjq2qNH.js.map
