import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { S as SiteSettings } from './34-C0sPzTlM.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-Cb5EDErE.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(SiteSettings, "SiteSettings").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-CPPazbmj.js.map
