const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DuvkOSaP.js')).default;
const imports = ["_app/immutable/nodes/1.CV_D-H48.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/stores.CukszKVv.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DS77eadk.js.map
