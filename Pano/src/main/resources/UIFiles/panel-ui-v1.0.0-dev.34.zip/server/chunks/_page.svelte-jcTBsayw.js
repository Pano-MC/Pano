import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { A as Addons } from './Addons-BnP7WxB_.js';
import './index-DzcLzHBX.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardFilters-CshGiVuB.js';
import './NoContent-Cd8O1sR9.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Addons, "Addons").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-jcTBsayw.js.map
