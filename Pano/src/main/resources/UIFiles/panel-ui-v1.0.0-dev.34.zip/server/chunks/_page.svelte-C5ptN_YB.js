import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';

const GameIntegrationSettings = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Oyun Entegrasyon Ayarları");
  return `<div class="card animate__animated animate__fadeIn" data-svelte-h="svelte-1kyusic"><div class="card-body"><div class="row"><label class="col-md-4 col-form-label" for="loginIntergration"><p>Giriş Entegrasyonu</p> <small class="text-muted">Description of login integration here.</small></label> <div class="col col-form-label"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="loginIntergration"></div></div></div></div> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(GameIntegrationSettings, "GameIntegrationSettings").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-C5ptN_YB.js.map
