import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';

const Tools = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Araçlar");
  return `<div class="container" data-svelte-h="svelte-vvdzyv">Tools page!</div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Tools, "Tools").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BfVhfdQ0.js.map
