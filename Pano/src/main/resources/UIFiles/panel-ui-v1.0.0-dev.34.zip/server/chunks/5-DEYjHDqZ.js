import { c as create_ssr_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_PERMISSION_GROUPS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const PermGroupsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-cwGmV3M_.js')).default;
const universal_id = "src/routes/players/perm-groups/+layout.js";
const imports = ["_app/immutable/nodes/5.ChSW3kqT.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.BqcupRKq.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/index.CvLV2jqT.js"];
const stylesheets = [];
const fonts = [];

var _5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { PermGroupsLayout as P, _5 as _ };
//# sourceMappingURL=5-DEYjHDqZ.js.map
