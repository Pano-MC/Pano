import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';

const ActivityLogs = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `Activity logs etc....`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ActivityLogs, "ActivityLogs").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-B5VohBUn.js.map
