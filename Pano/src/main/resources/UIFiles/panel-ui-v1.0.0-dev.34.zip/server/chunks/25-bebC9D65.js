import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each, i as createEventDispatcher, b as add_classes, d as add_attribute } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-Cb5EDErE.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination--ODwq86l.js';
import './ToastContainer-D6cKqDaa.js';
import { D as Date_1 } from './Date-CO7kc4Oc.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-npnb-NGS.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';

const PostRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { post } = $$props;
  let { pageType } = $$props;
  let { buttonsLoading } = $$props;
  createEventDispatcher();
  if ($$props.post === void 0 && $$bindings.post && post !== void 0) $$bindings.post(post);
  if ($$props.pageType === void 0 && $$bindings.pageType && pageType !== void 0) $$bindings.pageType(pageType);
  if ($$props.buttonsLoading === void 0 && $$bindings.buttonsLoading && buttonsLoading !== void 0) $$bindings.buttonsLoading(buttonsLoading);
  $$unsubscribe__();
  return `<tr${add_classes((post.selected ? "table-primary" : "").trim())}><th scope="row"><div class="dropdown position-static"><a role="button" href="javascript:void(0);" class="btn btn-sm btn-link" data-bs-toggle="dropdown"${add_attribute("title", $_("components.post-row.actions"), 0)}><span class="fas fa-ellipsis-v"></span></a> <div class="dropdown-menu dropdown-menu-start animate__animated animate__fadeIn"><a class="dropdown-item" target="_blank" href="${escape("", true) + "/preview/post/" + escape(post.id, true)}"><i class="fas fa-eye me-2"></i> ${escape($_("components.post-row.view"))}</a> ${pageType !== PageTypes.DRAFT ? `<a class="${["dropdown-item", buttonsLoading ? "disabled" : ""].join(" ").trim()}" href="javascript:void(0);"><span><i class="fa-solid fa-box-archive me-2"></i> ${escape($_("components.post-row.move-to-draft"))}</span></a>` : ``} ${pageType !== PageTypes.PUBLISHED ? `<a class="${["dropdown-item", buttonsLoading ? "disabled" : ""].join(" ").trim()}" href="javascript:void(0);"><span><i class="fas fa-globe-americas me-2"></i> ${escape($_("components.post-row.publish"))}</span></a>` : ``} <a class="dropdown-item link-danger" href="javascript:void(0);"><i class="fas fa-trash me-2"></i> ${pageType !== PageTypes.TRASH ? `${escape($_("components.post-row.move-to-trash"))}` : `${escape($_("components.post-row.delete"))}`}</a></div></div></th> <td class="align-middle text-nowrap"><a${add_attribute("href", base + "/posts/detail/" + post.id, 0)}${add_attribute("title", $_("components.post-row.edit"), 0)}>${escape(post.title)}</a></td> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.post-row.filter"), 0)} href="${escape(base, true) + "/posts?categoryUrl=" + escape(post.category.url, true)}">${escape(post.category.title === "-" ? $_("components.post-row.no-category") : post.category.title)}</a></td> <td class="align-middle text-nowrap">${escape(post.views)}</td> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/players/detail/" + escape(post.writer.username, true)}"><img${add_attribute("alt", post.writer.username, 0)} class="rounded-circle" height="32" src="${"https://minotar.net/avatar/" + escape(post.writer.username, true)}" width="32"></a></td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: post.date }, {}, {})}</td> </tr>`;
});
const PageTypes = Object.freeze({
  PUBLISHED: "PUBLISHED",
  DRAFT: "DRAFT",
  TRASH: "TRASH"
});
const DefaultPageType = PageTypes.PUBLISHED;
async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const page = searchParams.get("page") || 1;
  const categoryUrl = searchParams.get("categoryUrl");
  const pageType = searchParams.get("pageType") || DefaultPageType;
  if (!Object.values(PageTypes).includes(pageType)) {
    throw error(404, "PAGE_NOT_FOUND");
  }
  const queryParams = buildQueryParams({ page, pageType, categoryUrl });
  const body = await ApiUtil.get({
    path: `/api/panel/posts` + queryParams,
    request: event
  }).catch((err) => {
    throw error(500, err);
  });
  if (body.error === "PAGE_NOT_FOUND") {
    throw error(404, body.error);
  }
  if (body.error) {
    throw error(500, body.error);
  }
  body.page = parseInt(page);
  body.pageType = pageType;
  body.categoryUrl = categoryUrl;
  return body;
}
const Posts = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  let buttonsLoading = false;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set(data.categoryUrl ? $_("pages.posts.category-posts-title", {
        values: {
          category: (data.category?.title || "-") === "-" ? $_("pages.posts.no-category") : data.category?.title || "-"
        }
      }) : $_("pages.posts.title", {
        values: {
          pageType: data.pageType === PageTypes.PUBLISHED ? $_("pages.posts.published") + " " : data.pageType === PageTypes.DRAFT ? $_("pages.posts.draft") + " " : data.pageType === PageTypes.TRASH ? $_("pages.posts.trash") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div slot="right">${!data.categoryUrl ? `<a href="${escape(base, true) + "/posts/create-post"}" class="btn btn-secondary" role="button"><i class="fas fa-plus me-2"></i> ${escape($_("pages.posts.create-post-button"))}</a>` : ``}</div>`;
    },
    middle: () => {
      return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
        default: () => {
          return `${!data.categoryUrl ? `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/posts", startsWith: true }, {}, {
            default: () => {
              return `${escape($_("pages.post-categories.posts"))}`;
            }
          })} ${validate_component(CardMenuItem, "CardMenuItem").$$render(
            $$result,
            {
              href: "/posts/categories",
              startsWith: true
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.post-categories-button"))}`;
              }
            }
          )}` : ``}`;
        }
      })}`;
    },
    left: () => {
      return `<div slot="left">${data.categoryUrl ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/posts"}"><i class="fas fa-arrow-left ms-2"></i> ${escape($_("buttons.posts"))}</a>` : ``}</div>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${!data.categoryUrl ? `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts",
              active: data.pageType === PageTypes.PUBLISHED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.published"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts?pageType=DRAFT",
              active: data.pageType === PageTypes.DRAFT
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.draft"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts?pageType=TRASH",
              active: data.pageType === PageTypes.TRASH
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.trash"))}`;
              }
            }
          )}` : ``}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.posts.table-title", {
        values: {
          postCount: data.postCount,
          pageType: data.pageType === PageTypes.PUBLISHED ? $_("pages.posts.published") + " " : data.pageType === PageTypes.DRAFT ? $_("pages.posts.draft") + " " : data.pageType === PageTypes.BANNED ? $_("pages.posts.banned") + " " : ""
        }
      }))}</h5>`;
    }
  })}  ${data.postCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th> <th class="align-middle" scope="col">${escape($_("pages.posts.table.title"))}</th> <th scope="col" class="${["align-middle", data.categoryUrl ? "table-primary" : ""].join(" ").trim()}">${escape($_("pages.posts.table.category"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.views"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.author"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.last-update"))}</th></tr></thead> <tbody>${each(data.posts, (post, index) => {
    return `${validate_component(PostRow, "PostRow").$$render(
      $$result,
      {
        post,
        pageType: data.pageType,
        buttonsLoading
      },
      {},
      {}
    )}`;
  })}</tbody></table></div>`}  <div class="d-flex justify-content-sm-start justify-content-center">${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div> </div></div> </article>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 25;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DVgXTdPd.js')).default;
const universal_id = "src/routes/posts/+page.js";
const imports = ["_app/immutable/nodes/25.BeA5nEN_.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.CvLV2jqT.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/api.util.DjyA6Qtr.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/Pagination.DlIpNFey.js","_app/immutable/chunks/ConfirmDeletePostModal.VdD2noem.js","_app/immutable/chunks/ToastContainer.DJmHgWMZ.js","_app/immutable/chunks/Date.BBtJyksR.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.D1XPrI3Y.js","_app/immutable/chunks/language.util.Bm0GVGlQ.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/NoContent.BUfNilqv.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.CjMNuYL-.js","_app/immutable/chunks/CardMenuItem.BOhVMVhc.js","_app/immutable/chunks/CardFilters.D_NieZz5.js"];
const stylesheets = [];
const fonts = [];

var _25 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Posts as P, _25 as _ };
//# sourceMappingURL=25-bebC9D65.js.map
