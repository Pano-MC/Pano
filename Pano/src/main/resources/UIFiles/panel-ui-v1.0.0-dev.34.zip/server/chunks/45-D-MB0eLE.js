const index = 45;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DYnCqbzh.js')).default;
const imports = ["_app/immutable/nodes/45.tCVtPBnc.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/paths.P3ueEoWl.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=45-D-MB0eLE.js.map
