const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BaLBcg6l.js')).default;
const imports = ["_app/immutable/nodes/16.BAgCBwDy.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=16-j8KcyNjX.js.map
