import { l as load$1, M as Modes } from './PostEditor-Bfzr3GZ6.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CNgXF1Vs.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';
import './paths-C6LjEmZF.js';

async function load(params) {
  return load$1(params, Modes.CREATE);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 27;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CfSl19bs.js')).default;
const universal_id = "src/routes/posts/create-post/+page.js";
const imports = ["_app/immutable/nodes/27.d5v52tqX.js","_app/immutable/chunks/PostEditor.B-OGxKEk.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.CvLV2jqT.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/api.util.DjyA6Qtr.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/tooltip.util.D1XPrI3Y.js","_app/immutable/chunks/ConfirmDeletePostModal.VdD2noem.js","_app/immutable/chunks/ToastContainer.DJmHgWMZ.js","_app/immutable/chunks/AddEditPostCategoryModal.Bse3iWKv.js","_app/immutable/chunks/Editor.C-Ebu8pW.js","_app/immutable/chunks/NoContent.BUfNilqv.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardMenuItem.BOhVMVhc.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=27-D3yfzzzW.js.map
