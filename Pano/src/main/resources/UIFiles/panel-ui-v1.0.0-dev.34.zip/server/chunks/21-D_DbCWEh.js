import { c as create_ssr_component, a as subscribe, f as getContext, o as onDestroy, e as escape, d as add_attribute, v as validate_component, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-Cb5EDErE.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { c as currentLanguage } from './language.util-2VlJt8zV.js';
import './ToastContainer-D6cKqDaa.js';
import { T as TicketStatusBadge } from './TicketStatusBadge-BiE81nbk.js';
import { D as Date_1 } from './Date-CO7kc4Oc.js';
import { P as Pagination } from './Pagination--ODwq86l.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PlayerPermissionBadge } from './PlayerPermissionBadge-DYILRjQ1.js';

async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const username = event.params.username;
  const page = searchParams.get("page") || 1;
  const queryParams = buildQueryParams({ page });
  const body = await ApiUtil.get({
    path: `/api/panel/players/${username}` + queryParams,
    request: event
  });
  if (body.error) {
    if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
      throw error(404, body.error);
    }
    throw error(500, body.error);
  }
  body.username = username;
  body.page = parseInt(page);
  return body;
}
const PlayerDetail = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let isOnline;
  let $_, $$unsubscribe__;
  let $user, $$unsubscribe_user;
  let $siteInfo, $$unsubscribe_siteInfo;
  let $$unsubscribe_currentLanguage;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_currentLanguage = subscribe(currentLanguage, (value) => value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  const user = getContext("user");
  $$unsubscribe_user = subscribe(user, (value) => $user = value);
  const siteInfo = getContext("siteInfo");
  $$unsubscribe_siteInfo = subscribe(siteInfo, (value) => $siteInfo = value);
  pageTitle.set(data.username);
  let interval;
  onDestroy(() => {
    clearInterval(interval);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  isOnline = data.player.lastActivityTime > Date.now() - 5 * 60 * 1e3 || data.player.inGame;
  $$unsubscribe__();
  $$unsubscribe_user();
  $$unsubscribe_siteInfo();
  $$unsubscribe_currentLanguage();
  return ` <div class="container"> <div class="row justify-content-between mb-3 animate__animated animate__slideInUp"><div class="col-auto">${hasPermission(Permissions.MANAGE_PLAYERS) ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players"}"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.player-detail.players"))}</a>` : ``}</div> <div class="col-auto">${hasPermission(Permissions.MANAGE_PLAYERS) ? `<button class="${[
    "btn btn-link link-danger",
    $user.username === data.player.username || data.player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" data-svelte-h="svelte-1r0wysy"><i class="fas fa-trash"></i></button> ${data.player.isBanned ? `<button class="${[
    "btn btn-link link-danger",
    $user.username === data.player.username || data.player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" data-svelte-h="svelte-1l8as3s"><i class="fas fa-gavel"></i></button>` : `<button class="${[
    "btn btn-link link-danger",
    $user.username === data.player.username || data.player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" data-svelte-h="svelte-1basbm1"><i class="fas fa-gavel"></i></button>`} ${!data.player.isEmailVerified ? `<button class="${[
    "btn btn-link",
    $user.username === data.player.username || data.player.permissionGroup === "admin" && !$user.admin || !$siteInfo.emailEnabled ? "disabled" : ""
  ].join(" ").trim()}" data-svelte-h="svelte-15fusv1"><i class="fas fa-envelope"></i></button>` : ``} <button class="${[
    "btn btn-link",
    $user.username === data.player.username || data.player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" data-svelte-h="svelte-1inaq1u"><i class="fas fa-user-circle"></i></button>` : ``} ${hasPermission(Permissions.MANAGE_PLAYERS) || $user.username === data.player.username ? `<button class="${[
    "btn btn-primary",
    data.player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}"><i class="fas fa-pencil-alt me-2"></i> ${escape($_("pages.player-detail.edit"))}</button>` : ``}</div></div> <div class="row g-3"><div class="col-lg-3"><div class="card"><div class="card-body d-flex flex-column justify-content-center align-items-center"><img${add_attribute("alt", data.player.username, 0)} class="${[
    "mb-3 rounded-circle animate__animated animate__zoomIn",
    (isOnline ? "border" : "") + " " + (isOnline ? "border-5" : "") + " " + (isOnline ? "border-success" : "")
  ].join(" ").trim()}" width="128" height="128" src="${"https://minotar.net/avatar/" + escape(data.player.username, true)}"> <h3 class="card-title">${escape(data.player.username)}</h3> <h6 class="text-muted">${escape(data.player.email)}</h6> ${data.player.isBanned ? `<div class="text-danger">${escape($_("pages.player-detail.banned"))}</div>` : `${validate_component(PlayerPermissionBadge, "PlayerPermissionBadge").$$render(
    $$result,
    {
      permissionGroup: data.player.permissionGroup
    },
    {},
    {}
  )}`}</div></div></div> <div class="col-lg-9 vstack gap-3">${hasPermission(Permissions.MANAGE_TICKETS) ? ` <div class="card"><div class="card-body"><h5 class="card-title">${escape($_("pages.player-detail.last-tickets"))}</h5> ${data.ticketCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : `<div class="table-responsive"><table class="table table-hover mb-0">${each(data.tickets, (ticket, index) => {
    return `<tbody><tr><td class="align-middle text-nowrap"><a href="${escape(base, true) + "/tickets/detail/" + escape(ticket.id, true)}"${add_attribute("title", $_("pages.player-detail.view"), 0)}>#${escape(ticket.id)} ${escape(ticket.title)}</a></td> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("pages.player-detail.filter"), 0)} href="${escape(base, true) + "/tickets?categoryUrl=" + escape(ticket.category.url, true)}">${escape(ticket.category.title === "-" ? $_("pages.player-detail.no-category") : ticket.category.title)} </a></td> <td class="align-middle text-nowrap">${validate_component(TicketStatusBadge, "TicketStatusBadge").$$render($$result, { status: ticket.status }, {}, {})}</td> <td class="align-middle text-nowrap"><span>${validate_component(Date_1, "DateComponent").$$render($$result, { time: ticket.lastUpdate }, {}, {})}</span></td></tr> </tbody>`;
  })}</table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.ticketTotalPage
    },
    {},
    {}
  )}</div></div>` : ``}  <div class="card"><div class="card-body"><h5 class="card-title">${escape($_("pages.player-detail.statistics"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape($_("pages.player-detail.email"))}</td> <td>${data.player.isEmailVerified ? `${escape($_("pages.player-detail.email-verified"))}` : `${escape($_("pages.player-detail.email-not-verified"))}`}</td></tr> <tr><td>${escape($_("pages.player-detail.last-entrance"))}</td> <td>${validate_component(Date_1, "DateComponent").$$render($$result, { time: data.player.lastLoginDate }, {}, {})}</td></tr> <tr><td>${escape($_("pages.player-detail.register-date"))}</td> <td>${validate_component(Date_1, "DateComponent").$$render($$result, { time: data.player.registerDate }, {}, {})}</td></tr></tbody></table></div></div></div></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 21;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C0MQB9Rv.js')).default;
const universal_id = "src/routes/players/detail/[username]/+page.js";
const imports = ["_app/immutable/nodes/21.DyLkdmc2.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.CvLV2jqT.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/api.util.DjyA6Qtr.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.D1XPrI3Y.js","_app/immutable/chunks/auth.util.BqcupRKq.js","_app/immutable/chunks/language.util.Bm0GVGlQ.js","_app/immutable/chunks/UnbanPlayerModal.BxsmMMl4.js","_app/immutable/chunks/ToastContainer.DJmHgWMZ.js","_app/immutable/chunks/ConfirmDeletePlayerModal.DU6UcoZy.js","_app/immutable/chunks/TicketStatusBadge.Cqj_mLKv.js","_app/immutable/chunks/Date.BBtJyksR.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/Pagination.DlIpNFey.js","_app/immutable/chunks/NoContent.BUfNilqv.js","_app/immutable/chunks/PlayerPermissionBadge.Dd1iW-mB.js"];
const stylesheets = [];
const fonts = [];

var _21 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PlayerDetail as P, _21 as _ };
//# sourceMappingURL=21-D_DbCWEh.js.map
