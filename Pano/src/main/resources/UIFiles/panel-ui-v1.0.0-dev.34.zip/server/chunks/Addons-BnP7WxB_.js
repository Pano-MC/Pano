import { c as create_ssr_component, f as getContext, v as validate_component, e as escape, h as each, a as subscribe, d as add_attribute } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { d as buildQueryParams, b as ApiUtil, A as API_URL, c as PANO_WEBSITE_URL } from './api.util-Cb5EDErE.js';
import { b as base } from './paths-C6LjEmZF.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-npnb-NGS.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';
import { w as writable } from './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';

const dialogID = "addPluginModal";
const loading = writable(false);
const AddPluginModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $loading, $$unsubscribe_loading;
  $$unsubscribe_loading = subscribe(loading, (value) => $loading = value);
  $$unsubscribe_loading();
  return ` <div class="modal modal-xl fade"${add_attribute("id", dialogID, 0)} tabindex="-1" aria-hidden="true"><div class="modal-dialog"><div class="modal-content">${$loading ? `<div class="modal-body" data-svelte-h="svelte-79dvbl"><div class="text-center"><div class="spinner-border text-primary" role="status"></div></div></div>` : `<div class="modal-header"><h5 class="modal-title" id="exampleModalLabel" data-svelte-h="svelte-1aq6y8c">Add plugin</h5> <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div> <div class="modal-body" data-svelte-h="svelte-1q9yadn">test</div> <div class="modal-footer" data-svelte-h="svelte-8f3n87">Footer</div>`}</div></div> </div>`;
});
const PageTypes = Object.freeze({
  ALL: "ALL",
  ACTIVE: "ACTIVE",
  DISABLED: "DISABLED"
});
const DefaultPageType = PageTypes.ALL;
async function load(event, pageType = DefaultPageType) {
  const { parent } = event;
  await parent();
  pageType = pageType.toUpperCase();
  const queryParams = buildQueryParams({ status: pageType });
  const body = await ApiUtil.get({
    path: `/api/panel/plugins` + queryParams,
    request: event
  });
  if (body.error) {
    throw error(500, body);
  }
  body.pageType = pageType;
  return body;
}
const Addons = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Eklentiler");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(AddPluginModal, "AddPluginModal").$$render($$result, {}, {}, {})} <div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<a href="javascript:void(0);" class="btn btn-secondary ml-auto" role="button" slot="right" data-svelte-h="svelte-1ukweji"><i class="fas fa-plus me-2"></i>
      Eklenti Yükle</a>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="/addons/categories" slot="left" data-svelte-h="svelte-1b0mw40"><i class="fas fa-puzzle-piece me-2"></i>
      Eklenti Kategorileri</a>`;
    }
  })}  <div class="card"><div class="card-body vstack gap-3">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/addons/all",
              active: data.pageType === PageTypes.ALL
            },
            {},
            {
              default: () => {
                return `Tümü`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/addons/active",
              active: data.pageType === PageTypes.ACTIVE
            },
            {},
            {
              default: () => {
                return `Aktif`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/addons/disabled",
              active: data.pageType === PageTypes.DISABLED
            },
            {},
            {
              default: () => {
                return `Devre Dışı`;
              }
            }
          )}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape(data.plugins.length)} ${escape(data.pageType === PageTypes.ACTIVE ? "Aktif" : data.pageType === PageTypes.DISABLED ? "Devre Dışı" : "Yüklü")} Eklenti</h5>`;
    }
  })} <div class="row row-cols-xl-2 row-cols-1 g-3">${data.plugins.length === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ``} ${each(data.plugins, (plugin, index) => {
    return `<div class="${"col " + escape(plugin.status === "FAILED" && "animate__animated animate__shakeX animate__slower", true)}"> <div class="${"card border " + escape(plugin.status === "FAILED" && "border-danger border-3", true)}"><div class="card-body"><div class="row d-flex flex-nowrap"><div class="col-auto d-md-flex d-none"><a href="${escape(base, true) + "/addons/detail/" + escape(plugin.id, true)}"><img height="82" width="82" src="${escape(API_URL, true) + "/panel/plugins/" + escape(plugin.id, true) + "/logo"}" class="bg-light animate__animated animate__zoomIn"${add_attribute("alt", plugin.id, 0)}> </a></div> <div class="col"><div class="row"><div class="col"><a href="${escape(base, true) + "/addons/detail/" + escape(plugin.id, true)}"><h5 class="card-title">${escape(plugin.id)}</h5> </a></div> <div class="col-auto"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="addonStatusSwitch" ${plugin.status === "STARTED" ? "checked" : ""} ${plugin.loading ? "disabled" : ""}> </div></div> ${plugin.status === "FAILED" ? `<div class="col-auto ps-0"><a href="#" tabindex="0" class="link-danger" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-custom-class="font-monospace" data-bs-title="Error Log"${add_attribute("data-bs-content", plugin.error, 0)}><i class="fa-solid fa-circle-exclamation fa-1x"></i></a> </div>` : ``}</div> <small class="text-muted"><a href="/" target="_blank">${escape(plugin.author)}</a> <div class="vr mx-2"></div> <span class="font-monospace">${escape(plugin.version)}</span> ${plugin.verifyStatus !== "UNKNOWN" ? `<div class="vr mx-2"></div> <a href="${escape(PANO_WEBSITE_URL, true) + "/" + escape(plugin.id, true)}" target="_blank" title="Mağaza Adresi" class="card-link"><i class="fa-solid fa-store"></i> </a>` : ``} ${plugin.sourceUrl ? `<div class="vr mx-2"></div> <a${add_attribute("href", plugin.sourceUrl, 0)} target="_blank" title="Kaynak Adresi" class="card-link"><i class="fa-solid fa-link"></i> </a>` : ``} ${plugin.license ? `<div class="vr mx-2"></div> <span class="font-monospace">${escape(plugin.license)}</span>` : ``} ${plugin.verifyStatus !== "UNKNOWN" ? `<div class="vr mx-2"></div>` : ``} ${plugin.verifyStatus === "VERIFIED" ? `<span class="text-success" data-svelte-h="svelte-139duwz"><i class="fa-regular fa-circle-check me-1"></i> </span>` : `${plugin.verifyStatus === "NOT_VERIFIED" ? `<span class="text-warning" data-svelte-h="svelte-1u3ukvw"><i class="fa-solid fa-circle-exclamation me-1"></i> </span>` : ``}`}</small> <p class="pt-2"><!-- HTML_TAG_START -->${plugin.description}<!-- HTML_TAG_END --></p> </div></div> </div></div> </div>`;
  })}</div></div></div> </div>`;
});

export { Addons as A, PageTypes as P, load as l };
//# sourceMappingURL=Addons-BnP7WxB_.js.map
