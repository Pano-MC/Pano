import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PostsLayout } from './6-A9W_Y587.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './index-DzcLzHBX.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';

const Layout_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(PostsLayout, "Layout").$$render($$result, {}, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout_1 as default };
//# sourceMappingURL=_layout.svelte-CUFHnz32.js.map
