import { c as create_ssr_component, a as subscribe, f as getContext, o as onDestroy, v as validate_component, e as escape, h as each, i as createEventDispatcher, b as add_classes, d as add_attribute } from './ssr-ffuobYCI.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-Cb5EDErE.js';
import { e as error } from './index-DzcLzHBX.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination--ODwq86l.js';
import './ToastContainer-D6cKqDaa.js';
import { D as Date_1 } from './Date-CO7kc4Oc.js';
import { P as PlayerPermissionBadge } from './PlayerPermissionBadge-DYILRjQ1.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-npnb-NGS.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';

String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
const PlayerStatusBadge = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let isOnline;
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { banned = false } = $$props;
  let { lastActivityTime = 0 } = $$props;
  let { inGame = 0 } = $$props;
  let { checkTime = 0 } = $$props;
  if ($$props.banned === void 0 && $$bindings.banned && banned !== void 0) $$bindings.banned(banned);
  if ($$props.lastActivityTime === void 0 && $$bindings.lastActivityTime && lastActivityTime !== void 0) $$bindings.lastActivityTime(lastActivityTime);
  if ($$props.inGame === void 0 && $$bindings.inGame && inGame !== void 0) $$bindings.inGame(inGame);
  if ($$props.checkTime === void 0 && $$bindings.checkTime && checkTime !== void 0) $$bindings.checkTime(checkTime);
  isOnline = lastActivityTime > Date.now() - 5 * 60 * 1e3 || inGame;
  $$unsubscribe__();
  return `${banned ? `<div class="badge rounded-pill text-bg-danger">${escape($_("components.player-status-badge.banned"))}</div>` : `${isOnline ? `<div class="badge rounded-pill text-bg-success"><span>${escape($_("components.player-status-badge.online"))}</span></div>` : `<div class="badge rounded-pill text-bg-danger"><span>${escape($_("components.player-status-badge.offline"))}</span></div>`}`}`;
});
const PlayerRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $user, $$unsubscribe_user;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const user = getContext("user");
  $$unsubscribe_user = subscribe(user, (value) => $user = value);
  let { player } = $$props;
  let { checkTime } = $$props;
  createEventDispatcher();
  if ($$props.player === void 0 && $$bindings.player && player !== void 0) $$bindings.player(player);
  if ($$props.checkTime === void 0 && $$bindings.checkTime && checkTime !== void 0) $$bindings.checkTime(checkTime);
  $$unsubscribe__();
  $$unsubscribe_user();
  return `<tr${add_classes((player.selected ? "table-primary" : "").trim())}><th scope="row"><div class="dropdown position-static"><button type="button" class="btn btn-link btn-sm" aria-expanded="false" aria-haspopup="true" data-bs-toggle="dropdown" href="javascript:void(0);"${add_attribute("title", $_("components.player-row.actions"), 0)}><span class="fas fa-ellipsis-v"></span></button> <div class="dropdown-menu dropdown-menu-start animate__animated animate__fadeIn">${hasPermission(Permissions.MANAGE_PERMISSION_GROUPS) ? `<a class="${[
    "dropdown-item",
    $user.username === player.username || player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fas fa-user-circle me-2"></i> ${escape($_("components.player-row.authorize"))}</a>` : ``} <a class="${[
    "dropdown-item",
    player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fa-solid fa-pencil-alt me-2"></i> ${escape($_("components.player-row.edit"))}</a> <a class="${[
    "dropdown-item",
    ($user.username !== player.username && (player.permissionGroup === "admin" && $user.admin || player.permissionGroup !== "admin") ? "link-danger" : "") + " " + ($user.username === player.username || player.permissionGroup === "admin" && !$user.admin ? "disabled" : "")
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fas fa-gavel me-2"></i> ${player.isBanned ? `${escape($_("components.player-row.remove-ban"))}` : `${escape($_("components.player-row.ban"))}`}</a></div></div></th> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.player-row.view"), 0)} href="${escape(base, true) + "/players/detail/" + escape(player.username, true)}"><img${add_attribute("alt", player.username, 0)} class="rounded-circle animate__animated animate__zoomIn me-2" height="32" src="${"https://minotar.net/avatar/" + escape(player.username, true)}" width="32"> ${escape(player.username)}</a></td> <td class="align-middle text-nowrap text-capitalize">${validate_component(PlayerPermissionBadge, "PlayerPermissionBadge").$$render($$result, { permissionGroup: player.permissionGroup }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(PlayerStatusBadge, "PlayerStatusBadge").$$render(
    $$result,
    {
      banned: player.isBanned,
      lastActivityTime: player.lastActivityTime,
      inGame: player.inGame,
      checkTime
    },
    {},
    {}
  )}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: player.lastLoginDate }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: player.registerDate }, {}, {})}</td> </tr>`;
});
const PageTypes = Object.freeze({
  ALL: "ALL",
  HAS_PERM: "HAS_PERM",
  BANNED: "BANNED"
});
const DefaultPageType = PageTypes.ALL;
async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const page = parseInt(searchParams.get("page")) || 1;
  const permissionGroup = searchParams.get("permissionGroup");
  const pageType = searchParams.get("pageType") || DefaultPageType;
  if (!Object.values(PageTypes).includes(pageType)) {
    throw error(404, "PAGE_NOT_FOUND");
  }
  const queryParams = buildQueryParams({ page, status: pageType, permissionGroup });
  const body = await ApiUtil.get({
    path: `/api/panel/players` + queryParams,
    request: event
  });
  if (body.error) {
    if (body.error === "PAGE_NOT_FOUND") {
      throw error(404, body.error);
    }
    throw error(500, body.error);
  }
  body.page = page;
  body.pageType = pageType;
  body.permissionGroup = permissionGroup;
  return body;
}
const Players = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  let checkTime = 0;
  let interval;
  const pageTitle = getContext("pageTitle");
  onDestroy(() => {
    clearInterval(interval);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set(data.permissionGroup ? $_("pages.players.by-perm-group-title", {
        values: {
          permissionGroupName: data.permissionGroup === "-" ? $_("pages.players.player") : data.permissionGroup
        }
      }) : $_("pages.players.title", {
        values: {
          pageType: data.pageType === PageTypes.HAS_PERM ? $_("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? $_("pages.players.banned") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe__();
  return ` <div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    left: () => {
      return `<div slot="left">${data.permissionGroup ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players"}"><i class="fas fa-arrow-left me-2"></i> ${escape($_("buttons.players"))}</a>` : `${hasPermission(Permissions.MANAGE_PERMISSION_GROUPS) ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players/perm-groups"}"><i class="fas fa-user-circle me-2"></i> ${escape($_("pages.players.perm-groups"))}</a>` : ``}`}</div>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${!data.permissionGroup ? ` ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players",
              active: data.pageType === PageTypes.ALL
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.all"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players?pageType=HAS_PERM",
              active: data.pageType === PageTypes.HAS_PERM
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.authorized"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players?pageType=BANNED",
              active: data.pageType === PageTypes.BANNED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.banned"))}`;
              }
            }
          )}` : ``}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.players.table-title", {
        values: {
          playerCount: data.playerCount,
          pageType: data.pageType === PageTypes.HAS_PERM ? $_("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? $_("pages.players.banned") + " " : ""
        }
      }))}</h5>`;
    }
  })}  ${data.playerCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col"></th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.name"))}</th> <th class="${["align-middle text-nowrap", data.permissionGroup ? "table-primary" : ""].join(" ").trim()}" scope="col">${escape($_("pages.players.table.perm-group"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.status"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.last-login"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.register-date"))}</th></tr></thead> <tbody>${each(data.players, (player, index) => {
    return `${validate_component(PlayerRow, "PlayerRow").$$render($$result, { player, checkTime }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 20;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BqBrm7yO.js')).default;
const universal_id = "src/routes/players/+page.js";
const imports = ["_app/immutable/nodes/20.CVUnW2pu.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/api.util.DjyA6Qtr.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/index.CvLV2jqT.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/Pagination.DlIpNFey.js","_app/immutable/chunks/UnbanPlayerModal.BxsmMMl4.js","_app/immutable/chunks/ToastContainer.DJmHgWMZ.js","_app/immutable/chunks/Date.BBtJyksR.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.D1XPrI3Y.js","_app/immutable/chunks/language.util.Bm0GVGlQ.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/PlayerPermissionBadge.Dd1iW-mB.js","_app/immutable/chunks/auth.util.BqcupRKq.js","_app/immutable/chunks/NoContent.BUfNilqv.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.CjMNuYL-.js","_app/immutable/chunks/CardFilters.D_NieZz5.js"];
const stylesheets = [];
const fonts = [];

var _20 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Players as P, _20 as _ };
//# sourceMappingURL=20-CFI-EZQW.js.map
