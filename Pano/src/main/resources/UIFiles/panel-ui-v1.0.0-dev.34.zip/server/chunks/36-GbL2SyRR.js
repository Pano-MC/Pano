import { c as create_ssr_component, a as subscribe, f as getContext, d as add_attribute, e as escape, h as each, v as validate_component } from './ssr-ffuobYCI.js';
import { d as buildQueryParams, b as ApiUtil, c as PANO_WEBSITE_URL } from './api.util-Cb5EDErE.js';
import { b as base } from './paths-C6LjEmZF.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { p as page } from './stores-BDx4Az-R.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';
import { L as Languages } from './language.util-2VlJt8zV.js';
import { w as writable } from './index2-Dyghn50Q.js';

const modalElement = writable();
const error = writable(null);
const continueProcessObj = writable();
const ConfirmRemovePanoAccountModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_continueProcessObj;
  let $$unsubscribe_error;
  let $modalElement, $$unsubscribe_modalElement;
  let $_, $$unsubscribe__;
  $$unsubscribe_continueProcessObj = subscribe(continueProcessObj, (value) => value);
  $$unsubscribe_error = subscribe(error, (value) => value);
  $$unsubscribe_modalElement = subscribe(modalElement, (value) => $modalElement = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_continueProcessObj();
  $$unsubscribe_error();
  $$unsubscribe_modalElement();
  $$unsubscribe__();
  return `<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"${add_attribute("this", $modalElement, 0)}><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-remove-pano-account.title"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("buttons.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("buttons.yes"))}</button></div></div></div> </div>`;
});
const UpdatePeriod = Object.freeze({
  NEVER: "NEVER",
  ONCE_PER_DAY: "ONCE_PER_DAY",
  ONCE_PER_WEEK: "ONCE_PER_WEEK",
  ONCE_PER_MONTH: "ONCE_PER_MONTH"
});
async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const queryParams = buildQueryParams({ type: "GENERAL" });
  const body = await ApiUtil.get({
    path: "/api/panel/settings" + queryParams,
    request: event
  });
  body.oldSettings = structuredClone(body);
  const failed = searchParams.get("failed");
  const encodedData = searchParams.get("encodedData");
  const state = searchParams.get("state");
  return {
    ...body,
    platformConnectFailed: failed,
    encodedData,
    state
  };
}
function maskEmail(email) {
  const [localPart, domain] = email.split("@");
  const maskedLocal = localPart.length <= 3 ? `${localPart[0]}**` : `${localPart.substring(0, 2)}${"*".repeat(localPart.length - 2)}`;
  const domainParts = domain.split(".");
  const maskedDomain = `${domainParts[0][0]}${"*".repeat(domainParts[0].length - 1)}.${domainParts.slice(1).join(".")}`;
  return `${maskedLocal}@${maskedDomain}`;
}
const PlatformSettings = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let preferencesSaveDisabled;
  let emailSaveDisabled;
  let $siteInfo, $$unsubscribe_siteInfo;
  let $$unsubscribe_page;
  let $_, $$unsubscribe__;
  let $Languages, $$unsubscribe_Languages;
  $$unsubscribe_page = subscribe(page, (value) => value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_Languages = subscribe(Languages, (value) => $Languages = value);
  const pageTitle = getContext("pageTitle");
  const siteInfo = getContext("siteInfo");
  $$unsubscribe_siteInfo = subscribe(siteInfo, (value) => $siteInfo = value);
  pageTitle.set("pages.settings.platform.title");
  let { data } = $$props;
  let connecting = !data.panoAccount && data.state && data.encodedData;
  let smtpDisabled;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  preferencesSaveDisabled = data.oldSettings.updatePeriod === data.updatePeriod && data.oldSettings.locale === data.locale;
  emailSaveDisabled = JSON.stringify(data.oldSettings.email) === JSON.stringify(data.email) || !data.email.password;
  {
    {
      smtpDisabled = !$siteInfo.emailEnabled;
    }
  }
  $$unsubscribe_siteInfo();
  $$unsubscribe_page();
  $$unsubscribe__();
  $$unsubscribe_Languages();
  return `${!data.panoAccount && data.platformConnectFailed ? ` <div class="alert alert-danger alert-dismissible fade show mb-0" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert"${add_attribute("aria-label", $_("buttons.close"), 0)}></button> ${escape($_("pages.settings.platform.connect-failed-alert"))}</div>` : ``}  <div class="card"><div class="card-body animate__animated animate__fadeIn"><h5 class="card-title">${escape($_("pages.settings.platform.account"))}</h5> ${data.panoAccount ? `<div class="row mb-3"><label class="col-md-6" for="platformId">${escape($_("pages.settings.platform.platform-id"))}</label> <div class="col" id="platformId">${escape(data.panoAccount.platformId)}</div></div> <div class="row mb-3"><label class="col-md-6" for="panoAccountUsername">${escape($_("pages.settings.platform.user"))}</label> <div class="col" id="panoAccountUsername"><a${add_attribute("href", PANO_WEBSITE_URL + "/users/" + data.panoAccount.username, 0)}${add_attribute("title", $_("components.player-row.view"), 0)} target="_blank"><img src="${"https://minotar.net/avatar/" + escape(data.panoAccount.username, true)}" width="20" height="20" class="rounded-circle animate__animated animate__zoomIn me-2"${add_attribute("alt", data.panoAccount.username, 0)}>${escape(data.panoAccount.username)}</a></div></div>` : ``} <div class="row"><label class="col-md-6" for="connectPanoAccount">${escape($_("pages.settings.platform.online-account"))} <br> <small class="text-muted">${escape($_("pages.settings.platform.online-account-description"))}</small></label> <div class="col" id="connectPanoAccount">${data.panoAccount ? `<span class="text-muted">${escape(maskEmail(data.panoAccount.email))}</span> <button type="button" class="btn btn-sm btn-outline-danger ms-2" ${""}>${escape($_("buttons.remove"))}</button>` : `<button type="button" class="btn btn-sm btn-outline-primary lh-base" ${connecting ? "disabled" : ""}><img src="${escape(base, true) + "/assets/img/logo.svg"}" width="20" height="20" class="me-2 bg-dark p-1 rounded" alt="Pano"> ${escape(connecting ? $_("buttons.connecting") : $_("buttons.connect"))} ${connecting ? `<span class="spinner-border spinner-border-sm text-primary" role="status"></span>` : ``}</button>`}</div></div></div></div> <div class="card"><div class="card-body animate__animated animate__fadeIn"><h5 class="card-title">${escape($_("pages.settings.platform.preferences"))}</h5> <div class="row mb-3" data-svelte-h="svelte-1jqie97"><label class="col-md-6" for="platformDevMode">Geliştirici Modu</label> <div class="col"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="platformDevMode"></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="platformLanguage">${escape($_("pages.settings.platform.display-language"))}</label> <div class="col-md-6"><select class="form-control" id="platformLanguage">${each(Object.keys($Languages), (language, index) => {
    return `<option${add_attribute("value", $Languages[language].locale, 0)}>${escape($Languages[language].name)}</option>`;
  })}</select></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="updatePeriod">${escape($_("pages.settings.platform.check-auto-updates"))}</label> <div class="col-md-6"><select class="form-control" id="updatePeriod"><option${add_attribute("value", UpdatePeriod.NEVER, 0)}>${escape($_("pages.settings.platform.inputs.check-auto-updates.never"))}</option><option${add_attribute("value", UpdatePeriod.ONCE_PER_DAY, 0)}>${escape($_("pages.settings.platform.inputs.check-auto-updates.once-in-a-day"))}</option><option${add_attribute("value", UpdatePeriod.ONCE_PER_WEEK, 0)}>${escape($_("pages.settings.platform.inputs.check-auto-updates.once-in-a-week"))} </option><option${add_attribute("value", UpdatePeriod.ONCE_PER_MONTH, 0)}>${escape($_("pages.settings.platform.inputs.check-auto-updates.once-in-a-month"))}</option></select></div></div> <button class="${[
    "btn btn-secondary",
    preferencesSaveDisabled ? "disabled" : ""
  ].join(" ").trim()}"${add_attribute("aria-disabled", preferencesSaveDisabled, 0)}>${escape($_("pages.settings.platform.save-button"))}</button></div></div> ${``} <div class="card"><div class="card-header"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="smtpToggle" ${$siteInfo.emailEnabled ? "checked" : ""} ${""}> <label class="form-check-label" for="smtpToggle">${escape($_("pages.settings.platform.toggle-smtp"))}</label></div></div> <div class="${["card-body", smtpDisabled ? "opacity-50" : ""].join(" ").trim()}"><h5 class="card-title">${escape($_("pages.settings.platform.smtp-settings"))}</h5> <p class="text-muted">${escape($_("pages.settings.platform.smtp.description"))}</p> <div class="row mb-3"><label class="col-md-6 col-form-label" for="mailUsername">${escape($_("pages.settings.platform.smtp.username"))}</label> <div class="col-md-6"><input class="form-control" id="mailUsername" type="text" placeholder="no-reply" ${smtpDisabled ? "disabled" : ""}${add_attribute("value", data.email.username, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="mailUserPassword">${escape($_("pages.settings.platform.smtp.password"))}</label> <div class="col-md-6"><input class="form-control" id="mailUserPassword" placeholder="****************" type="password" ${smtpDisabled ? "disabled" : ""}${add_attribute("value", data.email.password, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="useSSLCheck">${escape($_("pages.settings.platform.smtp.ssl"))}</label> <div class="col-md-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="useSSLCheck" id="useSSLCheck"${add_attribute("aria-checked", data.email.ssl, 0)} ${smtpDisabled ? "disabled" : ""}${add_attribute("checked", data.email.ssl, 1)}></div></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="port">${escape($_("pages.settings.platform.smtp.tls-setting"))}</label> <div class="col-md-6"><select class="form-select" id="port" ${smtpDisabled ? "disabled" : ""}><option value="REQUIRED" data-svelte-h="svelte-f10wfa">REQUIRED</option><option value="OPTIONAL" data-svelte-h="svelte-1i3t086">OPTIONAL</option><option value="DISABLED" data-svelte-h="svelte-17fanv2">DISABLED</option></select></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="senderAddress">${escape($_("pages.settings.platform.smtp.sender-address"))}</label> <div class="col-md-6"><input class="form-control" id="senderAddress" type="text" placeholder="no-reply@forexample.com" ${smtpDisabled ? "disabled" : ""}${add_attribute("value", data.email.sender, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="hostAddress">${escape($_("pages.settings.platform.smtp.hostname"))}</label> <div class="col-md-6"><input class="form-control" id="hostAddress" type="text" placeholder="smtp.forexample.com" ${smtpDisabled ? "disabled" : ""}${add_attribute("value", data.email.hostname, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="port">${escape($_("pages.settings.platform.smtp.port"))}</label> <div class="col-md-6"><input class="form-control" id="port" placeholder="465" type="number" ${smtpDisabled ? "disabled" : ""}${add_attribute("value", data.email.port, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="port">${escape($_("pages.settings.platform.smtp.auth-methods"))}</label> <div class="col-md-6"><select class="form-select" ${smtpDisabled ? "disabled" : ""}><option value="PLAIN" data-svelte-h="svelte-1jpafdu">PLAIN</option><option value=""></option></select></div></div> <button class="btn btn-secondary" ${"disabled"}>${escape($_(!$siteInfo.emailEnabled ? "buttons.enable" : "pages.settings.platform.save-button"))}</button> ${!emailSaveDisabled ? `<button class="btn btn-outline-primary" ${smtpDisabled ? "disabled" : ""}>${escape($_("buttons.validate"))} ${``}</button>` : ``}</div></div> ${validate_component(ConfirmRemovePanoAccountModal, "ConfirmRemovePanoAccountModal").$$render($$result, {}, {}, {})}`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 36;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-B8rB0jhZ.js')).default;
const universal_id = "src/routes/settings/platform/+page.js";
const imports = ["_app/immutable/nodes/36.481oEMhH.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/api.util.DjyA6Qtr.js","_app/immutable/chunks/stores.CukszKVv.js","_app/immutable/chunks/entry.C3nji88B.js","_app/immutable/chunks/paths.P3ueEoWl.js","_app/immutable/chunks/runtime.DFEbvLuq.js","_app/immutable/chunks/ToastContainer.DJmHgWMZ.js","_app/immutable/chunks/language.util.Bm0GVGlQ.js"];
const stylesheets = [];
const fonts = [];

var _36 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PlatformSettings as P, _36 as _ };
//# sourceMappingURL=36-GbL2SyRR.js.map
