const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-3Z6FAi5I.js')).default;
const imports = ["_app/immutable/nodes/3.DHRxak_c.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-B2cBC23K.js.map
