import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';

const Languages = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `Language management page.`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Languages, "Languages").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DU2oRfWe.js.map
