import{b as a}from"../chunks/entry.C3nji88B.js";export{a as start};
