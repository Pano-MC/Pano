import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-D53OO7TG.js';
import { a as getProfile } from './profile2-2Ez3RMQI.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DJ0yQ441.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.B2lU3Z-T.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/BrX4yPZ8.js","_app/immutable/chunks/BURDKJNi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/D0zaWC_C.js","_app/immutable/chunks/BuNPbJz4.js","_app/immutable/chunks/CYgtFu8J.js","_app/immutable/chunks/CACRyBpo.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/CUGYs0tt.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/CqXlCtAN.js","_app/immutable/chunks/BtrVhXRe.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-C8_OhoPd.js.map
