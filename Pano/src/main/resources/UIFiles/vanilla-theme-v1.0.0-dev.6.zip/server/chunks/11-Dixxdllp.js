import { ab as stringify, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import './client-CjlfgChI.js';
import { b as getPostDetail, P as Post } from './posts2-WannU8zN.js';
import { e as error } from './index2-DzcLzHBX.js';
import { l as load$1, H as HomeSidebar } from './HomeSidebar-Dpf9cLnW.js';
import { a as attr } from './attributes-JZZbhxX3.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0,
      url: ""
    },
    previousPost: "-",
    nextPost: "-"
  };
  await load$1(event);
  await getPostDetail({ url: event.params.url, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "POST_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return { ...data, sidebar: HomeSidebar };
}
function PostDetail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  Post($$payload, { post: data.post, detail: true });
  $$payload.out += `<!----> <div class="row justify-content-between"><div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.previousPost === "-" ? "" : data.previousPost.url)}`)}${attr("class", `btn btn-link ps-0 ${stringify([data.previousPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.previous-post"))}</a></div> <div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.nextPost === "-" ? "" : data.nextPost.url)}`)}${attr("class", `btn btn-link pe-0 ${stringify([data.nextPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.next-post"))}</a></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C1tmFJ7D.js')).default;
const universal_id = "src/routes/blog/post/[url]/+page.js";
const imports = ["_app/immutable/nodes/11.BPo3NVIr.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BURDKJNi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/CYgtFu8J.js","_app/immutable/chunks/ZfpD-H_W.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/CUGYs0tt.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/CmArI4c2.js","_app/immutable/chunks/DEtv9G4I.js","_app/immutable/chunks/BtrVhXRe.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js"];
const stylesheets = [];
const fonts = [];

var _11 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PostDetail as P, _11 as _ };
//# sourceMappingURL=11-Dixxdllp.js.map
