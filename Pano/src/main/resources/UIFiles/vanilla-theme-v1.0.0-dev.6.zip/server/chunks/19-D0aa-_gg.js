import { t as pop, aa as getContext, a8 as store_get, ab as stringify, a9 as unsubscribe_stores, a6 as bind_props, a1 as writable, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { O as OnlineAdmins } from './OnlineAdmins-BRQUy31Y.js';
import { A as ApiUtil } from './api.util-Cv_Hl9eW.js';
import { a as attr } from './attributes-JZZbhxX3.js';

const data = writable({ onlineAdmins: [] });
const load$1 = async (event) => {
  data.set(await ApiUtil.get({ path: "/api/sidebar/support", request: event }));
};
function SupportSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  Sidebar($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3">`;
      OnlineAdmins($$payload2, {
        onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins
      });
      $$payload2.out += `<!----></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: SupportSidebar };
}
function Support($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.title"))}</h3> <p>Sana nasıl yardımcı olabiliriz?</p> <ul class="list-group list-group-horizontal text-center"><a href="/ticket/create" class="list-group-item list-group-item-action"><i class="fas fa-ticket fa-2x my-3"></i> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.description"))}</small></a> <a${attr("href", `mailto:${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.supportEmail)}`)} class="list-group-item list-group-item-action"><i class="fas fa-envelope fa-2x my-3"></i> <div class="col-auto"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.description", {
    values: {
      websiteName: store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName
    }
  }))}</small></div></a></ul></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 19;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-L8QPjZiZ.js')).default;
const universal_id = "src/routes/support/+page.js";
const imports = ["_app/immutable/nodes/19.DaXabwSU.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/CUGYs0tt.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/B1GWSh8X.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/BURDKJNi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/D-8kYPrx.js"];
const stylesheets = [];
const fonts = [];

var _19 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Support as S, _19 as _ };
//# sourceMappingURL=19-D0aa-_gg.js.map
