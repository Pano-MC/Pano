import { a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import { P as Pagination } from './Pagination-DT_5Txbj.js';
import { P as Posts } from './Posts-BPdz5Jjn.js';
import { l as load$1, H as HomeSidebar } from './HomeSidebar-Dpf9cLnW.js';
import { a as getPosts } from './posts2-WannU8zN.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    posts: [],
    postCount: 0,
    page: 1,
    totalPage: 1
  };
  await load$1(event);
  await getPosts({ page: event.params.page || 1, request: event }).then((body) => {
    if (body.error) {
      return;
    }
    data = body;
  });
  return { ...data, sidebar: HomeSidebar };
}
function Home($$payload, $$props) {
  push();
  let data = $$props["data"];
  Posts($$payload, { posts: data.posts });
  $$payload.out += `<!---->  `;
  if (data.postCount > 0) {
    $$payload.out += "<!--[-->";
    Pagination($$payload, {
      page: data.page,
      totalPage: data.totalPage,
      loading: false
    });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { data });
  pop();
}

export { Home as H, load as l };
//# sourceMappingURL=Home-CpXKmskZ.js.map
