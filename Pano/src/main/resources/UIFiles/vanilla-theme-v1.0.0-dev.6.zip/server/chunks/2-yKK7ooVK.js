import { a7 as slot, t as pop, p as push } from './index3-CeMfA1rb.js';
import { r as requireLogin } from './Store-CS8VFGEx.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-BLPscPiC.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.BQyJshZ6.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/D0zaWC_C.js","_app/immutable/chunks/BuNPbJz4.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/CYgtFu8J.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-yKK7ooVK.js.map
