import { l as load } from './Home-CpXKmskZ.js';
import './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-BPdz5Jjn.js';
import './posts2-WannU8zN.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './html-FW6Ia4bL.js';
import './api.util-Cv_Hl9eW.js';
import './NoContent-CRKA6SSq.js';
import './HomeSidebar-Dpf9cLnW.js';
import './Sidebar-BJnCaXJE.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 10;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CYSjbDnE.js')).default;
const universal_id = "src/routes/blog/page/[page]/+page.js";
const imports = ["_app/immutable/nodes/10.C1Cs5g82.js","_app/immutable/chunks/gCetOk0G.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/ZfpD-H_W.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/BURDKJNi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/CUGYs0tt.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/CmArI4c2.js","_app/immutable/chunks/DEtv9G4I.js","_app/immutable/chunks/BtrVhXRe.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/CDvv4TlA.js","_app/immutable/chunks/C9x-SqgQ.js","_app/immutable/chunks/D68HvWdn.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=10-BwVXtBE4.js.map
