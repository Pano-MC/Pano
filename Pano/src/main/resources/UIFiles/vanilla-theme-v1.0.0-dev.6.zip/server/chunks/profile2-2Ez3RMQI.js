import { A as ApiUtil } from './api.util-Cv_Hl9eW.js';

const getProfile = async ({ request }) => {
  return ApiUtil.get({
    path: `/api/profile`,
    request
  });
};
const getPlayerProfile = async ({ request, username }) => {
  return ApiUtil.get({
    path: `/api/profile/${username}`,
    request
  });
};

export { getProfile as a, getPlayerProfile as g };
//# sourceMappingURL=profile2-2Ez3RMQI.js.map
