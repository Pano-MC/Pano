import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { S as SuccessAlert } from './SuccessAlert-xdL2cry4.js';

async function load({ parent, url: { searchParams } }) {
  await parent();
  const token = searchParams.get("token") || "";
  return { token };
}
function ActivateNewEmail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let error;
  let successMessage = null;
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.title"))}</h3> <img alt="Allay" src="https://cdn3.emoji.gg/emojis/8182-allay-dancing.gif"> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message: successMessage });
  $$payload.out += `<!----> <button${attr("class", `btn btn-secondary w-100 ${stringify([
    ""
  ].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.activate-button"))}</button></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-wRIQcQMu.js')).default;
const universal_id = "src/routes/activate-new-email/+page.js";
const imports = ["_app/immutable/nodes/7.bXb8IWQg.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Bn6zQMqw.js","_app/immutable/chunks/DNoB9BYy.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/BuNPbJz4.js","_app/immutable/chunks/B71s1Bwl.js","_app/immutable/chunks/DbEct-_y.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/Ba6TciiY.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ActivateNewEmail as A, _7 as _ };
//# sourceMappingURL=7-DmnbjJDH.js.map
