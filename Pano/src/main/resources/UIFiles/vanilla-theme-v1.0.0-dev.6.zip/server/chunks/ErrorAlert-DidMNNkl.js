import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { e as escape_html } from './runtime-BlMCrmsd.js';

function ErrorAlert($$payload, $$props) {
  let error = $$props["error"];
  const alwaysVisible = false;
  if (error || alwaysVisible) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="alert alert-danger">${escape_html(error)}</div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { error });
}

export { ErrorAlert as E };
//# sourceMappingURL=ErrorAlert-DidMNNkl.js.map
