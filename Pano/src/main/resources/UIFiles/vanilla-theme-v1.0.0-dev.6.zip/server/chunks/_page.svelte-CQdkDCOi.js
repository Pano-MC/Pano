import { S as Settings } from './16-DMq9klFY.js';
import './index3-CeMfA1rb.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import './ProfileSidebar-D53OO7TG.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './api.util-Cv_Hl9eW.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload) {
  Settings($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CQdkDCOi.js.map
