import { t as pop, a1 as writable, p as push, a8 as store_get, a9 as unsubscribe_stores } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { O as OnlineAdmins } from './OnlineAdmins-BRQUy31Y.js';
import { A as ApiUtil } from './api.util-Cv_Hl9eW.js';
import { T as TicketStatuses } from './TicketStatus-BNVJhxUW.js';

const data = writable({ onlineAdmins: [] });
const ticketData = writable(null);
const load = async (event, ticket) => {
  data.set(await ApiUtil.get({ path: "/api/sidebar/support", request: event }));
  if (ticket) {
    ticketData.set(ticket);
  }
};
function TicketCreateAndDetailSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  Sidebar($$payload, {
    children: ($$payload2) => {
      if (store_get($$store_subs ??= {}, "$ticketData", ticketData)) {
        $$payload2.out += "<!--[-->";
        if (store_get($$store_subs ??= {}, "$ticketData", ticketData).status !== TicketStatuses.CLOSED) {
          $$payload2.out += "<!--[-->";
          $$payload2.out += `<div class="mb-3"><button class="btn btn-lg btn-danger w-100" type="button"><i class="fas fa-times me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.ticket-create-and-detail.close-ticket-button"))}</button></div>`;
        } else {
          $$payload2.out += "<!--[!-->";
        }
        $$payload2.out += `<!--]-->`;
      } else {
        $$payload2.out += "<!--[!-->";
      }
      $$payload2.out += `<!--]-->  `;
      OnlineAdmins($$payload2, {
        onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

export { TicketCreateAndDetailSidebar as T, load as l };
//# sourceMappingURL=TicketCreateAndDetailSidebar-10NNrnZ3.js.map
