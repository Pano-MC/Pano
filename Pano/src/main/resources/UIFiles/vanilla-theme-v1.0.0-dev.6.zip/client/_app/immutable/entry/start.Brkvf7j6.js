import{a as t}from"../chunks/DNoB9BYy.js";export{t as start};
