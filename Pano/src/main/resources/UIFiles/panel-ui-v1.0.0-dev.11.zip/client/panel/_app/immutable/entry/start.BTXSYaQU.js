import{a as t}from"../chunks/entry.BG2XX_1C.js";export{t as start};
