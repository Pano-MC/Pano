import { l as load$1, a as PageTypes } from './Posts-wGZWwfrK.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-CzxmL1-R.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardMenuItem-DRnpye9y.js';
import './stores-BDx4Az-R.js';
import './CardFilters-C1uMKg14.js';

async function load(input) {
  return load$1(input, PageTypes.DRAFT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 39;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BgDOF7qX.js')).default;
const universal_id = "src/routes/posts/draft/+page.js";
const imports = ["_app/immutable/nodes/39.Bctwchf6.js","_app/immutable/chunks/Posts.BdjNoq5l.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.HYqLlNvl.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/Store.CumO5kt-.js","_app/immutable/chunks/api.util.MQ_49TY1.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/Pagination.B2CWMpJx.js","_app/immutable/chunks/ConfirmDeletePostModal.Buje24hj.js","_app/immutable/chunks/Toast.BsODr_2q.js","_app/immutable/chunks/Date.BeJ2IgF2.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.Db4o2w4u.js","_app/immutable/chunks/language.util.DzEm6ZvY.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/PostPublishedToast.fQCjOvsd.js","_app/immutable/chunks/NoContent.pZt1Ccb_.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardMenuItem.C64M_a8R.js","_app/immutable/chunks/CardFilters.Dml6h8e8.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=39-RW0w1av9.js.map
