const index = 70;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DGC6z96p.js')).default;
const imports = ["_app/immutable/nodes/70.CUCMmT3N.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=70-BgTREfYp.js.map
