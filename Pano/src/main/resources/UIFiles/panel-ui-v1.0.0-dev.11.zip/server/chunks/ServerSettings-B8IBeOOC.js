import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, v as validate_component, d as add_attribute } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { w as writable } from './index2-Dyghn50Q.js';
import './client-CnCRRyPd.js';
import './ToastContainer-CKzXwJro.js';

const dialogID$1 = "makeMainServerModal";
const server$1 = writable({});
const loading$1 = writable(false);
const MakeMainServerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $server, $$unsubscribe_server;
  let $loading, $$unsubscribe_loading;
  let $_, $$unsubscribe__;
  $$unsubscribe_server = subscribe(server$1, (value) => $server = value);
  $$unsubscribe_loading = subscribe(loading$1, (value) => $loading = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_server();
  $$unsubscribe_loading();
  $$unsubscribe__();
  return `<div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$1, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.make-main-server.title", { values: { serverName: $server.name } }))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link link-danger col-6 m-0", $loading ? "disabled" : ""].join(" ").trim()}" type="button">${escape($_("components.modals.make-main-server.no"))}</button> <button class="${["btn btn-primary col-6 m-0", $loading ? "disabled" : ""].join(" ").trim()}" type="button">${escape($_("components.modals.make-main-server.yes"))}</button></div></div></div> </div>`;
});
const dialogID = "confirmRemoveServer";
const server = writable({});
const loading = writable(false);
const passwordError = writable(false);
const currentPassword = writable("");
const RemoveServerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let confirmButtonDisabled;
  let $passwordError, $$unsubscribe_passwordError;
  let $$unsubscribe_server;
  let $currentPassword, $$unsubscribe_currentPassword;
  let $$unsubscribe_loading;
  let $_, $$unsubscribe__;
  $$unsubscribe_passwordError = subscribe(passwordError, (value) => $passwordError = value);
  $$unsubscribe_server = subscribe(server, (value) => value);
  $$unsubscribe_currentPassword = subscribe(currentPassword, (value) => $currentPassword = value);
  $$unsubscribe_loading = subscribe(loading, (value) => value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  confirmButtonDisabled = $currentPassword.length === 0;
  $$unsubscribe_passwordError();
  $$unsubscribe_server();
  $$unsubscribe_currentPassword();
  $$unsubscribe_loading();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-16uwuuf"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.remove-server.title"))} <input class="${[
    "form-control d-inline-block text-center mt-3",
    $passwordError ? "border-danger" : ""
  ].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.remove-server.account-password"), 0)} type="password"${add_attribute("value", $currentPassword, 0)}></div> <div class="modal-footer flex-nowrap"><button class="btn btn-link col-6 m-0" type="button">${escape($_("components.modals.remove-server.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", confirmButtonDisabled ? "disabled" : ""].join(" ").trim()}" type="button" ${confirmButtonDisabled ? "disabled" : ""}>${escape($_("components.modals.remove-server.yes"))}</button></div></form></div></div> </div>`;
});
const ServerSettings = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $selectedServer, $$unsubscribe_selectedServer;
  let $_, $$unsubscribe__;
  let $mainServer, $$unsubscribe_mainServer;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const mainServer = getContext("mainServer");
  $$unsubscribe_mainServer = subscribe(mainServer, (value) => $mainServer = value);
  const selectedServer = getContext("selectedServer");
  $$unsubscribe_selectedServer = subscribe(selectedServer, (value) => $selectedServer = value);
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.server.settings.title");
  $$unsubscribe_selectedServer();
  $$unsubscribe__();
  $$unsubscribe_mainServer();
  return ` <div class="card animate__animated animate__fadeIn"><div class="card-body"><h5 class="card-title">${escape($selectedServer.name)} (${escape($selectedServer.host)}:${escape($selectedServer.port)})</h5> <div class="row mb-3"><label class="col-md-4 col-form-label" for="mainServer">${escape($_("pages.server.settings.main-server"))}</label> <div class="col col-form-label">${$selectedServer.id === $mainServer.id ? `<p class="mb-0 text-muted"><i class="fa-solid fa-check me-2"></i> ${escape($_("pages.server.settings.already-main-server", {
    values: { serverName: $selectedServer.name }
  }))}</p>` : `<a href="javascript:void(0);" class="btn btn-link ps-0"><i class="fa-solid fa-home me-2"></i> ${escape($_("pages.server.settings.make-main-server"))}</a> <small class="text-muted d-block">${escape($_("pages.server.settings.main-server-info"))}</small>`}</div></div> <div class="row py-3 rounded my-3 bg-danger bg-opacity-25"><label class="col-md-4 col-form-label" for="removeServer">${escape($_("pages.server.settings.remove-server"))}</label> <div class="col d-flex align-items-center"><a href="javascript:void(0);" class="btn btn-link link-danger ps-0"><i class="fa-solid fa-plug me-2"></i> ${escape($_("pages.server.settings.disconnect"))}</a></div></div></div></div> ${validate_component(MakeMainServerModal, "MakeMainServerModal").$$render($$result, {}, {}, {})} ${validate_component(RemoveServerModal, "RemoveServerModal").$$render($$result, {}, {}, {})}`;
});

export { ServerSettings as S };
//# sourceMappingURL=ServerSettings-B8IBeOOC.js.map
