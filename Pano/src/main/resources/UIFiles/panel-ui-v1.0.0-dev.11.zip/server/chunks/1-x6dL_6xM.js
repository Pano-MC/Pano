const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-kTRfs0_B.js')).default;
const imports = ["_app/immutable/nodes/1.yvxAX8-T.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/stores.BmoBeU7j.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-x6dL_6xM.js.map
