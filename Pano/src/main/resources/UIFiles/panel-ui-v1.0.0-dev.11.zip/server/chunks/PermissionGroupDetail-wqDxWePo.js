import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, d as add_attribute, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { A as ApiUtil } from './api.util-CzxmL1-R.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import './client-CnCRRyPd.js';
import './ToastContainer-CKzXwJro.js';

const Modes = Object.freeze({ EDIT: "edit", CREATE: "create" });
const DefaultMode = Modes.CREATE;
async function loadData({ id, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/permissionGroups/${id}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function loadPermissions({ request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({ path: "/api/panel/permissions", request }).then((body) => {
      if (body.result === "ok") {
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event, mode = DefaultMode) {
  const { parent } = event;
  await parent();
  let data = {
    id: -1,
    name: "",
    users: [],
    permissions: [],
    permissionGroupPerms: [],
    mode
  };
  if (mode === Modes.EDIT) {
    await loadData({ id: event.params.id, request: event }).then((body) => {
      data = { ...data, ...body };
    }).catch((body) => {
      if (body.error) {
        if (body.error === "NOT_EXISTS") {
          throw error(404, body.error);
        }
        throw error(500, body.error);
      }
    });
  }
  if (data !== null) {
    await loadPermissions({ request: event }).then((body) => {
      data = { ...data, ...body };
    });
    data.permissionList = data.permissions;
    data.permissions = data.permissionList.map((permission) => {
      return {
        id: permission.id,
        selected: data.name === "admin"
      };
    });
    if (data.name !== "admin") {
      data.permissionGroupPerms.forEach((permissionGroupPerm) => {
        data.permissions.forEach((permission) => {
          if (permission.id === permissionGroupPerm) {
            permission.selected = true;
          }
        });
      });
    }
    data.originalPermissions = [];
    data.permissions.forEach((permission) => {
      data.originalPermissions.push({ ...permission });
    });
    data.originalUsers = [];
    data.users.forEach((user) => {
      data.originalUsers.push(Object.freeze(user));
    });
  }
  return data;
}
function isPermissionListDifferent(originalPermissions, permissions) {
  let isDifferent = false;
  permissions.forEach((permission) => {
    const isSame = originalPermissions.filter((originalPermission) => originalPermission.id === permission.id && originalPermission.selected === permission.selected);
    if (isSame.length === 0) {
      isDifferent = true;
    }
  });
  return isDifferent;
}
const PermissionGroupDetail = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let saveButtonDisabled;
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set(data.mode === Modes.EDIT ? "pages.permission-group-detail.title-edit" : "pages.permission-group-detail.title-create");
  let errors = [];
  let name = data.name;
  let username = "";
  let addedUsers = [];
  let removedUsers = [];
  function isPermissionChecked(permission) {
    if (data.name === "admin") {
      return true;
    }
    const permissionChecked = data.permissions.filter((filteredPermission) => {
      return filteredPermission.selected && filteredPermission.id === permission.id;
    });
    return permissionChecked.length !== 0;
  }
  function isPermissionDisabled() {
    return data.name === "admin";
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  saveButtonDisabled = !name || data.name === name && !isPermissionListDifferent(data.originalPermissions, data.permissions) && addedUsers.length === 0 && removedUsers.length === 0;
  $$unsubscribe__();
  return `<article class="container"> <div class="row justify-content-between align-items-center mb-3 animate__animated animate__slideInUp"><div class="col-auto"><a class="btn btn-link" role="button" href="${escape(base, true) + "/players/perm-groups"}"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.permission-group-detail.permission-groups"))}</a></div> <div class="col-auto"><button class="${[
    "btn",
    (data.mode === Modes.CREATE ? "btn-secondary" : "") + " " + (data.mode === Modes.EDIT ? "btn-primary" : "") + " " + (saveButtonDisabled ? "disabled" : "")
  ].join(" ").trim()}" type="submit">${data.mode === Modes.EDIT ? `${escape($_("pages.permission-group-detail.save"))}` : `${escape($_("pages.permission-group-detail.create"))}`}</button></div></div> <div class="row"><div class="col mb-xl-0 mb-3"><div class="card h-100"><div class="card-body"><input class="${[
    "form-control form-control-lg mb-3",
    (errors.name ? "text-danger" : "") + " " + (!errors.name ? "text-black" : "")
  ].join(" ").trim()}"${add_attribute("placeholder", $_("pages.permission-group-detail.inputs.name.placeholder"), 0)} id="permissionGroupName" type="text" ${data.name === "admin" ? "disabled" : ""}${add_attribute("value", name, 0)}> <form><input class="${["form-control mb-3", ""].join(" ").trim()}" id="addPlayerInput" ${""}${add_attribute("placeholder", $_("pages.permission-group-detail.inputs.player.placeholder"), 0)}${add_attribute("value", username, 0)}></form> ${each(data.users, (user, index) => {
    return `<a href="javascript:void(0);"><span class="badge rounded-pill bg-light link-dark text-center"><img class="d-inline rounded-circle me-2" src="${"https://minotar.net/avatar/" + escape(user, true)}"${add_attribute("alt", user, 0)} width="28" height="28"> ${escape(user)}</span> </a>`;
  })}</div></div></div> <div class="col-xl-4"><div class="card"><div class="card-body"><table class="table table-sm table-hover mb-0"><tbody>${each(data.permissionList, (permission, index) => {
    return `<tr><th scope="col">    <small class="mb-0">${escape(permission.name)} </small></th> <td><div class="form-check form-switch d-flex justify-content-end align-content-center"><input type="checkbox" class="form-check-input"${add_attribute("id", permission.name, 0)} ${isPermissionChecked(permission) ? "checked" : ""} ${isPermissionDisabled() ? "disabled" : ""}> </div></td> </tr>`;
  })}</tbody></table></div></div></div></div> </article>`;
});

export { Modes as M, PermissionGroupDetail as P, load as l };
//# sourceMappingURL=PermissionGroupDetail-wqDxWePo.js.map
