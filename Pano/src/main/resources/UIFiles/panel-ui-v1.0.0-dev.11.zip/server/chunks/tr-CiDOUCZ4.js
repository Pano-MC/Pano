const buttons = {
  remove: "Kaldır",
  connect: "Bağla",
  connecting: "Bağlanıyor...",
  close: "Kapat",
  yes: "Evet",
  cancel: "İptal",
  download: "İndir"
};
const pages = {
  dashboard: {
    title: "Panel",
    "welcome-card": {
      description: "Pano başarıyla kuruldu ve kullanıma hazır. 🚀 <br /> İşte başlarken yapabileceklerin:",
      "connect-server": "Sunucu Bağla",
      "connect-server-description": "Oyun sunucunu bağla ve daha fazla yönetim özelliklerine eriş.",
      "menu-title": "Menü",
      "links-title": "Bağlantılar",
      "publish-your-first-post": "İlk Yazıyı Yayınla",
      "change-theme": "Tema Görünümünü Değiştir",
      "manage-addons": "Eklentleri Yönet",
      "manage-players": "Oyuncuları Yönet",
      "themes-and-extensions": "Temalar ve Eklentiler",
      documentations: "Dokümantasyon",
      website: "Website",
      discord: "Discord",
      "close-button": "Kapat"
    },
    "last-tickets": {
      title: "Son Talepler",
      "player-name": "Oyuncu Adı",
      view: "Görüntüle",
      filter: "Filtrele",
      "no-category": "Kategorisiz"
    }
  },
  statistics: {
    title: "İstatistikler",
    "online-player-text": "{onlinePlayerCount} Sitede Çevrimiçi",
    "new-register-text": "{newRegisterCount} Yeni Kayıt",
    "total-player-text": "{totalPlayerCount} Toplam Oyuncu",
    "website-graph": {
      title: "Website Aktivitesi",
      week: "Hafta",
      month: "Ay"
    },
    "total-statistics": {
      title: "İstatistik",
      posts: "Yazılar:",
      players: "Oyuncular:",
      admins: "Yöneticiler:",
      tickets: "Talepler:",
      "connected-servers": "Sunucular:",
      addons: "Eklentiler:",
      themes: "Temalar:"
    }
  },
  players: {
    title: "{pageType}Oyuncular",
    authorized: "Yetkili",
    banned: "Yasaklı",
    "perm-groups": "Yetki Grupları",
    "table-title": "{playerCount} {pageType} Oyuncu",
    all: "Tümü",
    table: {
      name: "Kullanıcı Adı",
      permission: "Yetki",
      status: "Durum",
      "last-entrance": "Son Giriş",
      "register-date": "Kayıt"
    }
  },
  posts: {
    title: "{pageType}Yazılar",
    published: "Yayınlanmış",
    draft: "Taslak",
    trash: "Çöp",
    "table-title": "{postCount} {pageType} Yazı",
    "post-categories-button": "Kategoriler",
    "create-post-button": "Yazı Oluştur",
    table: {
      title: "Başlık",
      category: "Kategori",
      views: "Görüntülenme",
      author: "Yazar",
      "last-update": "Son Güncellenme"
    }
  },
  tickets: {
    title: "{pageType}Talepler",
    "waiting-reply": "Yanıt Bekleyen",
    closed: "Kapalı",
    "ticket-categories": "Talep Kategorileri",
    "close-ticket-button": "Talebi Kapat",
    "table-title": "{ticketCount} {pageType} Talep",
    "amount-selected": "{amount} adet seçildi.",
    all: "Tümü",
    "select-all": "Tümünü Seç",
    table: {
      title: "Başlık",
      player: "Oyuncu",
      category: "Kategori",
      status: "Durum",
      "last-reply": "Son Yanıt"
    }
  },
  notifications: {
    title: "Bildirimler",
    "delete-all": "Tümünü Sil",
    "delete-notification": "Bildirimi Sil",
    "show-more": "Daha Fazla Göster ({count})"
  },
  settings: {
    about: {
      title: "Hakkında",
      version: "Versiyon",
      release: "Sürüm",
      website: "Website",
      discord: "Discord",
      "open-source-licenses": "Açık Kaynak Lisanslar"
    },
    "site-settings": {
      title: "Website Ayarları",
      preferences: "Tercihler",
      inputs: {
        "website-name": {
          label: "Site İsmi",
          placeholder: "İsim"
        },
        "website-description": {
          label: "Site Açıklaması"
        },
        "game-server-ip-address": {
          label: "Oyun Sunucu IP Adresi"
        },
        "game-server-version": {
          label: "Oyun Sunucu Versiyonu"
        },
        "support-email-address": {
          label: "Destek E-Posta Adresi"
        },
        keywords: {
          label: "Anahtar Kelimeler",
          placeholder: "Eklemek için Enter'a basın",
          remove: "Kaldırmak İçin Tıkla"
        },
        favicon: {
          label: "Favicon",
          select: "Seç",
          helper: "PNG, ICO, GIF, JPG, SVG formatında, maksimum 1 mb ve 16x16 piksel olmalı."
        },
        "website-logo": {
          label: "Website Logo",
          "server-icon": "Sunucu İkonu",
          helper: "PNG, JPEG, GIF, SVG formatında, maksimum 2 mb olmalı."
        }
      },
      "save-button": "Kaydet"
    },
    platform: {
      title: "Platform Ayarları",
      preferences: "Tercihler",
      "display-language": "Görüntüleme Dili",
      "check-auto-updates": "Platform Updates",
      "connect-failed-alert": "Pano hesabınıza bağlanırken hata oluştu! Lütfen tekrar deneyin.",
      account: "Hesap",
      "platform-id": "Platform ID",
      user: "Kullanıcı",
      "online-account": "Çevrimiçi Hesap",
      "online-account-description": "Eklenti, tema ve güncellemelere erişebilmek için çevrimiçi Pano hesabınızı bağlayın.",
      inputs: {
        "check-auto-updates": {
          never: "Asla",
          "once-in-a-day": "Günde Bir Kez",
          "once-in-a-week": "Haftada Bir Kez",
          "once-in-a-month": "Ayda Bir Kez"
        }
      },
      smtp: {
        username: "Kullanıcı Adı (Adres)",
        password: "Şifre",
        ssl: "SSL Kullan",
        "tls-setting": "TLS Ayarı",
        "sender-address": "Gönderici Adresi",
        hostname: "Sağlayıcı Adresi",
        port: "Port",
        "auth-methods": "Giriş Methodu",
        description: "Pano, e-posta gönderebilmek için bir e-posta sağlayıcısına ihtiyaç duyar. Lütfen kullanmak istediğiniz e-posta servisi ile oturum açın.",
        "email-validation-error": "E-mail ayarlarınız doğrulanamadı: {mailError}"
      },
      "smtp-settings": "E-Mail Ayarları (SMTP)",
      "save-button": "Kaydet"
    }
  },
  "ticket-detail": {
    tickets: "Talepler",
    "close-ticket": "Talebi Kapat",
    "by-who": "{username} tarafından,",
    "opened-in-category": "{category} kategorisinde açıldı.",
    "no-category": "Kategorisiz",
    "previous-messages": "Önceki Mesajlar ({count})",
    "send-button": "Gönder"
  },
  "post-categories": {
    title: "Yazı Kategorileri",
    posts: "Yazılar",
    "create-category-button": "Kategori Oluştur",
    "card-title": "{count} Yazı Kategorisi",
    category: "Kategori",
    description: "Açıklama",
    url: "URL",
    color: "Renk"
  },
  "ticket-categories": {
    title: "Talep Kategorileri",
    tickets: "Talepler",
    "create-category-button": "Kategori Oluştur",
    "card-title": "{count} Talep Kategorisi",
    category: "Kategori",
    description: "Açıklama"
  },
  "permission-groups": {
    title: "Yetki Grupları",
    players: "Oyuncular",
    "create-permission-group-button": "Yetki Grubu Oluştur",
    "card-title": "{count} Yetki Grubu",
    name: "İsim",
    "permission-amount": "Yetki Adeti",
    "player-amount": "Oyuncu Adeti"
  },
  error: {
    title: "Hata: {status}",
    "go-back": "Geri Git"
  },
  "post-editor": {
    posts: "Yazılar",
    trash: "Çöp",
    "move-to-drafts": "Taslaklara Taşı",
    view: "Görüntüle",
    save: "Kaydet",
    update: "Güncelle",
    publish: "Yayınla",
    inputs: {
      title: {
        placeholder: "Yazı başlığını girin"
      }
    },
    status: "Durum:",
    views: "Görüntülenme:",
    category: "Kategori:",
    "no-category": "Kategorisiz",
    thumbnail: "Küçük Resim:",
    clear: "Temizle",
    add: "Ekle",
    change: "Değiştir",
    "thumbnail-not-determined": "Küçük resim belirlenmedi.",
    "title-create": "Yeni Yazı Oluştur",
    "title-edit": "Yazıyı Düzenle",
    "new": "Yeni",
    draft: "Taslak",
    published: "Yayınlanmış"
  },
  "category-tickets": {
    title: '"{category}" Talepler',
    "no-category": "Kategorisiz",
    tickets: "Talepler",
    "delete": "Sil",
    "close-ticket": "Talebi Kapat",
    "table-title": "{ticketCount} Talep",
    "amount-selected": "{amount} adet seçildi.",
    table: {
      title: "Başlık",
      status: "Durum",
      category: "Kategori",
      player: "Oyuncu",
      "last-reply": "Son Yanıt"
    }
  },
  "category-posts": {
    title: '"{category}" Yazılar',
    "no-category": "Kategorisiz",
    posts: "Yazılar",
    "create-post": "Yazı Oluştur",
    "table-title": "{count} Yazı",
    table: {
      title: "Başlık",
      category: "Kategori",
      author: "Yazar",
      views: "Görüntülenme",
      date: "Tarih"
    },
    server: {
      dashboard: {
        title: "Sunucu İstatistikleri",
        "server-status": "Sunucu {status}",
        online: "Çevrimiçi",
        offline: "Çevrimdışı",
        player: "{playerCount}/{maxPlayerCount} Oyuncu",
        "working-time": "Çalışma Süresi: {upTime}",
        "last-online": "Son Aktif Zamanı: ",
        statistics: "İstatistik",
        "server-name": "Sunucu İsmi:",
        "server-type": "Sunucu Türü:",
        "local-ip-address": "Yerel IP Adresi:",
        "server-version": "Sunucu Sürümü:",
        "total-connected-servers": "Toplam Bağlı Sunucular:",
        "date-added": "Eklenme Zamanı:"
      },
      settings: {
        title: "Sunucu Ayarları",
        "main-server": "Ana Sunucu",
        "already-main-server": "{serverName} ana sunucu",
        "make-main-server": "Ana Sunucu Olarak Belirle",
        "main-server-info": "Websitede görüntülenecek sunucu bilgilerini ana sunucu belirler.",
        "remove-server": "Sunucuyu Kaldır",
        disconnect: "Bağlantıyı Kes"
      }
    }
  },
  server: {
    dashboard: {
      title: "Sunucu İstatistikleri",
      "server-status": "Sunucu {status}",
      online: "Çevrimiçi",
      offline: "Çevrimdışı",
      player: "{playerCount}/{maxPlayerCount} Oyuncu",
      "working-time": "Çalışma Süresi: {upTime}",
      "last-online": "Son Aktif Zamanı: ",
      statistics: "İstatistik",
      "server-name": "Sunucu İsmi:",
      "server-type": "Sunucu Türü:",
      "local-ip-address": "Yerel IP Adresi:",
      "server-version": "Sunucu Sürümü:",
      "total-connected-servers": "Toplam Bağlı Sunucular:",
      "date-added": "Eklenme Zamanı:"
    },
    settings: {
      title: "Sunucu Ayarları",
      "main-server": "Ana Sunucu",
      "already-main-server": "{serverName} ana sunucu",
      "make-main-server": "Ana Sunucu Belirle",
      "main-server-info": "Websitede görüntülenecek sunucu bilgilerini ana sunucu belirler.",
      "remove-server": "Sunucuyu Kaldır",
      disconnect: "Bağlantıyı Kes"
    },
    monitoring: {
      title: "Sunucu İzleme"
    }
  },
  "players-by-permission-group": {
    title: '"{permissionGroupName}" Yetkili Oyuncular',
    player: "Oyuncu",
    players: "Oyuncular",
    "table-title": "{count} Oyuncu",
    table: {
      player: "Oyuncu",
      "permission-group": "Yetki",
      status: "Durum",
      "last-login": "Son Oturum",
      "register-date": "Kayıt"
    }
  },
  "permission-group-detail": {
    "title-edit": "Yetki Grubunu Düzenle",
    "title-create": "Yetki Grubu Oluştur",
    "permission-groups": "Yetkiler",
    save: "Kaydet",
    create: "Oluştur",
    inputs: {
      name: {
        placeholder: "İsim"
      },
      player: {
        placeholder: "Oyuncu ekle..."
      }
    },
    remove: "Kaldır"
  },
  "player-detail": {
    players: "Oyuncular",
    "delete": "Sil",
    "un-ban": "Yasağı Kaldır",
    ban: "Yasakla",
    "send-verification-mail": "Oyuncu e-postasına bir doğrulama bağlantısı gönder",
    authorize: "Yetkilendir",
    edit: "Düzenle",
    "in-game": "Oyunda",
    "in-website": "Sitede",
    "online-text": "{whereOnline} Çevrimiçi",
    banned: "Yasaklı",
    "last-tickets": "Son Talepler",
    view: "Görüntüle",
    filter: "Filtrele",
    "no-category": "Kategorisiz",
    statistics: "İstatistikler",
    email: "E-Posta",
    "email-verified": "Doğrulandı",
    "email-not-verified": "Doğrulanmadı",
    "last-entrance": "Son Giriş",
    "register-date": "Kayıt"
  }
};
const components = {
  "ticket-status-badge": {
    filter: "Filtrele",
    "new": "Yeni",
    replied: "Yanıtlandı",
    closed: "Kapalı"
  },
  "website-activity-chart": {
    "new-registration": "Yeni Kayıt",
    "new-ticket": "Yeni Talep",
    visitor: "Ziyaretçi",
    view: "Görüntülenme"
  },
  "site-navigation-menu": {
    panel: "Panel",
    statistics: "İstatistikler",
    posts: "Yazılar",
    tickets: "Talepler",
    players: "Oyuncular",
    view: "Görünüm",
    addons: "Eklentiler",
    settings: "Ayarlar"
  },
  navbar: {
    "navbar-toggle-tooltip": "Menüyü Aç/Kapa",
    notifications: "Bildirimler",
    "show-all": "Tümünü Görüntüle",
    "account-dropdown": {
      session: "Oturum",
      profile: "Profil",
      logout: "Çıkış Yap"
    }
  },
  sidebar: {
    "sidebar-toggle-tooltip": "Menüyü Aç/Kapa",
    website: "Website",
    server: "Sunucu",
    "show-website": "Website",
    "show-servers": "Sunucular"
  },
  "server-navigation-menu": {
    statistics: "İstatistikler",
    monitoring: "İzleme",
    settings: "Ayarlar",
    "no-selected-server": "Seçili sunucu yok.",
    "no-server-text": "Sunucu menüsünü görüntülemek için bir sunucu bağla.",
    "connect-server": "Sunucu Bağla"
  },
  "post-row": {
    actions: "Eylemler",
    view: "Görüntüle",
    "move-to-draft": "Taslaklara Taşı",
    publish: "Yayınla",
    "move-to-trash": "Çöp Kutusuna Taşı",
    "delete": "Sil",
    edit: "Düzenle",
    "no-category": "Kategorisiz",
    filter: "Filtrele"
  },
  "ticket-row": {
    select: "Seç",
    view: "Görüntüle",
    filter: "Filtrele",
    "no-category": "Kategorisiz",
    "player-name": "Oyuncu Adı"
  },
  "player-row": {
    actions: "Eylemler",
    authorize: "Yetkilendir",
    edit: "Düzenle",
    "remove-ban": "Yasağı Kaldır",
    ban: "Yasakla",
    view: "Görüntüle"
  },
  "player-status-badge": {
    banned: "Yasaklı",
    "in-game": "Oyunda",
    "in-website": "Sitede",
    online: "Çevrimiçi",
    offline: "Çevrimdışı"
  },
  "player-permission-badge": {
    filter: "Filtrele",
    player: "Oyuncu"
  },
  bottom: {
    help: "Yardım",
    "pano-market": "Pano Market",
    discord: "Discord"
  },
  "notification-container": {
    notification: "Bildirim"
  },
  "settings-layout": {
    website: "Website",
    platform: "Platform",
    updates: "Güncellemeler",
    about: "Hakkında"
  },
  "server-settings-layout": {
    server: "Sunucu",
    "game-integration": "Oyun Entegrasyonu"
  },
  modals: {
    "confirm-remove-pano-account": {
      title: "Çevrimiçi Pano hesabınızı platformdan kaldırmak istediğinize emin misiniz?"
    },
    "add-edit-post-category": {
      "create-category": "Kategori Oluştur",
      "edit-category": "Kategoriyi Düzenle",
      close: "Kapat",
      inputs: {
        title: {
          placeholder: "Başlık"
        },
        description: {
          placeholder: "Açıklama"
        },
        url: {
          placeholder: "URL",
          helper: "Yanlızca [A-Z/a-z/0-9/-] içerebilir ve minimum 3, maksimum 32 karkater olabilir."
        }
      },
      save: "Kaydet",
      create: "Oluştur"
    },
    "add-edit-ticket-category": {
      "create-category": "Kategori Oluştur",
      "edit-category": "Kategoriyi Düzenle",
      close: "Kapat",
      inputs: {
        title: {
          placeholder: "Başlık"
        },
        description: {
          placeholder: "Açıklama"
        }
      },
      save: "Kaydet",
      create: "Oluştur"
    },
    "authorize-player": {
      title: "Oyuncuyu Yetkilendir",
      close: "Kapat",
      player: "Oyuncu",
      save: "Kaydet"
    },
    "confirm-ban-player": {
      title: "Bu oyuncuyu yasaklamak istediğinizden emin misiniz?",
      "notify-with-email": "E-posta ile bilgilendir",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-close-ticket": {
      "title-single": "Bu talebi kapatmak istediğinizden emin misiniz?",
      "title-multi": "Bu talepleri kapatmak istediğinizden emin misiniz?",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-permission-group": {
      title: "Bu yetki grubunu kalıcı olarak silmek istediğinizden emin misiniz?",
      description: "Yetki grubu içerisindeki şu kullanıcılar Oyuncu olarak değişecek:",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-player": {
      title: "Bu oyuncuyu gerçekten silmek istediğinizden emin misiniz?",
      inputs: {
        password: {
          placeholder: "Şifre"
        }
      },
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-post-category": {
      title: "Bu kategoriyi kalıcı olarak silmek istediğinizden emin misiniz?",
      description: "Kategori içerisindeki şu yazılar Kategorisiz olarak değişecek:",
      "more-posts": "+{count} yazı daha",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-post": {
      "title-permanent": "Bu yazıyı kalıcı olarak silmek istediğinizden emin misiniz?",
      "title-trash": "Bu yazıyı çöp kutusuna taşımak istediğinizden emin misiniz?",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-ticket-category": {
      "title-permanent": "Not: Eğer bu kategoriyi silerseniz, şu talepler Kategorisiz olarak kalacaklardır:",
      title: "Bu kategoriyi kalıcı olarak silmek istediğinizden emin misiniz?",
      "more-tickets": "+{count} talep daha",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-disable-addon-will-cause-more-disable": {
      title: '"{pluginId}" eklentisini devre dışı bırakmak istediğinizden emin misiniz?',
      description: '"{pluginId}" eklentisini devre dışı bırakmak bu eklentileri de devre dışı bırakacaktır:',
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-enabling-addon-will-cause-more-enable": {
      title: '"{pluginId}" eklentisini ektinleştirmek istediğinizden emin misiniz?',
      description: '"{pluginId}" eklentisini etkinleştirmek bu eklentileri de etkinleştirecektir:',
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-delete-ticket": {
      "title-single": "Bu talebi kalıcı olarak silmek istediğinizden emin misiniz?",
      "title-multi": "Bu talepleri kalıcı olarak silmek istediğinizden emin misiniz?",
      cancel: "İptal",
      yes: "Evet"
    },
    "confirm-remove-all-notifications": {
      title: "Tüm bildirimleri kalıcı olarak silmek istediğinizden emin misiniz?",
      cancel: "İptal",
      yes: "Evet"
    },
    "connect-server": {
      title: "Sunucu Bağla",
      close: "Kapat",
      steps: {
        "1": "Oyun Eklentisini Sunucuna Kur",
        "2": "Bağlantı Komutunu Çalıştır",
        "3": "Bağlantı İsteğini Onayla"
      },
      download: "Dosyayı İndir",
      copy: "Kopyala",
      copied: "Kopyalandı!",
      "code-refresh": "Kod {timeToRefreshKey} saniye sonra yenilenecek.",
      "notification-will-come": "Bağlantı isteği bildirim olarak gelecek."
    },
    "make-main-server": {
      title: '"{serverName}" sunucusunu ana sunucu yapmak istediğinizden emin misiniz?',
      no: "Hayır",
      yes: "Evet"
    },
    "remove-server": {
      title: "Bu sunucuyu kaldırmak istediğinizden emin misiniz?",
      "account-password": "Hesap Şifresi",
      cancel: "İptal",
      yes: "Evet"
    },
    "server-request": {
      title: '"{serverName}" sunucusunu platforma bağlamak istediğinizden emin misiniz?',
      reject: "Reddet",
      connect: "Bağla"
    },
    servers: {
      "connect-server-button": "Sunucu Bağla",
      servers: "Sunucular",
      close: "Kapat",
      "main-server": "Ana Sunucu",
      online: "Çevrimiçi"
    },
    "unban-player": {
      title: "Bu oyuncunun yasağını kaldırmak istediğinizden emin misiniz?",
      cancel: "İptal",
      yes: "Evet"
    },
    "edit-player": {
      title: "Oyuncu Bilgilerini Düzenle",
      close: "Kapat",
      inputs: {
        username: {
          placeholder: "Kullanıcı Adı",
          errors: {
            invalid: "Kullanıcı Adı geçerli değil.",
            exists: "Bu kullanıcı adı başka bir oyuncu tarafından kullanılıyor."
          }
        },
        email: {
          title: "E-Posta",
          errors: {
            invalid: "E-Posta geçerli değil",
            exists: "Bu E-Posta adresi başka bir oyuncu tarafından kullanılıyor"
          }
        },
        "new-password": {
          title: "Yeni Şifre",
          errors: {
            invalid: "Yeni şifre minimum 6 maksimum 128 karakterden oluşmalıdır"
          }
        },
        "new-password-repeat": {
          title: "Yeni Şifre Tekrarı",
          errors: {
            "not-match": "Şifreler aynı değil"
          }
        },
        "can-open-ticket": "Talep oluşturabilir",
        "email-verified": "E-Postası doğrulandı"
      },
      save: "Kaydet"
    }
  },
  editor: {
    title: "Başlık {number}",
    bold: "Kalın",
    italic: "İtalik",
    underline: "Altı Çizili",
    strike: "Üstü Çizili",
    "bullet-list": "Liste",
    "ordered-list": "Sıralı Liste",
    image: "Resim",
    link: "Bağlantı",
    "text-color": "Yazı Rengi",
    "remove-text-color": "Yazı Rengini Kaldır"
  },
  "no-content": {
    "here-is-empty": "Burası boş."
  },
  pagination: {
    "previous-page": "Önceki Sayfa",
    "next-page": "Sonraki Sayfa"
  },
  splash: {
    errors: {
      session: "Oturum hatası",
      permission: "Yetki hatası",
      connection: "Bağlantı hatası"
    },
    refreshing: "Yenileniyor...",
    refresh: "Yenile"
  },
  "permission-group-row": {
    "delete": "Sil",
    edit: "Düzenle"
  },
  "post-category-row": {
    "delete": "Sil",
    edit: "Düzenle",
    view: "Görüntüle"
  },
  "ticket-category-row": {
    "delete": "Sil",
    edit: "Düzenle"
  },
  toasts: {
    "accepted-server-connect-request": "Sunucu bağlantı isteği kabul edildi.",
    "expired-server-connect-request": "Geçersiz sunucu bağlantı isteği.",
    "notifications-deleted-permanently": "Tüm bildirimler silindi.",
    "permission-group-saved-or-created": {
      "permission-group": "Yetki grubu {event}",
      updated: "güncellendi.",
      saved: "kaydedildi."
    },
    "permission-group-save-error": "Yetki grubu kaydedilemedi! Hata: {errorCode}",
    "player-authorized-success": "Oyuncu yetkisi güncellendi.",
    "player-ban": {
      "the-player": '"{username}" kullanıcısı {event}',
      banned: "yasaklandı.",
      "could-not-ban": "yasaklanamadı, hata: {error}"
    },
    "player-deleted-success": 'Oyuncu "{username}" silindi.',
    "player-info-saved-success": "Oyuncu bilgileri güncellendi.",
    "player-unban": {
      "the-player": '"{username}" kullanıcısının {event}',
      "removed-ban": "yasağı kaldırıldı.",
      "could-not-remove-ban": "yasağı kaldırılamadı, hata: {error}"
    },
    "post-category-deleted-permanently": '"{title}" kalıcı olarak silindi.',
    "post-deleted-permanently": '"{title}" kalıcı olarak silindi.',
    "post-moved-to-draft": '"{title}" taslaklara taşındı.',
    "post-moved-to-trash": '"{title}" çöpe taşındı.',
    "post-published": '"{title}" yayınlandı.',
    "post-saved": '"{title}" kaydedildi.',
    "rejected-server-connect": "Sunucu bağlantı isteği reddedildi.",
    "server-deleted-success": '"{name}" sunucu silindi.',
    "server-made-main": '"{name}" ana sunucu olarak belirlendi.',
    "server-not-exists": "Sunucu bulunamadı.",
    "server-selected": '"{name}" seçildi.',
    "settings-save-error": "Ayarlar kaydedilemedi! Hata: {errorCode}",
    "settings-save-success": "Ayarlar kaydedildi.",
    "ticket-category-deleted-permanently": '"{title}" kalıcı olarak silindi.',
    "ticket-closed": {
      multi: "{count} talep kapatıldı.",
      single: "Talep kapatıldı."
    },
    "tickets-deleted-permanently": {
      multi: "{count} talep kalıcı olarak silindi.",
      single: "Talep kalıcı olarak silindi."
    },
    "verification-email-sent-error": '"{username}" kullanıcısına doğrulama e-mail gönderilemedi. Hata: {errorCode}',
    "verification-email-sent-successful": `"{username}" kullanıcısına doğrulama e-mail'i gönderildi.`,
    "enabling-addon-failed-by-dependency-error": '"{addon}" eklentisi bağımlı eklenti hatası sebebiyle etkinleştirilemedi!',
    "failed-to-enable-addon-error": '"{addon}" eklentisi etkinleştirilemedi. Eklenti hatalarını kontrol edin!',
    "pano-account-connect-success": "Pano hesabın başarıyla bağlandı!",
    "pano-account-disconnect-success": "Pano hesabı başarıyla kaldırıldı!",
    "pano-account-disconnect-fail": "Pano hesabı kaldırılırken hata oluştu!",
    "email-config-validate-success": "E-Mail başarıyla doğrulandı!"
  }
};
const tr = {
  buttons,
  pages,
  components,
  "page-error": {
    "404": "Enderman bu sayfanın yüklenmesini engelledi."
  }
};

export { buttons, components, tr as default, pages };
//# sourceMappingURL=tr-CiDOUCZ4.js.map
