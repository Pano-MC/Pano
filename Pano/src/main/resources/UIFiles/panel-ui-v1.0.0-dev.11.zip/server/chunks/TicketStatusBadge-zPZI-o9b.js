import { c as create_ssr_component, a as subscribe, e as escape, d as add_attribute } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';

const TicketStatuses = Object.freeze({
  NEW: "NEW",
  REPLIED: "REPLIED",
  CLOSED: "CLOSED"
});
const TicketStatusBadge = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { status = TicketStatuses.NEW } = $$props;
  if ($$props.status === void 0 && $$bindings.status && status !== void 0) $$bindings.status(status);
  $$unsubscribe__();
  return `${status === TicketStatuses.NEW ? `<a href="${escape(base, true) + "/tickets/waitingReply"}"><span class="badge rounded-pill text-bg-success"${add_attribute("title", $_("components.ticket-status-badge.filter"), 0)}>${escape($_("components.ticket-status-badge.new"))}</span></a>` : `${status === TicketStatuses.REPLIED ? `<a href="${escape(base, true) + "/tickets"}"><span class="badge rounded-pill text-bg-warning"${add_attribute("title", $_("components.ticket-status-badge.filter"), 0)}>${escape($_("components.ticket-status-badge.replied"))}</span></a>` : `${status === TicketStatuses.CLOSED ? `<a href="${escape(base, true) + "/tickets/closed"}"><span class="badge rounded-pill text-bg-danger"${add_attribute("title", $_("components.ticket-status-badge.filter"), 0)}>${escape($_("components.ticket-status-badge.closed"))}</span></a>` : ``}`}`}`;
});

export { TicketStatusBadge as T, TicketStatuses as a };
//# sourceMappingURL=TicketStatusBadge-zPZI-o9b.js.map
