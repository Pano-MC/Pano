import { l as load } from './TicketCategories-1RGEympY.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-DEJKHSTp.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 59;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DfkPXo8r.js')).default;
const universal_id = "src/routes/tickets/categories/+page.js";
const imports = ["_app/immutable/nodes/59.pBMPp8ey.js","_app/immutable/chunks/TicketCategories.B-bkEqR_.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/Pagination.BMy40NEt.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/NoContent.CnBreury.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=59-BhY1sCTx.js.map
