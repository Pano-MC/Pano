import { c as create_ssr_component, a as subscribe, i as createEventDispatcher, d as add_attribute, h as each, e as escape } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';

const Pagination = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  createEventDispatcher();
  let pages;
  let { page } = $$props;
  let { totalPage = 1 } = $$props;
  if ($$props.page === void 0 && $$bindings.page && page !== void 0) $$bindings.page(page);
  if ($$props.totalPage === void 0 && $$bindings.totalPage && totalPage !== void 0) $$bindings.totalPage(totalPage);
  {
    {
      pages = [];
      for (let i = 1; i <= totalPage; i++) {
        pages.push(i);
      }
    }
  }
  $$unsubscribe__();
  return `<nav class="pt-3"><ul class="pagination pagination-sm mb-0 justify-content-start"><li class="${["page-item", parseInt(page) === 1 ? "disabled" : ""].join(" ").trim()}"><a class="page-link" href="javascript:void(0);"${add_attribute("title", $_("components.pagination.previous-page"), 0)}${add_attribute("aria-hidden", parseInt(page) === 1, 0)}><i class="fa-solid fa-caret-left"></i></a></li> ${each(pages, (index) => {
    return `<li class="${["page-item", parseInt(page) === index ? "active" : ""].join(" ").trim()}"${add_attribute("aria-current", parseInt(page) === index ? "page" : "", 0)}><a class="page-link" href="javascript:void(0);"${add_attribute("aria-hidden", parseInt(page) === index, 0)}>${escape(index)}</a> </li>`;
  })} <li class="${["page-item", parseInt(page) === totalPage ? "disabled" : ""].join(" ").trim()}"><a class="page-link" href="javascript:void(0);"${add_attribute("title", $_("components.pagination.next-page"), 0)}${add_attribute("aria-hidden", parseInt(page) === totalPage, 0)}><i class="fa-solid fa-caret-right"></i></a></li></ul> </nav>`;
});

export { Pagination as P };
//# sourceMappingURL=Pagination-DWomX__u.js.map
