import { l as load$1, M as Modes } from './PostEditor-CaUKa1Av.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-DEJKHSTp.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CmEWUnXW.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';

async function load(params) {
  return load$1(params, Modes.CREATE);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 38;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DLaqNf9q.js')).default;
const universal_id = "src/routes/posts/create-post/+page.js";
const imports = ["_app/immutable/nodes/38.GO908mAw.js","_app/immutable/chunks/PostEditor.D2EbsWVg.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/ConfirmDeletePostModal.BRUkkBXg.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/AddEditPostCategoryModal.Dia0Wu0Q.js","_app/immutable/chunks/Editor.DFfdfwXG.js","_app/immutable/chunks/PostPublishedToast.BYcVJ6S9.js","_app/immutable/chunks/NoContent.CnBreury.js","_app/immutable/chunks/PageActions.aH27r9KG.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=38-C-oit8Xs.js.map
