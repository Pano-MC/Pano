import { l as load$1, P as PageTypes } from './Players-CHtx8ZY_.js';
import './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-DEJKHSTp.js';
import './index-DzcLzHBX.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import './PlayerRow-Dn-RjN1r.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';
import './PlayerPermissionBadge-ByW5q93g.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardFilters-C1uMKg14.js';

async function load(params) {
  return load$1(params, PageTypes.BANNED);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 21;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-9XLI3Vn5.js')).default;
const universal_id = "src/routes/players/banned/+page.js";
const imports = ["_app/immutable/nodes/21.84PoIef2.js","_app/immutable/chunks/Players.gYRJTZh8.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/Pagination.BMy40NEt.js","_app/immutable/chunks/AuthorizePlayerModal.z64v0Zxw.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/UnbanPlayerModal.CGmpjurE.js","_app/immutable/chunks/PlayerRow.DBVTOnkD.js","_app/immutable/chunks/Date.CLWAlcbL.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/language.util.CsWrTcNn.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/PlayerPermissionBadge.DquWwTDK.js","_app/immutable/chunks/auth.util.DzfmAorF.js","_app/immutable/chunks/NoContent.CnBreury.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.CawhLpLy.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=21-D37HQpaA.js.map
