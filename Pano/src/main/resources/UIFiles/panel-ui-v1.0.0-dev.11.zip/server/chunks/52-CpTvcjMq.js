import { c as create_ssr_component, a as subscribe, f as getContext, e as escape } from './ssr-ffuobYCI.js';
import { A as ApiUtil } from './api.util-DEJKHSTp.js';
import { $ as $format } from './runtime-DMBi37QM.js';

async function loadData({ request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: "/api/panel/settings/about",
      request
    }).then((body) => {
      if (body.result === "ok") {
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = { platformVersion: "", platformStage: "" };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({ request: event }).then((body) => {
    data = { ...data, ...body };
  });
  return data;
}
const About = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.settings.about.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <div class="card"><div class="card-body"><h5 class="card-title" data-svelte-h="svelte-1apllct">Pano Platform Info</h5> <form class="animate__animated animate__fadeIn"><div class="row"><label class="col-md-6 col-form-label" for="panoVersion">${escape($_("pages.settings.about.version"))}</label> <div class="col-md-6 col-form-label"><span aria-describedby="panoVersion" id="panoVersion">${escape(data.platformVersion)}</span></div></div> <div class="row"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.release"))}</label> <div class="col-md-6 col-form-label"><span aria-describedby="panoRelease" id="panoRelease">${escape(data.platformStage)}</span></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.website"))}</label> <div class="col-md-6 col-form-label" data-svelte-h="svelte-lzupp9"><a aria-describedby="panoWebsite" href="https://panomc.com" id="panoWebsite" target="_blank">panomc.com <i class="fa-solid fa-up-right-from-square ms-2"></i></a></div></div> <div class="row mb-0"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.about.discord"))}</label> <div class="col-md-6 col-form-label" data-svelte-h="svelte-1hk5uv9"><a aria-describedby="panoWebsite" href="https://panomc.com/discord" id="panoWebsite" target="_blank">panomc.com/discord <i class="fa-solid fa-up-right-from-square ms-2"></i></a></div></div></form></div></div> <div class="card"><div class="card-body animate__animated animate__fadeIn"><h5 class="card-title animate__animated animate__heartBeat animate__slower d-inline-block">${escape($_("pages.settings.about.open-source-licenses"))} ❤️</h5>  <details data-svelte-h="svelte-16hhkyh"><summary class="h6 text-primary">Title</summary> <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia quisquam
        assumenda dolor eligendi fugit, architecto ab vero possimus minus
        consequatur delectus aut quam voluptatem debitis ullam ea voluptate
        inventore rem!</p></details></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 52;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BwtZaYQ6.js')).default;
const universal_id = "src/routes/settings/about/+page.js";
const imports = ["_app/immutable/nodes/52.BCwwFHBO.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/runtime.D7rGe2l5.js"];
const stylesheets = [];
const fonts = [];

var _52 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { About as A, _52 as _ };
//# sourceMappingURL=52-CpTvcjMq.js.map
