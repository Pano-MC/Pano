import { c as create_ssr_component, a as subscribe, h as each, v as validate_component, m as missing_component } from './ssr-ffuobYCI.js';
import { w as writable } from './index2-Dyghn50Q.js';

const toasts = writable([]);
Array.prototype.insert = function(index, item) {
  this.splice(index, 0, item);
  return this;
};
Array.prototype.remove = function(index) {
  this.splice(index, 1);
  return this;
};
const ToastContainer = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $toasts, $$unsubscribe_toasts;
  $$unsubscribe_toasts = subscribe(toasts, (value) => $toasts = value);
  $$unsubscribe_toasts();
  return `<div class="toast-container position-fixed bottom-0 start-50 translate-middle-x mb-3">${each($toasts, (toast, index) => {
    return `${validate_component(toast.component || missing_component, "svelte:component").$$render($$result, Object.assign({}, { id: toast.id }, toast.params), {}, {})}`;
  })} </div>`;
});

export { ToastContainer as T };
//# sourceMappingURL=ToastContainer-CKzXwJro.js.map
