import { l as load } from './PostCategories-C8pC_zCw.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-DEJKHSTp.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Pagination-DWomX__u.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardMenuItem-DRnpye9y.js';
import './stores-BDx4Az-R.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 35;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-khwN5DjC.js')).default;
const universal_id = "src/routes/posts/categories/[page]/+page.js";
const imports = ["_app/immutable/nodes/35.UyWiCUmN.js","_app/immutable/chunks/PostCategories.Cw7DR4dR.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/Pagination.BMy40NEt.js","_app/immutable/chunks/AddEditPostCategoryModal.Dia0Wu0Q.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/NoContent.CnBreury.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardMenuItem.DlL_qMri.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=35-BurG2v56.js.map
