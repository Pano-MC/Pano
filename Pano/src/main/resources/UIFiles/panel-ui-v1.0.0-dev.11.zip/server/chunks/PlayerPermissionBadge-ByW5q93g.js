import { c as create_ssr_component, a as subscribe, d as add_attribute, e as escape } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';

String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
const PlayerPermissionBadge = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { permissionGroup } = $$props;
  String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
  };
  if ($$props.permissionGroup === void 0 && $$bindings.permissionGroup && permissionGroup !== void 0) $$bindings.permissionGroup(permissionGroup);
  $$unsubscribe__();
  return `<a class="badge rounded-pill text-bg-light"${add_attribute("title", $_("components.player-permission-badge.filter"), 0)} href="${escape(base, true) + "/players/by-perm-group/" + escape(permissionGroup, true)}">${escape(permissionGroup === "-" ? $_("components.player-permission-badge.player") : permissionGroup.capitalize())} </a>`;
});

export { PlayerPermissionBadge as P };
//# sourceMappingURL=PlayerPermissionBadge-ByW5q93g.js.map
