import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as TicketsLayout } from './9-C8FQsh28.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './index-DzcLzHBX.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-CKzXwJro.js';

const Layout_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(TicketsLayout, "Layout").$$render($$result, {}, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout_1 as default };
//# sourceMappingURL=_layout.svelte-CqBr8D15.js.map
