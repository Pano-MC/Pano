const index = 68;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BfVhfdQ0.js')).default;
const imports = ["_app/immutable/nodes/68.B_DMqHLD.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=68-Dw2W_x7q.js.map
