import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-DRnpye9y.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_VIEW, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const ViewLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `  <article class="container"> <nav>${validate_component(CardMenu, "CardMenu").$$render($$result, {}, {}, {
    default: () => {
      return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view" }, {}, {
        default: () => {
          return `Temalar`;
        }
      })} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view/theme-options" }, {}, {
        default: () => {
          return `Tema Seçenekleri`;
        }
      })}`;
    }
  })}</nav> ${slots.default ? slots.default({}) : ``} </article>`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 10;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-D4-lOBGe.js')).default;
const universal_id = "src/routes/view/+layout.js";
const imports = ["_app/immutable/nodes/10.H88wp7tJ.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/auth.util.BCyymusU.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/index.HYqLlNvl.js","_app/immutable/chunks/CardMenuItem.C64M_a8R.js"];
const stylesheets = [];
const fonts = [];

var _10 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ViewLayout as V, _10 as _ };
//# sourceMappingURL=10-Ddz-hj44.js.map
