import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PostCategories } from './PostCategories-CXJyhEZT.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-CzxmL1-R.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Pagination-DWomX__u.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardMenuItem-DRnpye9y.js';
import './stores-BDx4Az-R.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(PostCategories, "PostCategories").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-C_MRRP26.js.map
