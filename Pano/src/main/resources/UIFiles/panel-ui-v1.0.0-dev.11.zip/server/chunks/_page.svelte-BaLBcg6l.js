import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';

const AddonDetail = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Eklenti Detayı");
  return `<div class="container" data-svelte-h="svelte-vymfi0"> <section class="row justify-content-between align-items-center mb-3 animate__animated animate__slideInUp"><div class="col-auto"><a href="/panel/addons" class="btn btn-link" role="button"><i class="fas fa-arrow-left me-2"></i>
        Eklentiler</a></div> <div class="col-auto d-flex align-items-center"><button class="btn btn-link text-danger" type="button"><i class="fas fa-trash"></i></button> <button class="btn btn-link" type="button"><i class="fa-solid fa-eraser"></i></button> <button class="btn btn-link" type="button"><i class="fa-solid fa-arrows-rotate"></i></button> <div class="form-check form-switch mb-0 mx-2"><input class="form-check-input" type="checkbox" role="switch" id="addonStatusSwitch" checked> <label class="form-check-label" for="addonStatusSwitch">Aktif</label></div></div></section> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(AddonDetail, "AddonDetail").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BaLBcg6l.js.map
