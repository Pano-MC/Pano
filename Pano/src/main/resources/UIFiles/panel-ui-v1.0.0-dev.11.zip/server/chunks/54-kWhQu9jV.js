const index = 54;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-De0E4zMP.js')).default;
const imports = ["_app/immutable/nodes/54.B3yRE7BJ.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/tooltip.util.Db4o2w4u.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.Dml6h8e8.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/NoContent.pZt1Ccb_.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=54-kWhQu9jV.js.map
