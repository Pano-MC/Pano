import { c as create_ssr_component, a as subscribe, e as escape, d as add_attribute } from './ssr-ffuobYCI.js';
import { p as page } from './stores-BDx4Az-R.js';
import { b as base } from './paths-C6LjEmZF.js';

const CardMenu = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<ul class="nav nav-pills nav-fill">${slots.default ? slots.default({}) : ``}</ul>`;
});
function matching(path, pathName, startsWith = false) {
  return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
}
const CardMenuItem = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  let { href } = $$props;
  let { startsWith } = $$props;
  let { disabled } = $$props;
  if ($$props.href === void 0 && $$bindings.href && href !== void 0) $$bindings.href(href);
  if ($$props.startsWith === void 0 && $$bindings.startsWith && startsWith !== void 0) $$bindings.startsWith(startsWith);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0) $$bindings.disabled(disabled);
  $$unsubscribe_page();
  return `<li class="nav-item"><a class="${[
    "nav-link " + escape(disabled && "disabled", true),
    matching($page.url.pathname, base + href, startsWith) ? "active" : ""
  ].join(" ").trim()}" aria-current="page"${add_attribute("href", base + href, 0)}${add_attribute("aria-disabled", disabled, 0)}>${slots.default ? slots.default({}) : ``}</a> </li>`;
});

export { CardMenu as C, CardMenuItem as a };
//# sourceMappingURL=CardMenuItem-DRnpye9y.js.map
