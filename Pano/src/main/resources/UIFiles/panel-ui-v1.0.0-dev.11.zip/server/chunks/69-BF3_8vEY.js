const index = 69;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DYnCqbzh.js')).default;
const imports = ["_app/immutable/nodes/69.Cry6B8ub.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/paths.Ce7fYEx1.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=69-BF3_8vEY.js.map
