import { l as load$1, M as Modes } from './PermissionGroupDetail-BKXi1kIQ.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-DEJKHSTp.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 30;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-afNbY0Z4.js')).default;
const universal_id = "src/routes/players/perm-groups/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/30.i1xS-lg6.js","_app/immutable/chunks/PermissionGroupDetail.DJzZfxI_.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/Toast.DrzfcXFc.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=30-BkLkHJc_.js.map
