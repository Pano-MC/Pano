import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { A as ApiUtil } from './api.util-DEJKHSTp.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './ToastContainer-CKzXwJro.js';
import { P as PostRow } from './Posts-BpYEg5-U.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';

async function loadData({ page, url, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/posts?page=${page}&categoryUrl=${url}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        data.url = url;
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    postCount: 0,
    posts: [],
    totalPage: 1,
    page: event.params.page || 1,
    url: event.params.url,
    category: { id: -1, title: "-" }
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    url: event.params.url,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const CategoryPosts = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set($_("pages.category-posts.title", {
    values: {
      category: data.category.title === "-" ? $_("pages.category-posts.no-category") : data.category.title
    }
  }));
  let buttonsLoading = false;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <article class="container"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<a class="btn btn-secondary" role="button" href="${escape(base, true) + "/posts/create-post"}" slot="right"><i class="fas fa-plus"></i> <span class="d-xl-inline d-none ms-2">${escape($_("pages.category-posts.create-post"))}</span></a>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/posts"}" slot="left"><i class="fas fa-arrow-left ms-2"></i> ${escape($_("pages.category-posts.posts"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title mb-md-0" slot="left">${escape($_("pages.category-posts.table-title", { values: { count: data.postCount } }))}</h5>`;
    }
  })}  ${data.postCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th scope="col"></th> <th class="align-middle" scope="col">${escape($_("pages.category-posts.table.title"))}</th> <th scope="col" class="table-primary align-middle">${escape($_("pages.category-posts.table.category"))}</th> <th scope="col" class="align-middle">${escape($_("pages.category-posts.table.author"))}</th> <th scope="col" class="align-middle">${escape($_("pages.category-posts.table.views"))}</th> <th scope="col" class="align-middle">${escape($_("pages.category-posts.table.date"))}</th></tr></thead> <tbody>${each(data.posts, (post, index) => {
    return `${validate_component(PostRow, "PostRow").$$render(
      $$result,
      {
        post,
        pageType: data.pageType,
        buttonsLoading
      },
      {},
      {}
    )}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )} </div></div> </article>`;
});

export { CategoryPosts as C, load as l };
//# sourceMappingURL=CategoryPosts-Dt5Yo2Wa.js.map
