import { c as create_ssr_component, v as validate_component, a as subscribe, d as add_attribute, e as escape, h as each } from './ssr-ffuobYCI.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { b as base } from './paths-C6LjEmZF.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';

const dialogID$1 = "enablingAddonWillCauseMoreEnableConfirmationModal";
const plugin$1 = writable({ notStartedDependencies: [] });
const ConfirmEnablingAddonWillCauseMoreEnableModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $plugin, $$unsubscribe_plugin;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_plugin = subscribe(plugin$1, (value) => $plugin = value);
  $$unsubscribe__();
  $$unsubscribe_plugin();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$1, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-enabling-addon-will-cause-more-enable.title", { values: { pluginId: $plugin.id } }))} <div class="mt-3 alert alert-warning text-left">${escape($_("components.modals.confirm-enabling-addon-will-cause-more-enable.description", { values: { pluginId: $plugin.id } }))} <br> <br> ${each($plugin.notStartedDependencies, (addon, index) => {
    return `<a class="badge bg-warning rounded-pill" href="${escape(base, true) + "/addons/detail/" + escape(addon, true)}" target="_blank">${escape(addon)} </a>`;
  })}</div></div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-enabling-addon-will-cause-more-enable.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-enabling-addon-will-cause-more-enable.yes"))}</button></div></div></div> </div>`;
});
const dialogID = "disablingAddonWillCauseMoreDisableConfirmationModal";
const plugin = writable({ dependents: [] });
const ConfirmDisableAddonWillCauseMoreDisableModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $plugin, $$unsubscribe_plugin;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_plugin = subscribe(plugin, (value) => $plugin = value);
  $$unsubscribe__();
  $$unsubscribe_plugin();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-disable-addon-will-cause-more-disable.title", { values: { pluginId: $plugin.id } }))} <div class="mt-3 alert alert-warning text-left">${escape($_("components.modals.confirm-disable-addon-will-cause-more-disable.description", { values: { pluginId: $plugin.id } }))} <br> <br> ${each($plugin.dependents, (addon, index) => {
    return `<a class="badge bg-warning rounded-pill" href="${escape(base, true) + "/addons/detail/" + escape(addon, true)}" target="_blank">${escape(addon)} </a>`;
  })}</div></div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-disable-addon-will-cause-more-disable.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-disable-addon-will-cause-more-disable.yes"))}</button></div></div></div> </div>`;
});
async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_ADDONS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const AddonsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``} ${validate_component(ConfirmDisableAddonWillCauseMoreDisableModal, "ConfirmDisableAddonWillCauseMoreDisableModal").$$render($$result, {}, {}, {})} ${validate_component(ConfirmEnablingAddonWillCauseMoreEnableModal, "ConfirmEnablingAddonWillCauseMoreEnableModal").$$render($$result, {}, {}, {})}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-C4-861q2.js')).default;
const universal_id = "src/routes/addons/+layout.js";
const imports = ["_app/immutable/nodes/2.DtONEpSl.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.pAQwdRPF.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/auth.util.DzfmAorF.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/index.D3nWO9vj.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { AddonsLayout as A, _2 as _ };
//# sourceMappingURL=2-GU2TXIPW.js.map
