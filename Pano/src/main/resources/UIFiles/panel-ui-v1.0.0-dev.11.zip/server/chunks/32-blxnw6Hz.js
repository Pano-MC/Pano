import { l as load } from './PlayerDetail-rCTgHP8v.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-CzxmL1-R.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './language.util-DgXijOeV.js';
import './ToastContainer-CKzXwJro.js';
import './TicketStatusBadge-zPZI-o9b.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './format-DZNhO2Yc.js';
import './Pagination-DWomX__u.js';
import './NoContent-N-qOzDdv.js';
import './PlayerPermissionBadge-ByW5q93g.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 32;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CivXVaka.js')).default;
const universal_id = "src/routes/players/player/[username]/[page]/+page.js";
const imports = ["_app/immutable/nodes/32.b4s9-56L.js","_app/immutable/chunks/PlayerDetail.CDM01ebE.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.HYqLlNvl.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/Store.CumO5kt-.js","_app/immutable/chunks/api.util.MQ_49TY1.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.Db4o2w4u.js","_app/immutable/chunks/auth.util.BCyymusU.js","_app/immutable/chunks/language.util.DzEm6ZvY.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/AuthorizePlayerModal.CcSHoyeN.js","_app/immutable/chunks/Toast.BsODr_2q.js","_app/immutable/chunks/UnbanPlayerModal.mWuVg-P6.js","_app/immutable/chunks/ConfirmDeletePlayerModal.Bg4kH56M.js","_app/immutable/chunks/TicketStatusBadge.CeMsShHD.js","_app/immutable/chunks/Date.BeJ2IgF2.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/Pagination.B2CWMpJx.js","_app/immutable/chunks/NoContent.pZt1Ccb_.js","_app/immutable/chunks/PlayerPermissionBadge.ydugowFf.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=32-blxnw6Hz.js.map
