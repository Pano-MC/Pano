import { c as create_ssr_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user, selectedServer } = parentData;
  if (!hasPermission(Permissions.MANAGE_SERVERS, user)) {
    throw redirect(302, "/");
  }
  if (!selectedServer) {
    throw redirect(302, "/");
  }
  return parentData;
}
const ServerLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-cq1UXQUU.js')).default;
const universal_id = "src/routes/server/+layout.js";
const imports = ["_app/immutable/nodes/6.Du_2lWd3.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/auth.util.BCyymusU.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/index.HYqLlNvl.js"];
const stylesheets = [];
const fonts = [];

var _6 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ServerLayout as S, _6 as _ };
//# sourceMappingURL=6-C3fINVj6.js.map
