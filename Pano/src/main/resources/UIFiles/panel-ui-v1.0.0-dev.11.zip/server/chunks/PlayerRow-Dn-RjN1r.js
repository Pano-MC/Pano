import { c as create_ssr_component, a as subscribe, f as getContext, i as createEventDispatcher, b as add_classes, d as add_attribute, e as escape, v as validate_component } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { D as Date_1 } from './Date-BK0ZOKAA.js';
import './client-CnCRRyPd.js';
import { P as PlayerPermissionBadge } from './PlayerPermissionBadge-ByW5q93g.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';

String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
const PlayerStatusBadge = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let isOnline;
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { banned = false } = $$props;
  let { lastActivityTime = 0 } = $$props;
  let { inGame = 0 } = $$props;
  let { checkTime = 0 } = $$props;
  if ($$props.banned === void 0 && $$bindings.banned && banned !== void 0) $$bindings.banned(banned);
  if ($$props.lastActivityTime === void 0 && $$bindings.lastActivityTime && lastActivityTime !== void 0) $$bindings.lastActivityTime(lastActivityTime);
  if ($$props.inGame === void 0 && $$bindings.inGame && inGame !== void 0) $$bindings.inGame(inGame);
  if ($$props.checkTime === void 0 && $$bindings.checkTime && checkTime !== void 0) $$bindings.checkTime(checkTime);
  isOnline = lastActivityTime > Date.now() - 5 * 60 * 1e3 || inGame;
  $$unsubscribe__();
  return `${banned ? `<div class="badge rounded-pill text-bg-danger">${escape($_("components.player-status-badge.banned"))}</div>` : `${isOnline ? `<div class="badge rounded-pill text-bg-success"><span>${escape($_("components.player-status-badge.online"))}</span></div>` : `<div class="badge rounded-pill text-bg-light"><span>${escape($_("components.player-status-badge.offline"))}</span></div>`}`}`;
});
const PlayerRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $user, $$unsubscribe_user;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const user = getContext("user");
  $$unsubscribe_user = subscribe(user, (value) => $user = value);
  let { player } = $$props;
  let { checkTime } = $$props;
  createEventDispatcher();
  if ($$props.player === void 0 && $$bindings.player && player !== void 0) $$bindings.player(player);
  if ($$props.checkTime === void 0 && $$bindings.checkTime && checkTime !== void 0) $$bindings.checkTime(checkTime);
  $$unsubscribe__();
  $$unsubscribe_user();
  return `<tr${add_classes((player.selected ? "table-primary" : "").trim())}><th scope="row"><div class="dropdown position-static"><button type="button" class="btn btn-link btn-sm" aria-expanded="false" aria-haspopup="true" data-bs-toggle="dropdown" href="javascript:void(0);"${add_attribute("title", $_("components.player-row.actions"), 0)}><span class="fas fa-ellipsis-v"></span></button> <div class="dropdown-menu dropdown-menu-start animate__animated animate__fadeIn">${hasPermission(Permissions.MANAGE_PERMISSION_GROUPS) ? `<a class="${[
    "dropdown-item",
    $user.username === player.username || player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fas fa-user-circle me-2"></i> ${escape($_("components.player-row.authorize"))}</a>` : ``} <a class="${[
    "dropdown-item",
    player.permissionGroup === "admin" && !$user.admin ? "disabled" : ""
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fa-solid fa-pencil-alt me-2"></i> ${escape($_("components.player-row.edit"))}</a> <a class="${[
    "dropdown-item",
    ($user.username !== player.username && (player.permissionGroup === "admin" && $user.admin || player.permissionGroup !== "admin") ? "link-danger" : "") + " " + ($user.username === player.username || player.permissionGroup === "admin" && !$user.admin ? "disabled" : "")
  ].join(" ").trim()}" href="javascript:void(0);"><i class="fas fa-gavel me-2"></i> ${player.isBanned ? `${escape($_("components.player-row.remove-ban"))}` : `${escape($_("components.player-row.ban"))}`}</a></div></div></th> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.player-row.view"), 0)} href="${escape(base, true) + "/players/player/" + escape(player.username, true)}"><img${add_attribute("alt", player.username, 0)} class="rounded-circle animate__animated animate__zoomIn me-2" height="32" src="${"https://minotar.net/avatar/" + escape(player.username, true)}" width="32"> ${escape(player.username)}</a></td> <td class="align-middle text-nowrap text-capitalize">${validate_component(PlayerPermissionBadge, "PlayerPermissionBadge").$$render($$result, { permissionGroup: player.permissionGroup }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(PlayerStatusBadge, "PlayerStatusBadge").$$render(
    $$result,
    {
      banned: player.isBanned,
      lastActivityTime: player.lastActivityTime,
      inGame: player.inGame,
      checkTime
    },
    {},
    {}
  )}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: player.lastLoginDate }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: player.registerDate }, {}, {})}</td> </tr>`;
});

export { PlayerRow as P };
//# sourceMappingURL=PlayerRow-Dn-RjN1r.js.map
