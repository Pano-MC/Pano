import { l as load } from './PermissionGroups-BJI_ZneR.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-CzxmL1-R.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 28;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CiLGzLPP.js')).default;
const universal_id = "src/routes/players/perm-groups/[page]/+page.js";
const imports = ["_app/immutable/nodes/28.BD8GW_3T.js","_app/immutable/chunks/PermissionGroups.C_TNvTwT.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.HYqLlNvl.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/Store.CumO5kt-.js","_app/immutable/chunks/api.util.MQ_49TY1.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/tooltip.util.Db4o2w4u.js","_app/immutable/chunks/Pagination.B2CWMpJx.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=28-D9O2t1c4.js.map
