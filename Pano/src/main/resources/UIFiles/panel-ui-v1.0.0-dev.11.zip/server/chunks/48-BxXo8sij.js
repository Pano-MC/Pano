const index = 48;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-B47lMzWK.js')).default;
const imports = ["_app/immutable/nodes/48.CW_gvLG8.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/ServerSettings.DGcQkl3i.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/Store.CumO5kt-.js","_app/immutable/chunks/api.util.MQ_49TY1.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/Toast.BsODr_2q.js","_app/immutable/chunks/each.BbucQ6WL.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=48-BxXo8sij.js.map
