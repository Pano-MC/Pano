import { l as load } from './PostCategories-CXJyhEZT.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-CzxmL1-R.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Pagination-DWomX__u.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardMenuItem-DRnpye9y.js';
import './stores-BDx4Az-R.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 35;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cr3oZtGa.js')).default;
const universal_id = "src/routes/posts/categories/[page]/+page.js";
const imports = ["_app/immutable/nodes/35.BNBadUB5.js","_app/immutable/chunks/PostCategories.joLUxPFW.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.HYqLlNvl.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/chunks/Store.CumO5kt-.js","_app/immutable/chunks/api.util.MQ_49TY1.js","_app/immutable/chunks/stores.DC2ArYJ1.js","_app/immutable/chunks/runtime.DwURjVE3.js","_app/immutable/chunks/Pagination.B2CWMpJx.js","_app/immutable/chunks/AddEditPostCategoryModal.Dl8KD6AQ.js","_app/immutable/chunks/Toast.BsODr_2q.js","_app/immutable/chunks/NoContent.pZt1Ccb_.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardMenuItem.C64M_a8R.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=35-B5qyL54X.js.map
