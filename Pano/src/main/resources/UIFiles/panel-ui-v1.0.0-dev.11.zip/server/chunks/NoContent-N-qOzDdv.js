import { c as create_ssr_component, a as subscribe, e as escape } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';

const NoContent = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { dark = false } = $$props;
  let { icon = "fa-solid fa-ghost fa-3x" } = $$props;
  let { text = $_("components.no-content.here-is-empty") } = $$props;
  if ($$props.dark === void 0 && $$bindings.dark && dark !== void 0) $$bindings.dark(dark);
  if ($$props.icon === void 0 && $$bindings.icon && icon !== void 0) $$bindings.icon(icon);
  if ($$props.text === void 0 && $$bindings.text && text !== void 0) $$bindings.text(text);
  $$unsubscribe__();
  return `<div class="container text-center animate__animated animate__zoomIn">${dark ? `<i class="${escape(icon, true) + " text-light text-opacity-25 m-3"}"></i> <p class="text-light">${escape(text)}</p>` : `<i class="${escape(icon, true) + " text-dark text-opacity-25 m-3"}"></i> <small class="text-gray d-block mb-3">${escape(text)}</small>`} ${slots.default ? slots.default({}) : ``} </div>`;
});

export { NoContent as N };
//# sourceMappingURL=NoContent-N-qOzDdv.js.map
