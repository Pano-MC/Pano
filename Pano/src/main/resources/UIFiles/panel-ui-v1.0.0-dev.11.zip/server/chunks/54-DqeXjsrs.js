const index = 54;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-De0E4zMP.js')).default;
const imports = ["_app/immutable/nodes/54.C6wtqmrL.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.CawhLpLy.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/NoContent.CnBreury.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=54-DqeXjsrs.js.map
