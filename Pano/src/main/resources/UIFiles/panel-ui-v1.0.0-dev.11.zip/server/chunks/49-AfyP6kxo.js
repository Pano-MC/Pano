const index = 49;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C5ptN_YB.js')).default;
const imports = ["_app/immutable/nodes/49.C9UL7_uU.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=49-AfyP6kxo.js.map
