const index = 48;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-B47lMzWK.js')).default;
const imports = ["_app/immutable/nodes/48.CuqllKu9.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/ServerSettings.CVIAsPnv.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/each.BbucQ6WL.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=48-cAuJGTT1.js.map
