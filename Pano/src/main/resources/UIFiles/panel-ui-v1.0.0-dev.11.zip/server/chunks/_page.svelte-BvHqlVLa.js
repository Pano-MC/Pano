import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as Tickets } from './Tickets-CWtbIkBP.js';
import './index-DzcLzHBX.js';
import './index2-Dyghn50Q.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-DEJKHSTp.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import './TicketRow-CvSni0kK.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';
import './TicketStatusBadge-zPZI-o9b.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardFilters-C1uMKg14.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Tickets, "Tickets").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BvHqlVLa.js.map
