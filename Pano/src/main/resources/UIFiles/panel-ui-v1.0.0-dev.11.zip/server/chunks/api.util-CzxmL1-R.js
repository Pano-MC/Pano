import './client-CnCRRyPd.js';

let API_URL = "http://localhost:8088/panel/api";
const UI_URL = "/";
const PANO_WEBSITE_URL = "https://dev.panomc.com";
const COOKIE_PREFIX = "pano_";
const CSRF_TOKEN_COOKIE_NAME = "csrf_token";
const JWT_COOKIE_NAME = "auth_token";
const CSRF_HEADER = "X-CSRF-Token";
const PLUGIN_DEV_MODE = "false"?.toLowerCase() === "true";
function updateApiUrl(apiUrl) {
  API_URL = apiUrl;
}
const NETWORK_ERROR = "NETWORK_ERROR";
const networkErrorBody = { result: "error", error: NETWORK_ERROR };
const ApiUtil = {
  get({ path, request, csrfToken, token, blob }) {
    return this.customRequest({ path, request, csrfToken, token, blob });
  },
  post({ path, request, body, headers, csrfToken, token, blob }) {
    return this.customRequest({
      path,
      data: {
        method: "POST",
        credentials: "include",
        body,
        headers
      },
      request,
      csrfToken,
      token,
      blob
    });
  },
  put({ path, request, body, headers, csrfToken, token, blob }) {
    return this.customRequest({
      path,
      data: {
        method: "PUT",
        credentials: "include",
        body,
        headers
      },
      request,
      csrfToken,
      token,
      blob
    });
  },
  delete({ path, request, headers, csrfToken, token, blob }) {
    return this.customRequest({
      path,
      data: {
        method: "DELETE",
        headers
      },
      request,
      csrfToken,
      token,
      blob
    });
  },
  async customRequest({ path, data = {}, request, csrfToken, token, blob }) {
    if (!csrfToken) {
      let session;
      if (request) {
        const parentData = await request.parent();
        const { session: parentSession } = parentData;
        session = parentSession;
      }
      csrfToken = session && session.csrfToken;
    }
    const CSRFHeader = {};
    if (csrfToken) CSRFHeader[CSRF_HEADER] = csrfToken;
    if (!(data.body instanceof FormData)) {
      data.body = JSON.stringify(data.body);
      data.headers = {
        "Content-Type": "application/json",
        ...data.headers
      };
    }
    const options = {
      ...data,
      headers: csrfToken ? { ...data.headers, ...CSRFHeader } : data.headers
    };
    if (token) {
      options.headers["Authorization"] = `Bearer ${token}`;
    } else {
      const isCredentialsSupported = "credentials" in Request.prototype;
      if (isCredentialsSupported) {
        options["credentials"] = "include";
      }
    }
    path = `${API_URL}/${path.replace("/api/", "")}`;
    const fetchRequest = request && request.fetch ? request.fetch(path, options) : fetch(path, options);
    return fetchRequest.then((r) => blob ? r.blob() : r.text()).then((json) => {
      try {
        return JSON.parse(json);
      } catch (err) {
        return json;
      }
    });
  }
};

export { ApiUtil as A, COOKIE_PREFIX as C, JWT_COOKIE_NAME as J, PLUGIN_DEV_MODE as P, UI_URL as U, CSRF_TOKEN_COOKIE_NAME as a, PANO_WEBSITE_URL as b, API_URL as c, networkErrorBody as n, updateApiUrl as u };
//# sourceMappingURL=api.util-CzxmL1-R.js.map
