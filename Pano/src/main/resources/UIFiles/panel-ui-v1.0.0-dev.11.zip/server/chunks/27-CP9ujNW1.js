import { l as load } from './PermissionGroups--eTfGqsW.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-DEJKHSTp.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 27;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-N5-Ad14I.js')).default;
const universal_id = "src/routes/players/perm-groups/+page.js";
const imports = ["_app/immutable/nodes/27.Ci1_kxHP.js","_app/immutable/chunks/PermissionGroups.ehoWUXZR.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.D3nWO9vj.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/Pagination.BMy40NEt.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=27-CP9ujNW1.js.map
