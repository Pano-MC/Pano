import { l as load } from './Addons-BVJkV2E2.js';
import './ssr-ffuobYCI.js';
import './api.util-DEJKHSTp.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './index2-Dyghn50Q.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardFilters-C1uMKg14.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './NoContent-N-qOzDdv.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-X_8Uz8Dr.js')).default;
const universal_id = "src/routes/addons/+page.js";
const imports = ["_app/immutable/nodes/12.IyHOPb2i.js","_app/immutable/chunks/Addons.Dfi9xH5b.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/api.util.WJ8nAceo.js","_app/immutable/chunks/stores.BmoBeU7j.js","_app/immutable/chunks/entry.BG2XX_1C.js","_app/immutable/chunks/paths.Ce7fYEx1.js","_app/immutable/chunks/tooltip.util.D44udoWT.js","_app/immutable/chunks/Store.Dte-ps2W.js","_app/immutable/chunks/Toast.DrzfcXFc.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.CawhLpLy.js","_app/immutable/chunks/runtime.D7rGe2l5.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.pAQwdRPF.js","_app/immutable/chunks/NoContent.CnBreury.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=12-NdWhVnte.js.map
