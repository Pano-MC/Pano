const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "panel/_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/404.png","assets/img/landing.png","assets/img/loading_slime.gif","assets/img/logo.svg","assets/img/minecraft-icon.png","assets/img/vanilla.png","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".gif":"image/gif",".txt":"text/plain"},
	_: {
		client: {"start":"_app/immutable/entry/start.DzL43iYG.js","app":"_app/immutable/entry/app.Bc0qPDBn.js","imports":["_app/immutable/entry/start.DzL43iYG.js","_app/immutable/chunks/entry.pOwZnOL0.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/paths.BhRVuHPg.js","_app/immutable/entry/app.Bc0qPDBn.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./chunks/0-BeCw1sQb.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-DGU63Bja.js')),
			__memo(() => import('./chunks/2-Hgc_JM2Q.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/3-NHon-L3k.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/4-6BeOCgrW.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/5-BNL6JVKY.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/6-C3fINVj6.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-DHuEKSpz.js')),
			__memo(() => import('./chunks/8-D_G24rHn.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/9-C8FQsh28.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/10-Ddz-hj44.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/11-CzY3iKWX.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/12-CIHWnWue.js')),
			__memo(() => import('./chunks/13-hORxBZhC.js')),
			__memo(() => import('./chunks/14-0EsjXeWC.js')),
			__memo(() => import('./chunks/15-D5WFwBe8.js')),
			__memo(() => import('./chunks/16-Cmt4jpyx.js')),
			__memo(() => import('./chunks/17-D7HsTnDX.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-DmD0uxwM.js')),
			__memo(() => import('./chunks/19-CkP-3S9u.js')),
			__memo(() => import('./chunks/20-GM0nN3Cl.js')),
			__memo(() => import('./chunks/21-BXIyXfu8.js')),
			__memo(() => import('./chunks/22-D_wexzTz.js')),
			__memo(() => import('./chunks/23-fynIodCC.js')),
			__memo(() => import('./chunks/24-BIMe5xde.js')),
			__memo(() => import('./chunks/25-dojJX-_N.js')),
			__memo(() => import('./chunks/26-Dc7IKCcJ.js')),
			__memo(() => import('./chunks/27-CNkpryrK.js')),
			__memo(() => import('./chunks/28-D9O2t1c4.js')),
			__memo(() => import('./chunks/29-DFSZgbyj.js')),
			__memo(() => import('./chunks/30-BJusqxAC.js')),
			__memo(() => import('./chunks/31-M4s5_ZT5.js')),
			__memo(() => import('./chunks/32-blxnw6Hz.js')),
			__memo(() => import('./chunks/33-BoAF1Rd9.js')),
			__memo(() => import('./chunks/34-DPeKJ782.js')),
			__memo(() => import('./chunks/35-B5qyL54X.js')),
			__memo(() => import('./chunks/36-CYrT9b_V.js')),
			__memo(() => import('./chunks/37-CPEtlonJ.js')),
			__memo(() => import('./chunks/38-DVewE-wa.js')),
			__memo(() => import('./chunks/39-RW0w1av9.js')),
			__memo(() => import('./chunks/40-ond7Rgvo.js')),
			__memo(() => import('./chunks/41-DHST2eT_.js')),
			__memo(() => import('./chunks/42-YpcfgcG-.js')),
			__memo(() => import('./chunks/43-CuOJyS67.js')),
			__memo(() => import('./chunks/44-DSK3WIDh.js')),
			__memo(() => import('./chunks/45-k3w7aE6n.js')),
			__memo(() => import('./chunks/46-CMuW-avz.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/47-BR0EKgmk.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/48-BxXo8sij.js')),
			__memo(() => import('./chunks/49-AfyP6kxo.js')),
			__memo(() => import('./chunks/50-Bm6jlXMo.js')),
			__memo(() => import('./chunks/51-BRbbhC-P.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/52-BRTVBAUv.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/53-Cer0CWdx.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/54-kWhQu9jV.js')),
			__memo(() => import('./chunks/55-sSt1DYG1.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/56-CGBdd1MU.js')),
			__memo(() => import('./chunks/57-C9qu1CkI.js')),
			__memo(() => import('./chunks/58-BnDnJ2rc.js')),
			__memo(() => import('./chunks/59-r9V4GlzQ.js')),
			__memo(() => import('./chunks/60-Cd3MRlG7.js')),
			__memo(() => import('./chunks/61-CtPwzclU.js')),
			__memo(() => import('./chunks/62-D2864Uyu.js')),
			__memo(() => import('./chunks/63-Q0UPxc_3.js')),
			__memo(() => import('./chunks/64-BPek1VG_.js')),
			__memo(() => import('./chunks/65-DEhoVwoO.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/66-D_MM9LLV.js')),
			__memo(() => import('./chunks/67-BcWaV7a_.js')),
			__memo(() => import('./chunks/68-Dw2W_x7q.js')),
			__memo(() => import('./chunks/69-BrfsPAPM.js')),
			__memo(() => import('./chunks/70-BgTREfYp.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/addons",
				pattern: /^\/addons\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/addons/active",
				pattern: /^\/addons\/active\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/addons/all",
				pattern: /^\/addons\/all\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/addons/detail/[addonId]",
				pattern: /^\/addons\/detail\/([^/]+?)\/?$/,
				params: [{"name":"addonId","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/addons/disabled",
				pattern: /^\/addons\/disabled\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/players",
				pattern: /^\/players\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/players/all",
				pattern: /^\/players\/all\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/players/all/[page]",
				pattern: /^\/players\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 20 },
				endpoint: null
			},
			{
				id: "/players/banned",
				pattern: /^\/players\/banned\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/players/banned/[page]",
				pattern: /^\/players\/banned\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/players/by-perm-group/[permissionGroup]",
				pattern: /^\/players\/by-perm-group\/([^/]+?)\/?$/,
				params: [{"name":"permissionGroup","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/players/by-perm-group/[permissionGroup]/[page]",
				pattern: /^\/players\/by-perm-group\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"permissionGroup","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/players/hasPerm",
				pattern: /^\/players\/hasPerm\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/players/hasPerm/[page]",
				pattern: /^\/players\/hasPerm\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/players/perm-groups",
				pattern: /^\/players\/perm-groups\/?$/,
				params: [],
				page: { layouts: [0,3,4,], errors: [1,,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/players/perm-groups/create",
				pattern: /^\/players\/perm-groups\/create\/?$/,
				params: [],
				page: { layouts: [0,3,4,], errors: [1,,,], leaf: 29 },
				endpoint: null
			},
			{
				id: "/players/perm-groups/detail/[id]",
				pattern: /^\/players\/perm-groups\/detail\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,4,], errors: [1,,,], leaf: 30 },
				endpoint: null
			},
			{
				id: "/players/perm-groups/[page]",
				pattern: /^\/players\/perm-groups\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,4,], errors: [1,,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/players/player/[username]",
				pattern: /^\/players\/player\/([^/]+?)\/?$/,
				params: [{"name":"username","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 31 },
				endpoint: null
			},
			{
				id: "/players/player/[username]/[page]",
				pattern: /^\/players\/player\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"username","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 32 },
				endpoint: null
			},
			{
				id: "/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Duh1hDwD.js'))
			},
			{
				id: "/posts",
				pattern: /^\/posts\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 33 },
				endpoint: null
			},
			{
				id: "/posts/categories",
				pattern: /^\/posts\/categories\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 34 },
				endpoint: null
			},
			{
				id: "/posts/categories/[page]",
				pattern: /^\/posts\/categories\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 35 },
				endpoint: null
			},
			{
				id: "/posts/category/[url]",
				pattern: /^\/posts\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 36 },
				endpoint: null
			},
			{
				id: "/posts/category/[url]/[page]",
				pattern: /^\/posts\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 37 },
				endpoint: null
			},
			{
				id: "/posts/create-post",
				pattern: /^\/posts\/create-post\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 38 },
				endpoint: null
			},
			{
				id: "/posts/draft",
				pattern: /^\/posts\/draft\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 39 },
				endpoint: null
			},
			{
				id: "/posts/draft/[page]",
				pattern: /^\/posts\/draft\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 40 },
				endpoint: null
			},
			{
				id: "/posts/post/[id]",
				pattern: /^\/posts\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 41 },
				endpoint: null
			},
			{
				id: "/posts/published",
				pattern: /^\/posts\/published\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 42 },
				endpoint: null
			},
			{
				id: "/posts/published/[page]",
				pattern: /^\/posts\/published\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 43 },
				endpoint: null
			},
			{
				id: "/posts/trash",
				pattern: /^\/posts\/trash\/?$/,
				params: [],
				page: { layouts: [0,5,], errors: [1,,], leaf: 44 },
				endpoint: null
			},
			{
				id: "/posts/trash/[page]",
				pattern: /^\/posts\/trash\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,5,], errors: [1,,], leaf: 45 },
				endpoint: null
			},
			{
				id: "/server/dashboard",
				pattern: /^\/server\/dashboard\/?$/,
				params: [],
				page: { layouts: [0,6,], errors: [1,,], leaf: 46 },
				endpoint: null
			},
			{
				id: "/server/monitoring",
				pattern: /^\/server\/monitoring\/?$/,
				params: [],
				page: { layouts: [0,6,], errors: [1,,], leaf: 47 },
				endpoint: null
			},
			{
				id: "/server/settings",
				pattern: /^\/server\/settings\/?$/,
				params: [],
				page: { layouts: [0,6,7,], errors: [1,,,], leaf: 48 },
				endpoint: null
			},
			{
				id: "/server/settings/game-integration",
				pattern: /^\/server\/settings\/game-integration\/?$/,
				params: [],
				page: { layouts: [0,6,7,], errors: [1,,,], leaf: 49 },
				endpoint: null
			},
			{
				id: "/server/settings/server",
				pattern: /^\/server\/settings\/server\/?$/,
				params: [],
				page: { layouts: [0,6,7,], errors: [1,,,], leaf: 50 },
				endpoint: null
			},
			{
				id: "/settings",
				pattern: /^\/settings\/?$/,
				params: [],
				page: { layouts: [0,8,], errors: [1,,], leaf: 51 },
				endpoint: null
			},
			{
				id: "/settings/about",
				pattern: /^\/settings\/about\/?$/,
				params: [],
				page: { layouts: [0,8,], errors: [1,,], leaf: 52 },
				endpoint: null
			},
			{
				id: "/settings/platform",
				pattern: /^\/settings\/platform\/?$/,
				params: [],
				page: { layouts: [0,8,], errors: [1,,], leaf: 53 },
				endpoint: null
			},
			{
				id: "/settings/updates",
				pattern: /^\/settings\/updates\/?$/,
				params: [],
				page: { layouts: [0,8,], errors: [1,,], leaf: 54 },
				endpoint: null
			},
			{
				id: "/statistics",
				pattern: /^\/statistics\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 55 },
				endpoint: null
			},
			{
				id: "/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 56 },
				endpoint: null
			},
			{
				id: "/tickets/all",
				pattern: /^\/tickets\/all\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 57 },
				endpoint: null
			},
			{
				id: "/tickets/all/[page]",
				pattern: /^\/tickets\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,9,], errors: [1,,], leaf: 58 },
				endpoint: null
			},
			{
				id: "/tickets/categories",
				pattern: /^\/tickets\/categories\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 59 },
				endpoint: null
			},
			{
				id: "/tickets/categories/page",
				pattern: /^\/tickets\/categories\/page\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 60 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]",
				pattern: /^\/tickets\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,9,], errors: [1,,], leaf: 61 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]/[page]",
				pattern: /^\/tickets\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,9,], errors: [1,,], leaf: 62 },
				endpoint: null
			},
			{
				id: "/tickets/closed",
				pattern: /^\/tickets\/closed\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 63 },
				endpoint: null
			},
			{
				id: "/tickets/closed/[page]",
				pattern: /^\/tickets\/closed\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,9,], errors: [1,,], leaf: 64 },
				endpoint: null
			},
			{
				id: "/tickets/ticket/[id]",
				pattern: /^\/tickets\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,9,], errors: [1,,], leaf: 65 },
				endpoint: null
			},
			{
				id: "/tickets/waitingReply",
				pattern: /^\/tickets\/waitingReply\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 66 },
				endpoint: null
			},
			{
				id: "/tickets/waitingReply/waitingReply",
				pattern: /^\/tickets\/waitingReply\/waitingReply\/?$/,
				params: [],
				page: { layouts: [0,9,], errors: [1,,], leaf: 67 },
				endpoint: null
			},
			{
				id: "/tools",
				pattern: /^\/tools\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 68 },
				endpoint: null
			},
			{
				id: "/view",
				pattern: /^\/view\/?$/,
				params: [],
				page: { layouts: [0,10,], errors: [1,,], leaf: 69 },
				endpoint: null
			},
			{
				id: "/view/theme-options",
				pattern: /^\/view\/theme-options\/?$/,
				params: [],
				page: { layouts: [0,10,], errors: [1,,], leaf: 70 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "/panel";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
