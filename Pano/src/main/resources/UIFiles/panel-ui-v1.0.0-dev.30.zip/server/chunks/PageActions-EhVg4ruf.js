import { c as create_ssr_component } from './ssr-ffuobYCI.js';

const PageActions = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="row gy-2 d-flex align-items-center"><div class="col-lg-4 col-12 d-flex justify-content-lg-start justify-content-center">${slots.left ? slots.left({}) : ``}</div> <div class="col-lg-4 col-12 order-lg-2 order-last">${slots.middle ? slots.middle({}) : ``}</div> <div class="col-lg-4 col-12 order-3 d-flex justify-content-lg-end justify-content-center">${slots.right ? slots.right({}) : ``}</div></div>`;
});

export { PageActions as P };
//# sourceMappingURL=PageActions-EhVg4ruf.js.map
