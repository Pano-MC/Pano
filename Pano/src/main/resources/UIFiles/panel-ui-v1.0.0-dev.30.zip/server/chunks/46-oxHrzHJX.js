const index = 46;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DGC6z96p.js')).default;
const imports = ["_app/immutable/nodes/46.CiWn7RWt.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=46-oxHrzHJX.js.map
