const buttons = {
  remove: "Remove",
  connect: "Connect",
  connecting: "Connecting...",
  close: "Close",
  yes: "Yes",
  cancel: "Cancel",
  download: "Download",
  enable: "Enable",
  validate: "Validate",
  players: "Players",
  posts: "Posts",
  tickets: "Tickets"
};
const pages = {
  dashboard: {
    title: "Panel",
    "welcome-card": {
      description: "Pano is successfully installed and ready for use. 🚀 <br /> Here's what you can do to get started:",
      "connect-server": "Connect Server",
      "connect-server-description": "Connect your game server and access more management features.",
      "menu-title": "The Menu",
      "links-title": "Links",
      "publish-your-first-post": "Publish First Post",
      "change-theme": "Change Theme Appearance",
      "manage-addons": "Manage Addons",
      "manage-players": "Manage Players",
      "themes-and-extensions": "Themes & Extensions",
      documentations: "Documentation",
      website: "Website",
      discord: "Discord",
      "close-button": "Close"
    },
    "last-tickets": {
      title: "Last Tickets",
      "player-name": "Player Name",
      view: "View",
      filter: "Filter",
      "no-category": "No Category"
    }
  },
  statistics: {
    title: "Statistics",
    "online-player-text": "{onlinePlayerCount} Online on Site",
    "new-register-text": "{newRegisterCount} New Registration",
    "total-player-text": "{totalPlayerCount} Total Players",
    "website-graph": {
      title: "Website Activity",
      week: "Week",
      month: "Month"
    },
    "total-statistics": {
      title: "Statistics",
      posts: "Posts:",
      players: "Players:",
      admins: "Admins:",
      tickets: "Tickets:",
      "connected-servers": "Servers:",
      addons: "Addons:",
      themes: "Themes:"
    }
  },
  players: {
    title: "{pageType}Players",
    "by-perm-group-title": '"{permissionGroupName}" Authorized Players',
    authorized: "Authorized",
    banned: "Banned",
    "perm-groups": "Permission Groups",
    "table-title": "{playerCount} {pageType} Player",
    all: "All",
    player: "Player",
    table: {
      name: "Username",
      "perm-group": "Permission Group",
      status: "Status",
      "last-login": "Last Login",
      "register-date": "Register Date"
    }
  },
  posts: {
    title: "{pageType}Posts",
    "category-posts-title": '"{category}" Posts',
    "no-category": "No Category",
    published: "Published",
    draft: "Draft",
    trash: "Trash",
    "table-title": "{postCount} {pageType} Post",
    "post-categories-button": "Categories",
    "create-post-button": "Create Post",
    table: {
      title: "Title",
      category: "Category",
      views: "Views",
      author: "Author",
      "last-update": "Last Update"
    }
  },
  tickets: {
    title: "{pageType}Tickets",
    "category-tickets-title": '"{category}" Tickets',
    "no-category": "No Category",
    "waiting-reply": "Waiting Reply",
    closed: "Closed",
    "ticket-categories": "Ticket Categories",
    "close-ticket-button": "Close Ticket",
    "table-title": "{ticketCount} {pageType} Ticket",
    "ticket-categories-button": "Categories",
    "amount-selected": "{amount} amount selected.",
    all: "All",
    "select-all": "Select All",
    table: {
      title: "Title",
      player: "Player",
      category: "Category",
      status: "Status",
      "last-reply": "Last Reply"
    }
  },
  notifications: {
    title: "Notifications",
    "delete-all": "Delete All",
    "delete-notification": "Delete Notification",
    "show-more": "Show More ({count})"
  },
  settings: {
    about: {
      title: "About",
      version: "Version",
      release: "Release",
      website: "Website",
      discord: "Discord",
      "open-source-licenses": "Open Source Licenses"
    },
    "site-settings": {
      title: "Website Settings",
      preferences: "Preferences",
      inputs: {
        "website-name": {
          label: "Website Name",
          placeholder: "Name"
        },
        "website-description": {
          label: "Website Description"
        },
        "game-server-ip-address": {
          label: "Game Server IP Address"
        },
        "game-server-version": {
          label: "Game Server Version"
        },
        "support-email-address": {
          label: "Support E-Mail Address"
        },
        keywords: {
          label: "Keywords",
          placeholder: "Press Enter to insert",
          remove: "Click To Remove"
        },
        favicon: {
          label: "Favicon",
          select: "Select",
          helper: "PNG, ICO, GIF, JPG, SVG format, maximum 1 mb and 16x16 pixels It must be."
        },
        "website-logo": {
          label: "Website Logo",
          "server-icon": "Server Icon",
          helper: "PNG, JPEG, GIF, SVG format, maximum 2 mb."
        }
      },
      "save-button": "Save"
    },
    platform: {
      title: "Platform Settings",
      preferences: "Preferences",
      "display-language": "Display Language",
      "check-auto-updates": "Platform Updates",
      "connect-failed-alert": "Connecting your Pano account has been failed! Try again.",
      account: "Account",
      "platform-id": "Platform ID",
      user: "User",
      "online-account": "Online Account",
      "online-account-description": "Connect your online Pano account to access plugins, themes, and updates.",
      inputs: {
        "check-auto-updates": {
          never: "Never",
          "once-in-a-day": "Once in a Day",
          "once-in-a-week": "Once in a Week",
          "once-in-a-month": "Once in a Month"
        }
      },
      smtp: {
        username: "Username (Address)",
        password: "Password",
        ssl: "Use SSL",
        "tls-setting": "TLS Setting",
        "sender-address": "Sender Address",
        hostname: "Hostname",
        port: "Port",
        "auth-methods": "Auth Methods",
        description: "Pano requires an email provider to be able to send emails. Please log in with the e-mail service you want to use.",
        "email-validation-error": "Couldn't validate e-mail settings: {mailError}"
      },
      "smtp-settings": "E-Mail Settings (SMTP)",
      "save-button": "Save",
      "toggle-smtp": "Toggle SMTP"
    }
  },
  "ticket-detail": {
    tickets: "Tickets",
    "close-ticket": "Close Ticket",
    "by-who": "By {username},",
    "opened-in-category": "opened in {category} category.",
    "no-category": "No Category",
    "previous-messages": "Previous Messages ({count})",
    "send-button": "Send"
  },
  "post-categories": {
    title: "Post Categories",
    posts: "Posts",
    "create-category-button": "Create Category",
    "card-title": "{count} Post Category",
    category: "Category",
    description: "Description",
    url: "URL",
    color: "Color"
  },
  "ticket-categories": {
    title: "Ticket Categories",
    tickets: "Tickets",
    "create-category-button": "Create Category",
    "card-title": "{count} Ticket Category",
    category: "Category",
    description: "Description"
  },
  "permission-groups": {
    title: "Permission Groups",
    players: "Players",
    "create-permission-group-button": "Create Permission Group",
    "card-title": "{count} Permission Group",
    name: "Name",
    "permission-amount": "Permission Amount",
    "player-amount": "Player Amount"
  },
  error: {
    title: "Error: {status}",
    "go-back": "Go Back"
  },
  "post-editor": {
    posts: "Posts",
    trash: "Trash",
    "move-to-drafts": "Move to Drafts",
    view: "View",
    save: "Save",
    update: "Update",
    publish: "Publish",
    inputs: {
      title: {
        placeholder: "Enter post title"
      }
    },
    status: "Status:",
    views: "View:",
    category: "Category:",
    "no-category": "No Category",
    thumbnail: "Thumbnail:",
    clear: "Clear",
    add: "Add",
    change: "Change",
    "thumbnail-not-determined": "The thumbnail has not been determined.",
    "title-create": "Create New Post",
    "title-edit": "Edit Post",
    "new": "New",
    draft: "Draft",
    published: "Published"
  },
  server: {
    dashboard: {
      title: "Server Statistics",
      "server-status": "Server {status}",
      online: "Online",
      offline: "Offline",
      player: "{playerCount}/{maxPlayerCount} Player",
      "working-time": "Uptime: {upTime}",
      "last-online": "Last Online: ",
      statistics: "Statistics",
      "server-name": "Server Name:",
      "server-type": "Server Type:",
      "local-ip-address": "Local IP Address:",
      "server-version": "Server Version:",
      "total-connected-servers": "Amount Of Connected Servers:",
      "date-added": "Date Added:"
    },
    settings: {
      title: "Server Settings",
      "main-server": "Main Server",
      "already-main-server": "{serverName} is main server",
      "make-main-server": "Set as Main Server",
      "main-server-info": "The host server determines the server information to be displayed on the website.",
      "remove-server": "Remove Server",
      disconnect: "Disconnect"
    },
    monitoring: {
      title: "Server Monitoring"
    }
  },
  "permission-group-detail": {
    "title-edit": "Edit Permission Group",
    "title-create": "Create Permission Group",
    "permission-groups": "Permission Groups",
    save: "Edit",
    create: "Create",
    inputs: {
      name: {
        placeholder: "Name"
      },
      player: {
        placeholder: "Add player..."
      }
    },
    remove: "Remove"
  },
  "player-detail": {
    players: "Players",
    "delete": "Delete",
    "un-ban": "Remove Ban",
    ban: "Ban",
    "send-verification-mail": "Send a verification link to player email",
    authorize: "Authorize",
    edit: "Edit",
    "in-game": "In Game",
    "in-website": "In Website",
    "online-text": "{whereOnline} Online",
    banned: "Banned",
    "last-tickets": "Last Tickets",
    view: "View",
    filter: "Filter",
    "no-category": "No Category",
    statistics: "Statistics",
    email: "E-Mail",
    "email-verified": "Verified",
    "email-not-verified": "Not Verified",
    "last-entrance": "Last Entrance",
    "register-date": "Register Date"
  }
};
const components = {
  "ticket-status-badge": {
    filter: "Filter",
    "new": "New",
    replied: "Replied",
    closed: "Closed"
  },
  "website-activity-chart": {
    "new-registration": "New Registration",
    "new-ticket": "New Ticket",
    visitor: "Visitor",
    view: "View"
  },
  "site-navigation-menu": {
    panel: "Panel",
    statistics: "Statistics",
    posts: "Posts",
    tickets: "Tickets",
    players: "Players",
    view: "View",
    addons: "Addons",
    settings: "Settings",
    translations: "Translations"
  },
  navbar: {
    "navbar-toggle-tooltip": "Open/Close Menu",
    notifications: "Notifications",
    "show-all": "Show All",
    "account-dropdown": {
      session: "Session",
      profile: "Profile",
      logout: "Logout"
    }
  },
  sidebar: {
    "sidebar-toggle-tooltip": "Open/Close Menu",
    website: "Website",
    server: "Server",
    "show-website": "Website",
    "show-servers": "Servers"
  },
  "server-navigation-menu": {
    statistics: "Statistics",
    monitoring: "Monitoring",
    settings: "Settings",
    "no-selected-server": "No selected server.",
    "no-server-text": "Connect a server to view the server menu.",
    "connect-server": "Connect Server"
  },
  "post-row": {
    actions: "Actions",
    view: "View",
    "move-to-draft": "Move To Draft",
    publish: "Publish",
    "move-to-trash": "Move To Trash",
    "delete": "Delete",
    edit: "Edit",
    "no-category": "No Category",
    filter: "Filter"
  },
  "ticket-row": {
    select: "Select",
    view: "View",
    filter: "Filter",
    "no-category": "No Category",
    "player-name": "Player Name"
  },
  "player-row": {
    actions: "Actions",
    authorize: "Authorize",
    edit: "Edit",
    "remove-ban": "Remove Ban",
    ban: "Ban",
    view: "View"
  },
  "player-status-badge": {
    banned: "Banned",
    "in-game": "In Game",
    "in-website": "In Website",
    online: "Online",
    offline: "Offline"
  },
  "player-permission-badge": {
    filter: "Filter",
    player: "Player"
  },
  bottom: {
    help: "Help",
    "pano-market": "Pano Market",
    discord: "Discord"
  },
  "notification-container": {
    notification: "Notification"
  },
  "settings-layout": {
    website: "Website",
    platform: "Platform",
    updates: "Updates",
    about: "About"
  },
  "server-settings-layout": {
    server: "Server",
    "game-integration": "Game Integration"
  },
  modals: {
    "confirm-remove-pano-account": {
      title: "Are you sure to disconnect your online Pano account from this platform?"
    },
    "add-edit-post-category": {
      "create-category": "Create Category",
      "edit-category": "Edit Category",
      close: "Close",
      inputs: {
        title: {
          placeholder: "Title"
        },
        description: {
          placeholder: "Description"
        },
        url: {
          placeholder: "URL",
          helper: "It can only contain [A-Z/a-z/0-9/-] and can have a minimum of 3 and a maximum of 32 characters."
        }
      },
      save: "Save",
      create: "Create"
    },
    "add-edit-ticket-category": {
      "create-category": "Create Category",
      "edit-category": "Edit Category",
      close: "Close",
      inputs: {
        title: {
          placeholder: "Title"
        },
        description: {
          placeholder: "Description"
        }
      },
      save: "Save",
      create: "Create"
    },
    "authorize-player": {
      title: "Authorize Player",
      close: "Close",
      player: "Player",
      save: "Save"
    },
    "confirm-ban-player": {
      title: "Are you sure you want to ban this player?",
      "notify-with-email": "Notify by email",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-close-ticket": {
      "title-single": "Are you sure you want to close this ticket?",
      "title-multi": "Are you sure you want to close these tickets?",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-permission-group": {
      title: "Are you sure you want to permanently delete this authorization group?",
      description: "The following users in the authorization group will be changed to Player:",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-player": {
      title: "Are you sure you really want to delete this player?",
      inputs: {
        password: {
          placeholder: "Password"
        }
      },
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-post-category": {
      title: "Are you sure you want to permanently delete this category?",
      description: "The following posts in the category will be changed to Uncategorized:",
      "more-posts": "+{count} more posts",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-post": {
      "title-permanent": "Are you sure you want to permanently delete this post?",
      "title-trash": "Are you sure you want to move this post to the trash?",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-ticket-category": {
      "title-permanent": "Note: If you delete this category, the following tickets will remain Uncategorized:",
      title: "Are you sure you want to permanently delete this category?",
      "more-posts": "+{count} more tickets",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-disable-addon-will-cause-more-disable": {
      title: 'Are you sure to disable "{pluginId}" addon?',
      description: 'Disabling "{pluginId}" will cause disable these addons too:',
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-enabling-addon-will-cause-more-enable": {
      title: 'Are you sure to enable "{pluginId}" addon?',
      description: 'Enabling "{pluginId}" will cause enable these addons too:',
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-delete-ticket": {
      "title-single": "Are you sure you want to permanently delete this ticket?",
      "title-multi": "Are you sure you want to permanently delete these tickets?",
      cancel: "Cancel",
      yes: "Yes"
    },
    "confirm-remove-all-notifications": {
      title: "Are you sure you want to permanently delete all notifications?",
      cancel: "Cancel",
      yes: "Yes"
    },
    "connect-server": {
      title: "Connect Server",
      close: "Close",
      steps: {
        "1": "Install Game Server Plugin",
        "2": "Run Connection Command",
        "3": "Confirm Connection Request"
      },
      download: "Download File",
      copy: "Copy",
      copied: "Copied!",
      "code-refresh": "Code will refresh after {timeToRefreshKey} seconds.",
      "notification-will-come": "The connection request will come as a notification."
    },
    "make-main-server": {
      title: 'Are you sure you want to make "{serverName}" the main server?',
      no: "No",
      yes: "Yes"
    },
    "remove-server": {
      title: "Are you sure you want to remove this server?",
      "account-password": "Account Password",
      cancel: "Cancel",
      yes: "Yes"
    },
    "server-request": {
      title: 'Are you sure you want to connect the server "{serverName}" to the platform?',
      reject: "Reject",
      connect: "Connect"
    },
    servers: {
      "connect-server-button": "Connect Server",
      servers: "Servers",
      close: "Close",
      "main-server": "Main Server",
      online: "Online"
    },
    "unban-player": {
      title: "Are you sure you want to unban this player?",
      cancel: "Cancel",
      yes: "Yes"
    },
    "edit-player": {
      title: "Edit Player Information",
      close: "Close",
      inputs: {
        username: {
          placeholder: "Username",
          errors: {
            invalid: "Username is not valid",
            exists: "This username is used by another player"
          }
        },
        email: {
          title: "E-Mail",
          errors: {
            invalid: "E-Mail is not valid",
            exists: "This E-Mail address is used by another player"
          }
        },
        "new-password": {
          title: "New Password",
          errors: {
            invalid: "The new password must have a minimum of 6 and a maximum of 128 characters"
          }
        },
        "new-password-repeat": {
          title: "New Password Repeat",
          errors: {
            "not-match": "The passwords do not match"
          }
        },
        "can-open-ticket": "Can create ticket",
        "email-verified": "E-Mail is verified"
      },
      save: "Save"
    }
  },
  editor: {
    title: "Title {number}",
    bold: "Bold",
    italic: "Italic",
    underline: "Underline",
    strike: "Strikethrough",
    "bullet-list": "List",
    "ordered-list": "Ordered List",
    image: "Image",
    link: "Link",
    "text-color": "Text Color",
    "remove-text-color": "Remove Text Color"
  },
  "no-content": {
    "here-is-empty": "Here is empty."
  },
  pagination: {
    "previous-page": "Previous Page",
    "next-page": "Next Page"
  },
  splash: {
    errors: {
      session: "Session error",
      permission: "Permission error",
      connection: "Connection error"
    },
    refreshing: "Refreshing...",
    refresh: "Refresh"
  },
  "permission-group-row": {
    "delete": "Delete",
    edit: "Edit"
  },
  "post-category-row": {
    "delete": "Delete",
    edit: "Edit",
    view: "View"
  },
  "ticket-category-row": {
    "delete": "Delete",
    edit: "Edit"
  },
  toasts: {
    "accepted-server-connect-request": "Server connection request accepted.",
    "expired-server-connect-request": "Invalid server connection request.",
    "notifications-deleted-permanently": "All notifications have been deleted.",
    "permission-group-saved-or-created": {
      "permission-group": "Permission group {event}",
      updated: "updated.",
      saved: "saved."
    },
    "permission-group-save-error": "Failed to save permission group! Error: {errorCode}",
    "player-authorized-success": "Updated player permission group.",
    "player-ban": {
      "the-player": '"{username}" user {event}',
      banned: "banned.",
      "could-not-ban": "couldn't ban, error: {error}"
    },
    "player-deleted-success": 'Deleted player "{username}".',
    "player-info-saved-success": "Updated player information.",
    "player-unban": {
      "the-player": `"{username}" user's {event}`,
      "removed-ban": "ban removed.",
      "could-not-remove-ban": "couldn't remove ban, error: {error}"
    },
    "post-category-deleted-permanently": '"{title}" deleted permanently.',
    "post-deleted-permanently": '"{title}" is permanently deleted.',
    "post-moved-to-draft": '"{title}" is moved to drafts.',
    "post-moved-to-trash": '"{title}" is moved to trash.',
    "post-published": '"{title}" is published.',
    "post-saved": '"{title}" is saved.',
    "rejected-server-connect": "Server connection request denied.",
    "server-deleted-success": 'Deleted server "{name}".',
    "server-made-main": '"{name}" is designated as the main server.',
    "server-not-exists": "Server not found.",
    "server-selected": 'Selected "{name}".',
    "settings-save-error": "Failed to save settings! Error: {errorCode}",
    "settings-save-success": "Settings saved.",
    "ticket-category-deleted-permanently": '"{title}" is permanently deleted.',
    "ticket-closed": {
      multi: "{count} tickets closed.",
      single: "Ticket is closed."
    },
    "tickets-deleted-permanently": {
      multi: "{count} tickets permanently deleted.",
      single: "Ticket is permanently deleted."
    },
    "verification-email-sent-error": 'Failed to send verification e-mail to user "{username}". Error: {errorCode}',
    "verification-email-sent-successful": 'A verification e-mail was sent to the user "{username}".',
    "enabling-addon-failed-by-dependency-error": 'Failed to enable "{addon}" addon due to failed dependency plugins!',
    "failed-to-enable-addon-error": 'Failed to enable "{addon}". Check out the addon logs!',
    "pano-account-connect-success": "Your Pano account has been successfully connected!",
    "pano-account-disconnect-success": "Pano account removed successfully!",
    "pano-account-disconnect-fail": "An error occurred during the removing Pano account!",
    "email-config-validate-success": "E-Mail validated successfully!",
    "smtp-disabled-success": "E-mail disabled successfully!",
    "smtp-enabled-success": "E-mail enabled successfully!"
  }
};
const enUS = {
  buttons,
  pages,
  components,
  "page-error": {
    "404": "Enderman blocked this page from loading."
  }
};

export { buttons, components, enUS as default, pages };
//# sourceMappingURL=en-US-BgujcVOF.js.map
