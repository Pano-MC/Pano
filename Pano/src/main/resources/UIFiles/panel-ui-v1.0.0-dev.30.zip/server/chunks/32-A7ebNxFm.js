const index = 32;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C5ptN_YB.js')).default;
const imports = ["_app/immutable/nodes/32.CX6qFZoo.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=32-A7ebNxFm.js.map
