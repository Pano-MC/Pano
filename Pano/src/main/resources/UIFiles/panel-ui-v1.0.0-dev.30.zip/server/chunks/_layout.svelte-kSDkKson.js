import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { M as MainLayout } from './0-7ImEn9A0.js';
import './api.util-Cb5EDErE.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import 'fs';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './language.util-B5bwf1tX.js';
import './stores-BDx4Az-R.js';
import './NoContent-Cd8O1sR9.js';
import './auth.util-BRaxc5Jt.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './formatDistanceToNow-wbEYwSfo.js';
import './differenceInSeconds-C8IiJITI.js';

const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(MainLayout, "MainLayout").$$render($$result, { data }, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout as default };
//# sourceMappingURL=_layout.svelte-kSDkKson.js.map
