import{b as a}from"../chunks/entry.pJz25ewp.js";export{a as start};
