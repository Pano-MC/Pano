import{b as a}from"../chunks/entry.kWwTwVNp.js";export{a as start};
