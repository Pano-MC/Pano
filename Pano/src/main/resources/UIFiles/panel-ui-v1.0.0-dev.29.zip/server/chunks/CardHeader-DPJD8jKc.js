import { c as create_ssr_component } from './ssr-ffuobYCI.js';

const CardHeader = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="row gy-1"><div class="col-md-6 text-md-start text-center">${slots.left ? slots.left({}) : ``}</div> <div class="col-md-6 d-flex justify-content-md-end justify-content-center"> ${slots.right ? slots.right({}) : ``}</div></div>`;
});

export { CardHeader as C };
//# sourceMappingURL=CardHeader-DPJD8jKc.js.map
