import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, d as add_attribute, v as validate_component, h as each } from './ssr-ffuobYCI.js';
import { b as ApiUtil, c as PANO_WEBSITE_URL } from './api.util-Cb5EDErE.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import './client-CnCRRyPd.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { T as TicketStatusBadge } from './TicketStatusBadge-BiE81nbk.js';
import { D as Date_1 } from './Date-MmFinT7K.js';

async function load(event) {
  const { parent } = event;
  await parent();
  return await ApiUtil.get({
    path: `/api/panel/dashboard`,
    request: event
  });
}
const Dashboard = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.dashboard.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <div class="container"> ${data.gettingStartedBlocks.welcomeBoard ? `<div class="alert alert-success alert-dismissible animate__animated animate__zoomIn mb-3"><div class="row"><h5 class="mb-3"><!-- HTML_TAG_START -->${$_("pages.dashboard.welcome-card.description")}<!-- HTML_TAG_END --></h5> <div class="col-lg-4 mb-lg-0 mb-3"><p>${escape($_("pages.dashboard.welcome-card.connect-server-description"))}</p> <button class="btn btn-sm btn-primary" data-bs-target="#connectServer" data-bs-toggle="modal"><i class="fa-solid fa-plus me-2"></i> ${escape($_("pages.dashboard.welcome-card.connect-server"))}</button></div> <div class="col-lg-4"><ul class="list-unstyled mb-0"><li><a class="alert-link" href="${escape(base, true) + "/posts/create-post"}"><i class="fa-solid fa-pen me-2"></i> ${escape($_("pages.dashboard.welcome-card.publish-your-first-post"))}</a></li> <li><a class="alert-link" href="${escape(base, true) + "/view"}"><i class="fa-solid fa-brush me-2"></i> ${escape($_("pages.dashboard.welcome-card.change-theme"))}</a></li> <li><a class="alert-link" href="${escape(base, true) + "/addons"}"><i class="fa-solid fa-puzzle-piece me-2"></i> ${escape($_("pages.dashboard.welcome-card.manage-addons"))}</a></li> <li><a class="alert-link" href="${escape(base, true) + "/players"}"><i class="fa-solid fa-user-cog me-2"></i>${escape($_("pages.dashboard.welcome-card.manage-players"))}</a></li></ul></div> <div class="col-lg-4"><ul class="list-unstyled"><li><a class="alert-link" href="${escape(PANO_WEBSITE_URL, true) + "/addons"}" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square me-2"></i> ${escape($_("pages.dashboard.welcome-card.themes-and-extensions"))}</a></li> <li><a class="alert-link" href="${escape(PANO_WEBSITE_URL, true) + "/docs"}" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square me-2"></i> ${escape($_("pages.dashboard.welcome-card.documentations"))}</a></li> <li><a class="alert-link"${add_attribute("href", PANO_WEBSITE_URL, 0)} target="_blank"><i class="fa-solid fa-globe me-2"></i> ${escape($_("pages.dashboard.welcome-card.website"))}</a></li> <li><a class="alert-link" href="${escape(PANO_WEBSITE_URL, true) + "/discord"}" target="_blank"><i class="fab fa-discord me-2"></i> ${escape($_("pages.dashboard.welcome-card.discord"))}</a></li></ul></div></div> <button type="button"${add_attribute("title", $_("pages.dashboard.welcome-card.close-button"), 0)} class="btn-close" data-bs-dismiss="alert"></button></div>` : ``} <div class="row g-3"><div class="col-lg-6"> ${hasPermission(Permissions.MANAGE_TICKETS) ? `<div class="card"><div class="card-body"><h5 class="card-title">${escape($_("pages.dashboard.last-tickets.title"))}</h5> ${data.tickets.length === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : `<div class="table-responsive"><table class="table table-hover mb-0">${each(data.tickets, (ticket, index) => {
    return `<tbody><tr><td class="align-middle"><a href="${escape(base, true) + "/players/detail/" + escape(ticket.writer.username, true)}"><img src="${"https://minotar.net/avatar/" + escape(ticket.writer.username, true) + "/32"}"${add_attribute("alt", $_("pages.dashboard.last-tickets.player-name"), 0)} class="rounded-circle animate__animated animate__zoomIn" height="32" width="32"> </a></td> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/tickets/detail/" + escape(ticket.id, true)}"${add_attribute("title", $_("pages.dashboard.last-tickets.view"), 0)}>#${escape(ticket.id)} ${escape(ticket.title)}</a></td> <td class="align-middle text-nowrap">${validate_component(TicketStatusBadge, "TicketStatusBadge").$$render($$result, { status: ticket.status }, {}, {})}</td> <td class="align-middle text-nowrap"><span>${validate_component(Date_1, "Date").$$render($$result, { time: ticket.lastUpdate }, {}, {})}</span></td></tr> </tbody>`;
  })}</table></div>`}</div></div>` : ``}</div> <div class="col-lg-6" data-svelte-h="svelte-1cingc9"><div class="card"><div class="card-body"><h5 class="card-title">Logs</h5></div></div></div></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CZ8jq4PG.js')).default;
const universal_id = "src/routes/+page.js";
const imports = ["_app/immutable/nodes/12.CXbUooxQ.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/api.util.DA5pmtwJ.js","_app/immutable/chunks/stores.DYPJM7jX.js","_app/immutable/chunks/entry.kWwTwVNp.js","_app/immutable/chunks/paths.BJzMCz4s.js","_app/immutable/chunks/runtime.CNBVLHbk.js","_app/immutable/chunks/auth.util.C--Wq74g.js","_app/immutable/chunks/tooltip.util.A6wwJI5P.js","_app/immutable/chunks/NoContent.DaWe_qnI.js","_app/immutable/chunks/TicketStatusBadge.CJCUMXIm.js","_app/immutable/chunks/Date.D21mWBk-.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/language.util.aPVI1VQM.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js"];
const stylesheets = [];
const fonts = [];

var _12 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Dashboard as D, _12 as _ };
//# sourceMappingURL=12-CFT8pl1K.js.map
