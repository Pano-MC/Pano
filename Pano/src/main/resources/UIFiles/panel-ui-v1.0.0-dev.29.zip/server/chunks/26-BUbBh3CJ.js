import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each, d as add_attribute, i as createEventDispatcher, b as add_classes } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-Cb5EDErE.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { P as Pagination } from './Pagination--ODwq86l.js';
import { A as AddEditPostCategoryModal } from './AddEditPostCategoryModal-BamjU8eK.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { b as base } from './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';

const dialogID = "postCategoryDeleteConfirmationModal";
const category = writable({ posts: [] });
const ConfirmDeletePostCategoryModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $category, $$unsubscribe_category;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_category = subscribe(category, (value) => $category = value);
  $$unsubscribe__();
  $$unsubscribe_category();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-delete-post-category.title"))} ${$category.postCount !== 0 ? `<div class="mt-3 alert alert-warning text-left">${escape($_("components.modals.confirm-delete-post-category.description"))} <br> <br> ${each($category.posts, (post, index) => {
    return `<a class="badge bg-warning rounded-pill" href="${escape(base, true) + "/posts/detail/" + escape(post.id, true)}" target="_blank">${escape(post.title)} </a>`;
  })}</div> ${$category.postCount > 5 ? `${escape($_("components.modals.confirm-delete-post-category.more-posts", {
    values: { count: $category.postCount - 5 }
  }))}` : ``}` : ``}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-post-category.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-post-category.yes"))}</button></div></div></div> </div>`;
});
const PostCategoryRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { category: category2 } = $$props;
  let { index } = $$props;
  createEventDispatcher();
  if ($$props.category === void 0 && $$bindings.category && category2 !== void 0) $$bindings.category(category2);
  if ($$props.index === void 0 && $$bindings.index && index !== void 0) $$bindings.index(index);
  $$unsubscribe__();
  return `<tr${add_classes((category2.selected ? "table-primary" : "").trim())}><th scope="row" class="align-middle"><a${add_attribute("title", $_("components.post-category-row.delete"), 0)} class="btn btn-sm btn-link link-danger" href="javascript:void(0);"><i class="fas fa-trash"></i></a></th> <td class="align-middle text-nowrap"><a href="javascript:void(0);"${add_attribute("title", $_("components.post-category-row.edit"), 0)}>${escape(category2.title)}</a></td> <td class="align-middle text-nowrap">${escape(category2.description)}</td> <td class="align-middle"><a href="${escape("", true) + "/blog/category/" + escape(category2.url, true)}" target="_blank"${add_attribute("title", $_("components.post-category-row.view"), 0)}>/category/${escape(category2.url)}</a></td> <td class="d-none"><input value="${"#" + escape(category2.color, true)}" class="form-control form-control-sm bg-transparent" disabled type="color"></td> </tr>`;
});
async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const page = searchParams.get("page") || 1;
  const queryParams = buildQueryParams({ page });
  const body = await ApiUtil.get({
    path: `/api/panel/post/categories` + queryParams,
    request: event
  });
  if (body.error) {
    if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
      throw error(404, body.error);
    }
    throw error(500, body.error);
  }
  body.page = parseInt(page);
  return body;
}
const PostCategories = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.post-categories.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    middle: () => {
      return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
        default: () => {
          return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/posts" }, {}, {
            default: () => {
              return `${escape($_("pages.post-categories.posts"))}`;
            }
          })} ${validate_component(CardMenuItem, "CardMenuItem").$$render(
            $$result,
            {
              href: "/posts/categories",
              startsWith: true
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.post-categories-button"))}`;
              }
            }
          )}`;
        }
      })}`;
    },
    right: () => {
      return `<button class="btn btn-secondary" type="button" slot="right"><i class="fas fa-plus me-2"></i>${escape($_("pages.post-categories.create-category-button"))}</button>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.post-categories.card-title", { values: { count: data.categoryCount } }))}</h5>`;
    }
  })}  ${data.categoryCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ``}  ${data.categoryCount > 0 ? `<div class="table-responsive"><table class="table table-hover"><thead><tr><th scope="col"></th> <th class="align-middle" scope="col">${escape($_("pages.post-categories.category"))}</th> <th scope="col" class="align-middle">${escape($_("pages.post-categories.description"))}</th> <th scope="col" class="align-middle">${escape($_("pages.post-categories.url"))}</th> <th scope="col" class="d-none align-middle">${escape($_("pages.post-categories.color"))}</th></tr></thead> <tbody>${each(data.categories, (category2, index) => {
    return `${validate_component(PostCategoryRow, "PostCategoryRow").$$render($$result, { category: category2, index }, {}, {})}`;
  })}</tbody></table></div>` : ``}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div></article>  ${validate_component(ConfirmDeletePostCategoryModal, "ConfirmDeletePostCategoryModal").$$render($$result, {}, {}, {})}  ${validate_component(AddEditPostCategoryModal, "AddEditPostCategoryModal").$$render($$result, {}, {}, {})}`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 26;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D0qyW4f4.js')).default;
const universal_id = "src/routes/posts/categories/+page.js";
const imports = ["_app/immutable/nodes/26.D2uMDqvZ.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.BeSfBBL_.js","_app/immutable/chunks/entry.kWwTwVNp.js","_app/immutable/chunks/paths.BJzMCz4s.js","_app/immutable/chunks/api.util.DA5pmtwJ.js","_app/immutable/chunks/stores.DYPJM7jX.js","_app/immutable/chunks/runtime.CNBVLHbk.js","_app/immutable/chunks/Pagination.6RUHIuaq.js","_app/immutable/chunks/AddEditPostCategoryModal.BC9WUdQe.js","_app/immutable/chunks/ToastContainer.BFTE14Nz.js","_app/immutable/chunks/NoContent.DaWe_qnI.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.BvONY-DZ.js","_app/immutable/chunks/CardMenuItem.CffKs3V3.js"];
const stylesheets = [];
const fonts = [];

var _26 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PostCategories as P, _26 as _ };
//# sourceMappingURL=26-BUbBh3CJ.js.map
