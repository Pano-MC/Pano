import { c as create_ssr_component, f as getContext } from './ssr-ffuobYCI.js';
import './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';

async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = { server: {}, connectedServerCount: 0 };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  return data;
}
const ServerMonitoring = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.server.monitoring.title");
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `Monitoring page`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 30;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CJj0k_8C.js')).default;
const universal_id = "src/routes/server/monitoring/+page.js";
const imports = ["_app/immutable/nodes/30.DPEkJo_l.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.CNBVLHbk.js","_app/immutable/chunks/entry.kWwTwVNp.js","_app/immutable/chunks/paths.BJzMCz4s.js"];
const stylesheets = [];
const fonts = [];

var _30 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ServerMonitoring as S, _30 as _ };
//# sourceMappingURL=30-DUATrKhN.js.map
