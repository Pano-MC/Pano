import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as TicketDetail } from './41-DvgRbDD1.js';
import './index-DzcLzHBX.js';
import './Editor-CNgXF1Vs.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './TicketStatusBadge-BiE81nbk.js';
import './paths-C6LjEmZF.js';
import './api.util-Cb5EDErE.js';
import './prod-ssr-DxkyU4_t.js';
import './ToastContainer-D6cKqDaa.js';
import './Date-MmFinT7K.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-B5bwf1tX.js';
import './format-DZNhO2Yc.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(TicketDetail, "TicketDetail").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-HbN6_S6X.js.map
