import { c as create_ssr_component, v as validate_component, d as add_attribute } from './ssr-ffuobYCI.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './paths-C6LjEmZF.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './stores-BDx4Az-R.js';

const Translations = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `<div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div slot="right" class="hstack gap-2"><select class="form-select" name="selectLanguage" id="selectLanguage"><option selected value="en-us" data-svelte-h="svelte-yp7xu7">English</option><option value="tr" data-svelte-h="svelte-etbate">Turkish</option><option value="ru" data-svelte-h="svelte-vbpwzq">Russian</option></select> <button class="btn btn-secondary disabled" disabled data-svelte-h="svelte-omd7lb">Save</button></div>`;
    },
    middle: () => {
      return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
        default: () => {
          return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/translations", startsWith: true }, {}, {
            default: () => {
              return `Platform`;
            }
          })} ${validate_component(CardMenuItem, "CardMenuItem").$$render(
            $$result,
            {
              href: "/translations/themes",
              startsWith: true
            },
            {},
            {
              default: () => {
                return `Theme`;
              }
            }
          )} ${validate_component(CardMenuItem, "CardMenuItem").$$render(
            $$result,
            {
              href: "/translations/addons",
              startsWith: true
            },
            {},
            {
              default: () => {
                return `Addons`;
              }
            }
          )}`;
        }
      })}`;
    },
    left: () => {
      return `<a href="" class="btn btn-link" role="button" slot="left" data-svelte-h="svelte-1vgwkpz"><i class="fa-solid fa-earth-americas me-2"></i>
      Manage Languages</a>`;
    }
  })} <div class="card"><div class="card-body vstack gap-3">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/", active: true }, {}, {
            default: () => {
              return `All`;
            }
          })} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/" }, {}, {
            default: () => {
              return `Original`;
            }
          })} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/" }, {}, {
            default: () => {
              return `Modified`;
            }
          })}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left" data-svelte-h="svelte-dt3t5y">Platform Translations (307)</h5>`;
    }
  })} <div class="accordion" data-svelte-h="svelte-cfnh28"><div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseplatformTranslations">Panel</button></h2> <div id="collapseplatformTranslations" class="accordion-collapse collapse show"><div class="accordion-body"><div class="row-cols-3 g-2 d-flex flex-nowrap"><label for="keyTranslation">Key</label> <label for="originalTranslation">Original</label> <label for="customTranslation">Custom</label> <label for=""></label></div> <div class="input-group row-cols-3 d-flex flex-nowrap g-2 overflow-x-auto"><input type="text" class="form-control font-monospace" id="keyTranslation" value="components.modals.confirm-disable-addon-will-cause-more-disable.title"> <input type="text" class="form-control" id="originalTranslation"${add_attribute("value", `Are you sure to disable "{pluginId}" addon?`, 0)}> <input type="text" class="form-control border-danger" id="customTranslation"${add_attribute("value", `"{pluginId}" eklentisini devre dışı bırakmak istediğinizden emin misiniz?`, 0)}></div></div></div></div> <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOtherTranslations">Other (1)</button></h2> <div id="collapseOtherTranslations" class="accordion-collapse collapse"><div class="accordion-body"><div class="row-cols-3 g-2 d-flex flex-nowrap"><label for="keyTranslation">Key</label> <label for="originalTranslation">Original</label> <label for="customTranslation">Custom</label> <label for=""></label></div> <div class="input-group row-cols-3 d-flex flex-nowrap g-2 overflow-x-auto"><input type="text" class="form-control font-monospace" id="keyTranslation" value="DATA"> <input type="text" class="form-control" id="originalTranslation"> <input type="text" class="form-control border-danger" id="customTranslation"></div></div></div></div></div></div></div> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Translations, "Translations").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BuWhr0TO.js.map
