import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';

const LogsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `Logs layout.

<br> ${slots.default ? slots.default({}) : ``}`;
});
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(LogsLayout, "LogsLayout").$$render($$result, {}, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout as default };
//# sourceMappingURL=_layout.svelte-3Z6FAi5I.js.map
