import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, d as add_attribute, h as each, i as createEventDispatcher, b as add_classes } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-Cb5EDErE.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination--ODwq86l.js';
import './ToastContainer-D6cKqDaa.js';
import { D as Date_1 } from './Date-MmFinT7K.js';
import { T as TicketStatusBadge } from './TicketStatusBadge-BiE81nbk.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';

const TicketRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $checkedList, $$unsubscribe_checkedList;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { ticket } = $$props;
  let { checkedList: checkedList2 } = $$props;
  $$unsubscribe_checkedList = subscribe(checkedList2, (value) => $checkedList = value);
  createEventDispatcher();
  if ($$props.ticket === void 0 && $$bindings.ticket && ticket !== void 0) $$bindings.ticket(ticket);
  if ($$props.checkedList === void 0 && $$bindings.checkedList && checkedList2 !== void 0) $$bindings.checkedList(checkedList2);
  $$unsubscribe__();
  $$unsubscribe_checkedList();
  return `<tr${add_classes((ticket.selected ? "table-primary" : "").trim())}><th scope="row" class="align-middle"><div class="form-check"><input${add_attribute("title", $_("components.ticket-row.select"), 0)} class="form-check-input" id="${"postCheck" + escape(ticket.id, true)}" type="checkbox"${add_attribute("checked", $checkedList[ticket.id], 1)}></div></th> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/tickets/detail/" + escape(ticket.id, true)}"${add_attribute("title", $_("components.ticket-row.view"), 0)}>#${escape(ticket.id)} ${escape(ticket.title)}</a></td> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.ticket-row.filter"), 0)} href="${escape(base, true) + "/tickets?categoryUrl=" + escape(ticket.category.url, true)}">${escape(ticket.category.title === "-" ? $_("components.ticket-row.no-category") : ticket.category.title)}</a></td> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/players/detail/" + escape(ticket.writer.username, true)}"${add_attribute("title", $_("components.ticket-row.view"), 0)}><img src="${"https://minotar.net/avatar/" + escape(ticket.writer.username, true) + "/32"}"${add_attribute("alt", $_("components.ticket-row.player-name"), 0)} class="rounded-circle animate__animated animate__zoomIn me-2" height="32" width="32"> ${escape(ticket.writer.username)}</a></td> <td class="align-middle text-nowrap">${validate_component(TicketStatusBadge, "TicketStatusBadge").$$render($$result, { status: ticket.status }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: ticket.lastUpdate }, {}, {})}</td> </tr>`;
});
let checkedList = writable([]);
const PageTypes = Object.freeze({
  ALL: "ALL",
  WAITING_REPLY: "WAITING_REPLY",
  CLOSED: "CLOSED"
});
const DefaultPageType = PageTypes.ALL;
async function load(event) {
  const { parent, url: { searchParams } } = event;
  await parent();
  const page = parseInt(searchParams.get("page")) || 1;
  const categoryUrl = searchParams.get("categoryUrl");
  const pageType = searchParams.get("pageType") || DefaultPageType;
  if (!Object.values(PageTypes).includes(pageType)) {
    throw error(404, "PAGE_NOT_FOUND");
  }
  const queryParams = buildQueryParams({ page, pageType, categoryUrl });
  const body = await ApiUtil.get({
    path: `/api/panel/tickets` + queryParams,
    request: event
  });
  if (body.error) {
    if (body.error === "PAGE_NOT_FOUND") {
      throw error(404, body.error);
    }
    throw error(500, body.error);
  }
  body.page = page;
  body.pageType = pageType;
  body.categoryUrl = categoryUrl;
  return body;
}
function isAllTicketsSelected(ticketsList, selectedList) {
  let isAllSelected = true;
  ticketsList.forEach((ticket) => {
    if (!selectedList[ticket.id]) isAllSelected = false;
  });
  return isAllSelected;
}
const Tickets = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $checkedList, $$unsubscribe_checkedList;
  let $_, $$unsubscribe__;
  $$unsubscribe_checkedList = subscribe(checkedList, (value) => $checkedList = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  let firstLoad = true;
  function getListOfChecked(list) {
    const result = Object.keys(list).filter((key) => list[key]);
    if (result.length > 0) firstLoad = false;
    return result;
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set(data.categoryUrl ? $_("pages.tickets.category-tickets-title", {
        values: {
          category: (data.category?.title || "-") === "-" ? $_("pages.tickets.no-category") : data.category?.title || "-"
        }
      }) : $_("pages.tickets.title", {
        values: {
          pageType: data.pageType === PageTypes.WAITING_REPLY ? $_("pages.tickets.waiting-reply") + " " : data.pageType === PageTypes.CLOSED ? $_("pages.tickets.closed") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe_checkedList();
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div class="${[
        "animate__animated animate__faster " + escape(
          getListOfChecked($checkedList).length > 0 ? "animate__slideInUp" : "animate__slideOutDown",
          true
        ) + " faster",
        firstLoad ? "d-none" : ""
      ].join(" ").trim()}" slot="right"><button class="${[
        "btn btn-link link-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" type="button" data-svelte-h="svelte-gqbpao"><i class="fas fa-trash"></i></button> <button class="${[
        "btn btn-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" type="button"><i class="fas fa-times me-2"></i> ${escape($_("pages.tickets.close-ticket-button"))}</button></div>`;
    },
    middle: () => {
      return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
        default: () => {
          return `${!data.categoryUrl ? `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/tickets" }, {}, {
            default: () => {
              return `${escape($_("pages.ticket-categories.tickets"))}`;
            }
          })} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/tickets/categories" }, {}, {
            default: () => {
              return `${escape($_("pages.tickets.ticket-categories-button"))}`;
            }
          })}` : ``}`;
        }
      })}`;
    },
    left: () => {
      return `<div slot="left">${data.categoryUrl ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/tickets"}"><i class="fas fa-arrow-left me-2"></i> ${escape($_("buttons.tickets"))}</a>` : ``}</div>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${!data.categoryUrl ? `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets",
              active: data.pageType === PageTypes.ALL
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.all"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets?pageType=WAITING_REPLY",
              active: data.pageType === PageTypes.WAITING_REPLY
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.waiting-reply"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets?pageType=CLOSED",
              active: data.pageType === PageTypes.CLOSED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.closed"))}`;
              }
            }
          )}` : ``}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.tickets.table-title", {
        values: {
          ticketCount: data.ticketCount,
          pageType: data.pageType === PageTypes.WAITING_REPLY ? $_("pages.tickets.waiting-reply") : data.pageType === PageTypes.CLOSED ? $_("pages.tickets.closed") : ""
        }
      }) + (getListOfChecked($checkedList).length > 0 ? ", " + $_("pages.tickets.amount-selected", {
        values: {
          amount: getListOfChecked($checkedList).length
        }
      }) : ""))}</h5>`;
    }
  })}  ${data.ticketCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle" scope="col"><div class="form-check"><input${add_attribute("title", $_("pages.tickets.select-all"), 0)} class="form-check-input" ${isAllTicketsSelected(data.tickets, $checkedList) ? "checked" : ""} id="selectAll" type="checkbox"></div></th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.title"))}</th> <th class="${["align-middle", data.categoryUrl ? "table-primary" : ""].join(" ").trim()}" scope="col">${escape($_("pages.tickets.table.category"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.player"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.status"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.last-reply"))}</th></tr></thead> <tbody>${each(data.tickets, (ticket, index) => {
    return `${validate_component(TicketRow, "TicketRow").$$render($$result, { ticket, checkedList }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </article>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 39;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BfPRPJuK.js')).default;
const universal_id = "src/routes/tickets/+page.js";
const imports = ["_app/immutable/nodes/39.DSwCcuQX.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.BeSfBBL_.js","_app/immutable/chunks/entry.kWwTwVNp.js","_app/immutable/chunks/paths.BJzMCz4s.js","_app/immutable/chunks/api.util.DA5pmtwJ.js","_app/immutable/chunks/stores.DYPJM7jX.js","_app/immutable/chunks/runtime.CNBVLHbk.js","_app/immutable/chunks/Pagination.6RUHIuaq.js","_app/immutable/chunks/ConfirmDeleteTicketModal.C6xE5cai.js","_app/immutable/chunks/ToastContainer.BFTE14Nz.js","_app/immutable/chunks/TicketStatusBadge.CJCUMXIm.js","_app/immutable/chunks/Date.D21mWBk-.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.A6wwJI5P.js","_app/immutable/chunks/language.util.aPVI1VQM.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/NoContent.DaWe_qnI.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.BvONY-DZ.js","_app/immutable/chunks/CardFilters.Dv5sWyVb.js","_app/immutable/chunks/CardMenuItem.CffKs3V3.js"];
const stylesheets = [];
const fonts = [];

var _39 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Tickets as T, _39 as _ };
//# sourceMappingURL=39-DWlenvkW.js.map
