import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, v as validate_component, d as add_attribute, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { E as Editor_1 } from './Editor-CNgXF1Vs.js';
import { a as TicketStatuses, T as TicketStatusBadge } from './TicketStatusBadge-BiE81nbk.js';
import { b as ApiUtil } from './api.util-Cb5EDErE.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import { D as Date_1 } from './Date-MmFinT7K.js';

const css = {
  code: ".answer>p{margin-bottom:0}",
  map: '{"version":3,"file":"TicketDetail.svelte","sources":["TicketDetail.svelte"],"sourcesContent":["<style global>\\n  :global(.answer) > :global(p) {\\n    margin-bottom: 0;\\n  }\\n</style>\\n\\n<article class=\\"container\\">\\n  <div\\n    class=\\"row justify-content-between mb-3 animate__animated animate__slideInUp\\">\\n    <div class=\\"col-auto\\">\\n      <a class=\\"btn btn-link\\" role=\\"button\\" href=\\"{base}/tickets\\">\\n        <i class=\\"fas fa-arrow-left me-2\\"></i>\\n        {$_(\\"pages.ticket-detail.tickets\\")}\\n      </a>\\n    </div>\\n    <div class=\\"col-auto ml-auto\\">\\n      <button\\n        class=\\"btn btn-link link-danger\\"\\n        type=\\"button\\"\\n        on:click=\\"{() => showDeleteTicketModal([data.ticket.id])}\\">\\n        <i class=\\"fas fa-trash\\"></i>\\n      </button>\\n      {#if data.ticket.status !== TicketStatuses.CLOSED}\\n        <button\\n          class=\\"btn btn-danger\\"\\n          type=\\"button\\"\\n          on:click=\\"{() => showCloseTicketModal([data.ticket.id])}\\">\\n          <i class=\\"fas fa-times me-2\\"></i>\\n          {$_(\\"pages.ticket-detail.close-ticket\\")}\\n        </button>\\n      {/if}\\n    </div>\\n  </div>\\n\\n  <div class=\\"card mb-3\\">\\n    <div class=\\"card-header\\">\\n      <div class=\\"row\\">\\n        <div class=\\"col\\">\\n          <h5 class=\\"card-title\\">{data.ticket.title}</h5>\\n          <small class=\\"mb-0\\">\\n            {@html $_(\\"pages.ticket-detail.by-who\\", {\\n              values: {\\n                username: `<a href=\\"${base}/players/detail/${data.ticket.username}\\"\\n              >${data.ticket.username}</a>`,\\n              },\\n            })}\\n            <Date time=\\"{data.ticket.date}\\" />,\\n            {@html $_(\\"pages.ticket-detail.opened-in-category\\", {\\n              values: {\\n                category: `<a href=\\"${base}/tickets?categoryUrl=${data.ticket.category.url}\\"\\n              >${\\n                data.ticket.category.title === \\"-\\"\\n                  ? $_(\\"pages.ticket-detail.no-category\\")\\n                  : data.ticket.category.title\\n              }</a>`,\\n              },\\n            })}\\n          </small>\\n        </div>\\n        <div class=\\"col-auto\\">\\n          <TicketStatusBadge status=\\"{data.ticket.status}\\" />\\n        </div>\\n      </div>\\n    </div>\\n    <div\\n      class=\\"card-body\\"\\n      id=\\"messageSection\\"\\n      bind:this=\\"{messagesSectionDiv}\\"\\n      bind:clientHeight=\\"{$messagesSectionClientHeight}\\">\\n      {#if data.ticket.messages.length < data.ticket.count && data.ticket.count > 5}\\n        <div class=\\"position-relative\\">\\n          <button\\n            class=\\"btn btn-sm btn-secondary position-absolute top-50 start-50 translate-middle\\"\\n            class:disabled=\\"{loadMoreLoading}\\"\\n            on:click=\\"{loadMore}\\"\\n            ><i class=\\"fas fa-arrow-up me-2\\"></i>\\n            {$_(\\"pages.ticket-detail.previous-messages\\", {\\n              values: {\\n                count:\\n                  data.ticket.count -\\n                  (data.ticket.messages.length - sentMessageCount),\\n              },\\n            })}\\n          </button>\\n        </div>\\n      {/if}\\n\\n      <div class=\\"vstack gap-2\\">\\n        {#each data.ticket.messages as message, index (message)}\\n          {#if message.panel}\\n            <div class=\\"row g-2 flex-nowrap\\">\\n              <div class=\\"col d-flex justify-content-end\\">\\n                <div class=\\"card text-bg-secondary\\">\\n                  <div class=\\"card-header small\\">\\n                    <Date time=\\"{message.date}\\" />\\n                  </div>\\n                  <div class=\\"card-body answer\\">\\n                    {@html message.message}\\n                  </div>\\n                </div>\\n              </div>\\n              <div class=\\"col-auto\\">\\n                <a href=\\"{base}/players/detail/{message.username}\\">\\n                  <img\\n                    src=\\"https://minotar.net/avatar/{message.username}/48\\"\\n                    alt=\\"{message.username}\\"\\n                    class=\\"rounded animate__animated animate__zoomIn\\"\\n                    use:tooltip=\\"{[message.username, { placement: \'bottom\' }]}\\"\\n                    width=\\"48\\"\\n                    height=\\"48\\" />\\n                </a>\\n              </div>\\n            </div>\\n          {:else}\\n            <div class=\\"row g-2 flex-nowrap\\">\\n              <div class=\\"col-auto\\">\\n                <a href=\\"{base}/players/detail/{message.username}\\">\\n                  <img\\n                    src=\\"https://minotar.net/avatar/{message.username}/48\\"\\n                    alt=\\"{message.username}\\"\\n                    class=\\"rounded animate__animated animate__zoomIn\\"\\n                    use:tooltip=\\"{[message.username, { placement: \'bottom\' }]}\\"\\n                    width=\\"48\\"\\n                    height=\\"48\\" />\\n                </a>\\n              </div>\\n              <div class=\\"col hstack gap-2\\">\\n                <div class=\\"card\\">\\n                  <div class=\\"card-header small\\">\\n                    <Date time=\\"{message.date}\\" />\\n                  </div>\\n                  <div class=\\"card-body\\">\\n                    {message.message}\\n                  </div>\\n                </div>\\n              </div>\\n            </div>\\n          {/if}\\n        {/each}\\n      </div>\\n      <hr />\\n\\n      <!-- Send Message Section -->\\n      <div\\n        class=\\"row align-items-end g-2\\"\\n        class:d-none=\\"{data.ticket.status === TicketStatuses.CLOSED}\\">\\n        <div class=\\"col\\">\\n          <!-- Editor -->\\n          <Editor bind:content=\\"{messageText}\\" bind:isEmpty=\\"{isEditorEmpty}\\" />\\n          <!-- Editor End -->\\n        </div>\\n        <div class=\\"col-auto\\">\\n          <button\\n            class=\\"btn btn-secondary mt-lg-0 mt-3\\"\\n            on:click=\\"{sendMessage}\\"\\n            class:disabled=\\"{messageSendLoading || isEditorEmpty}\\"\\n            :disabled=\\"{messageSendLoading || isEditorEmpty}\\">\\n            <i class=\\"fas fa-paper-plane\\"></i>\\n            <span class=\\"d-xl-inline d-none ms-2\\"\\n              >{$_(\\"pages.ticket-detail.send-button\\")}</span>\\n          </button>\\n        </div>\\n      </div>\\n    </div>\\n  </div>\\n</article>\\n\\n<script context=\\"module\\">\\n  import { writable } from \\"svelte/store\\";\\n\\n  import ApiUtil from \\"$lib/api.util.js\\";\\n\\n  import { TicketStatuses } from \\"$lib/component/badges/TicketStatusBadge.svelte\\";\\n  import Editor from \\"$lib/component/Editor.svelte\\";\\n  import { error } from \\"@sveltejs/kit\\";\\n\\n  /**\\n   * @type {import(\'@sveltejs/kit\').PageLoad}\\n   */\\n  export async function load(event) {\\n    const { parent } = event;\\n    await parent();\\n\\n    const id = event.params.id;\\n\\n    const body = await ApiUtil.get({\\n      path: `/api/panel/tickets/${id}`,\\n      request: event,\\n    })\\n\\n    if (body.error) {\\n      if (body.error === \\"NOT_EXISTS\\" || body.error === \\"PAGE_NOT_FOUND\\") {\\n        throw error(404, body.error);\\n      }\\n\\n      throw error(500, body.error);\\n    }\\n\\n    body.ticket.id = parseInt(id);\\n\\n    return body;\\n  }\\n<\/script>\\n\\n<script>\\n  import { afterUpdate, getContext, onMount } from \\"svelte\\";\\n  import { _ } from \\"svelte-i18n\\";\\n\\n  import { goto } from \\"$app/navigation\\";\\n  import { base } from \\"$app/paths\\";\\n\\n  import tooltip from \\"$lib/tooltip.util.js\\";\\n\\n  import {\\n    setCallback as setCloseTicketModalCallback,\\n    show as showCloseTicketModal,\\n  } from \\"$lib/component/modals/ConfirmCloseTicketModal.svelte\\";\\n  import {\\n    setCallback as setDeleteTicketModalCallback,\\n    show as showDeleteTicketModal,\\n  } from \\"$lib/component/modals/ConfirmDeleteTicketModal.svelte\\";\\n\\n  import Date from \\"$lib/component/Date.svelte\\";\\n  import TicketStatusBadge from \\"$lib/component/badges/TicketStatusBadge.svelte\\";\\n\\n  export let data;\\n\\n  const pageTitle = getContext(\\"pageTitle\\");\\n\\n  pageTitle.set(\\"#\\" + data.ticket.id + \\" \\" + limitTitle(data.ticket.title));\\n\\n  let messagesSectionDiv;\\n  let loadMoreLoading = false;\\n  let messageSendLoading = false;\\n\\n  let messageText = \\"\\";\\n  let isEditorEmpty = true;\\n\\n  let shouldScroll = true;\\n\\n  let sentMessageCount = 0;\\n\\n  const messagesSectionClientHeight = writable(0);\\n\\n  function loadMore() {\\n    loadMoreLoading = true;\\n\\n    ApiUtil.get({\\n      path: `/api/panel/tickets/${data.ticket.id}/messages?lastMessageId=${data.ticket.messages[0].id}`,\\n      handler: (body, reject) => {\\n        if (body.error) {\\n          if (body.error === \\"NOT_EXISTS\\") {\\n            goto(base + \\"/error-404\\");\\n\\n            return\\n          }\\n\\n          reject();\\n          return;\\n        }\\n\\n        body.messages.reverse().forEach((message) => {\\n          data.ticket.messages.unshift(message);\\n        });\\n\\n        data.ticket.messages = data.ticket.messages;\\n      }\\n    })\\n  }\\n\\n  function sendMessage() {\\n    messageSendLoading = true;\\n\\n    ApiUtil.post({\\n      path: `/api/panel/tickets/${data.ticket.id}/message`,\\n      body: {\\n        message: messageText,\\n      },\\n      handler: (body, reject) => {\\n        if (body.error) {\\n          if (body.error === \\"NOT_EXISTS\\") {\\n            goto(base + \\"/error-404\\");\\n\\n            return\\n          }\\n\\n          reject();\\n          return;\\n        }\\n\\n        shouldScroll = true;\\n\\n        data.ticket.messages.push(body.message);\\n\\n        sentMessageCount++;\\n\\n        data.ticket.status = TicketStatuses.REPLIED;\\n        messageText = \\"\\";\\n\\n        messageSendLoading = false;\\n      }\\n    })\\n  }\\n\\n  function limitTitle(text) {\\n    const limit = 32;\\n\\n    if (text.length > limit) {\\n      text = text.substring(0, limit) + \\"...\\";\\n    }\\n\\n    return text;\\n  }\\n\\n  setCloseTicketModalCallback(() => {\\n    data.ticket.status = TicketStatuses.CLOSED;\\n  });\\n\\n  setDeleteTicketModalCallback(() => {\\n    goto(base + \\"/tickets\\");\\n  });\\n\\n  afterUpdate(() => {\\n    if (shouldScroll && messagesSectionDiv.scrollHeight > 0) {\\n      messagesSectionDiv.scrollTo(0, messagesSectionDiv.scrollHeight);\\n\\n      shouldScroll = false;\\n    }\\n  });\\n\\n  onMount(() => {\\n    shouldScroll = true;\\n  });\\n<\/script>\\n"],"names":[],"mappings":"AACU,OAAQ,CAAW,CAAG,CAC5B,aAAa,CAAE,CACjB"}'
};
async function load(event) {
  const { parent } = event;
  await parent();
  const id = event.params.id;
  const body = await ApiUtil.get({
    path: `/api/panel/tickets/${id}`,
    request: event
  });
  if (body.error) {
    if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
      throw error(404, body.error);
    }
    throw error(500, body.error);
  }
  body.ticket.id = parseInt(id);
  return body;
}
function limitTitle(text) {
  const limit = 32;
  if (text.length > limit) {
    text = text.substring(0, limit) + "...";
  }
  return text;
}
const TicketDetail = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $$unsubscribe_messagesSectionClientHeight;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("#" + data.ticket.id + " " + limitTitle(data.ticket.title));
  let messagesSectionDiv;
  let messageText = "";
  let isEditorEmpty = true;
  let sentMessageCount = 0;
  const messagesSectionClientHeight = writable(0);
  $$unsubscribe_messagesSectionClientHeight = subscribe(messagesSectionClientHeight, (value) => value);
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$result.css.add(css);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `<article class="container"><div class="row justify-content-between mb-3 animate__animated animate__slideInUp"><div class="col-auto"><a class="btn btn-link" role="button" href="${escape(base, true) + "/tickets"}"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.ticket-detail.tickets"))}</a></div> <div class="col-auto ml-auto"><button class="btn btn-link link-danger" type="button" data-svelte-h="svelte-eeo2bm"><i class="fas fa-trash"></i></button> ${data.ticket.status !== TicketStatuses.CLOSED ? `<button class="btn btn-danger" type="button"><i class="fas fa-times me-2"></i> ${escape($_("pages.ticket-detail.close-ticket"))}</button>` : ``}</div></div> <div class="card mb-3"><div class="card-header"><div class="row"><div class="col"><h5 class="card-title">${escape(data.ticket.title)}</h5> <small class="mb-0"><!-- HTML_TAG_START -->${$_("pages.ticket-detail.by-who", {
      values: {
        username: `<a href="${base}/players/detail/${data.ticket.username}"
              >${data.ticket.username}</a>`
      }
    })}<!-- HTML_TAG_END --> ${validate_component(Date_1, "Date").$$render($$result, { time: data.ticket.date }, {}, {})},
            <!-- HTML_TAG_START -->${$_("pages.ticket-detail.opened-in-category", {
      values: {
        category: `<a href="${base}/tickets?categoryUrl=${data.ticket.category.url}"
              >${data.ticket.category.title === "-" ? $_("pages.ticket-detail.no-category") : data.ticket.category.title}</a>`
      }
    })}<!-- HTML_TAG_END --></small></div> <div class="col-auto">${validate_component(TicketStatusBadge, "TicketStatusBadge").$$render($$result, { status: data.ticket.status }, {}, {})}</div></div></div> <div class="card-body" id="messageSection"${add_attribute("this", messagesSectionDiv, 0)}>${data.ticket.messages.length < data.ticket.count && data.ticket.count > 5 ? `<div class="position-relative"><button class="${[
      "btn btn-sm btn-secondary position-absolute top-50 start-50 translate-middle",
      ""
    ].join(" ").trim()}"><i class="fas fa-arrow-up me-2"></i> ${escape($_("pages.ticket-detail.previous-messages", {
      values: {
        count: data.ticket.count - (data.ticket.messages.length - sentMessageCount)
      }
    }))}</button></div>` : ``} <div class="vstack gap-2">${each(data.ticket.messages, (message, index) => {
      return `${message.panel ? `<div class="row g-2 flex-nowrap"><div class="col d-flex justify-content-end"><div class="card text-bg-secondary"><div class="card-header small">${validate_component(Date_1, "Date").$$render($$result, { time: message.date }, {}, {})}</div> <div class="card-body answer"><!-- HTML_TAG_START -->${message.message}<!-- HTML_TAG_END --></div> </div></div> <div class="col-auto"><a href="${escape(base, true) + "/players/detail/" + escape(message.username, true)}"><img src="${"https://minotar.net/avatar/" + escape(message.username, true) + "/48"}"${add_attribute("alt", message.username, 0)} class="rounded animate__animated animate__zoomIn" width="48" height="48"> </a></div> </div>` : `<div class="row g-2 flex-nowrap"><div class="col-auto"><a href="${escape(base, true) + "/players/detail/" + escape(message.username, true)}"><img src="${"https://minotar.net/avatar/" + escape(message.username, true) + "/48"}"${add_attribute("alt", message.username, 0)} class="rounded animate__animated animate__zoomIn" width="48" height="48"> </a></div> <div class="col hstack gap-2"><div class="card"><div class="card-header small">${validate_component(Date_1, "Date").$$render($$result, { time: message.date }, {}, {})}</div> <div class="card-body">${escape(message.message)}</div> </div></div> </div>`}`;
    })}</div> <hr>  <div class="${[
      "row align-items-end g-2",
      data.ticket.status === TicketStatuses.CLOSED ? "d-none" : ""
    ].join(" ").trim()}"><div class="col"> ${validate_component(Editor_1, "Editor").$$render(
      $$result,
      {
        content: messageText,
        isEmpty: isEditorEmpty
      },
      {
        content: ($$value) => {
          messageText = $$value;
          $$settled = false;
        },
        isEmpty: ($$value) => {
          isEditorEmpty = $$value;
          $$settled = false;
        }
      },
      {}
    )} </div> <div class="col-auto"><button class="${[
      "btn btn-secondary mt-lg-0 mt-3",
      isEditorEmpty ? "disabled" : ""
    ].join(" ").trim()}"${add_attribute(":disabled", isEditorEmpty, 0)}><i class="fas fa-paper-plane"></i> <span class="d-xl-inline d-none ms-2">${escape($_("pages.ticket-detail.send-button"))}</span></button></div></div></div></div> </article>`;
  } while (!$$settled);
  $$unsubscribe__();
  $$unsubscribe_messagesSectionClientHeight();
  return $$rendered;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 41;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-HbN6_S6X.js')).default;
const universal_id = "src/routes/tickets/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/41.D4Tr5krN.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.BeSfBBL_.js","_app/immutable/chunks/entry.kWwTwVNp.js","_app/immutable/chunks/paths.BJzMCz4s.js","_app/immutable/chunks/Editor.BdZffAuZ.js","_app/immutable/chunks/runtime.CNBVLHbk.js","_app/immutable/chunks/tooltip.util.A6wwJI5P.js","_app/immutable/chunks/stores.DYPJM7jX.js","_app/immutable/chunks/TicketStatusBadge.CJCUMXIm.js","_app/immutable/chunks/api.util.DA5pmtwJ.js","_app/immutable/chunks/ConfirmDeleteTicketModal.C6xE5cai.js","_app/immutable/chunks/ToastContainer.BFTE14Nz.js","_app/immutable/chunks/Date.D21mWBk-.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/language.util.aPVI1VQM.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js"];
const stylesheets = ["_app/immutable/assets/41.BaBSOu05.css"];
const fonts = [];

var _41 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { TicketDetail as T, _41 as _ };
//# sourceMappingURL=41-DvgRbDD1.js.map
