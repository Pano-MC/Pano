import{a as t}from"../chunks/C7xj7bG7.js";export{t as start};
