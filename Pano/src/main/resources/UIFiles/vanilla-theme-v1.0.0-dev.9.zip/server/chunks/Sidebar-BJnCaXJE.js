import { af as fallback, ab as stringify, a7 as slot, a6 as bind_props } from './index3-CeMfA1rb.js';
import { a as attr } from './attributes-JZZbhxX3.js';

function Sidebar($$payload, $$props) {
  let side = fallback($$props["side"], "right");
  $$payload.out += `<aside${attr("class", `col-lg-4 ${stringify([
    side === "right" ? "order-lg-last" : "",
    side === "right" ? "order-first" : "",
    side === "left" ? "order-lg-first" : "",
    side === "left" ? "order-last" : ""
  ].filter(Boolean).join(" "))}`)}><!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----></aside>`;
  bind_props($$props, { side });
}

export { Sidebar as S };
//# sourceMappingURL=Sidebar-BJnCaXJE.js.map
