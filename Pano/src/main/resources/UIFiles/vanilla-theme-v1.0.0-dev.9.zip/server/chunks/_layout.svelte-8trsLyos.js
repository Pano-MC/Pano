import { a7 as slot } from './index3-CeMfA1rb.js';
import { T as TicketsLayout } from './TicketsLayout-BadSGyYQ.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './ErrorAlert-DidMNNkl.js';
import './attributes-JZZbhxX3.js';
import './Store-CS8VFGEx.js';
import './index2-DzcLzHBX.js';

function _layout($$payload, $$props) {
  TicketsLayout($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-8trsLyos.js.map
