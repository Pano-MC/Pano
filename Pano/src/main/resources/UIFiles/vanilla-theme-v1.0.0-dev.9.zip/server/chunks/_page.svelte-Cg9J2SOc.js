import { S as Settings } from './16-DxKlHXtg.js';
import './index3-CeMfA1rb.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import './ProfileSidebar-Y8cLa6Di.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './api.util-BEO4Rm0G.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload) {
  Settings($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cg9J2SOc.js.map
