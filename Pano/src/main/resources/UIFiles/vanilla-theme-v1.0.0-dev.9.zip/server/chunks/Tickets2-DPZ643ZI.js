import { p as push, ac as ensure_array_like, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import './client-CjlfgChI.js';
import { T as TicketStatuses, a as TicketStatus } from './TicketStatus-BpCBTGm1.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { N as NoContent } from './NoContent-CRKA6SSq.js';

function TicketRow($$payload, $$props) {
  push();
  var $$store_subs;
  let ticket = $$props["ticket"];
  $$payload.out += `<tr${attr("class", [ticket.selected ? "table-primary" : ""].filter(Boolean).join(" "))}><th scope="row">`;
  if (ticket.status !== TicketStatuses.CLOSED) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<a class="btn btn-link link-danger" role="button" href="javascript:void(0);"><i class="fas fa-times"></i></a>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></th><td class="align-middle text-nowrap"><a${attr("href", `/ticket/${stringify(ticket.id)}`)}${attr("title", store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.show-ticket"))}>#${escape_html(ticket.id)} ${escape_html(ticket.title)}</a></td><td class="align-middle text-nowrap">`;
  TicketStatus($$payload, { status: ticket.status });
  $$payload.out += `<!----></td><td class="align-middle text-nowrap"><a class="badge rounded-pill bg-light text-black"${attr("href", `/tickets/category/${stringify(ticket.category.url)}`)}>${escape_html(ticket.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("components.ticket-row.no-category") : ticket.category.title)}</a></td><td class="align-middle text-nowrap"><span>`;
  Date_1($$payload, { time: ticket.lastUpdate });
  $$payload.out += `<!----></span></td></tr>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { ticket });
  pop();
}
function Tickets($$payload, $$props) {
  push();
  var $$store_subs;
  let tickets = $$props["tickets"];
  if (tickets.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(tickets);
    $$payload.out += `<div class="table-responsive"><table class="table table-hover"><thead><tr><th class="align-middle" scope="col"></th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.title"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.status"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.category"))}</th><th class="align-middle" scope="col">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.tickets.table.last-reply"))}</th></tr></thead><tbody><!--[-->`;
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let ticket = each_array[index];
      TicketRow($$payload, { ticket });
    }
    $$payload.out += `<!--]--></tbody></table></div>`;
  } else {
    $$payload.out += "<!--[!-->";
    NoContent($$payload, {});
  }
  $$payload.out += `<!--]-->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { tickets });
  pop();
}

export { Tickets as T };
//# sourceMappingURL=Tickets2-DPZ643ZI.js.map
