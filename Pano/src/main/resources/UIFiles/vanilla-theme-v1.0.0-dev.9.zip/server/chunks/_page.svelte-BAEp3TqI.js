import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { T as TicketDetail } from './20-fqJohoUa.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './client-CjlfgChI.js';
import './TicketStatus-BpCBTGm1.js';
import './api.util-BEO4Rm0G.js';
import './TicketCreateAndDetailSidebar-B4yKRSB0.js';
import './Sidebar-BJnCaXJE.js';
import './OnlineAdmins-BRQUy31Y.js';
import './index2-DzcLzHBX.js';
import './html-FW6Ia4bL.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  TicketDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BAEp3TqI.js.map
