import { l as load } from './CategoryPosts-CiJDVH28.js';
import './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-pQvViTnv.js';
import './posts2-1yGbq9eM.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './html-FW6Ia4bL.js';
import './api.util-BEO4Rm0G.js';
import './NoContent-CRKA6SSq.js';
import './index2-DzcLzHBX.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DRJT9qJi.js')).default;
const universal_id = "src/routes/blog/category/[url]/+page.js";
const imports = ["_app/immutable/nodes/8.CYrgZKxq.js","_app/immutable/chunks/D2pj9ZJl.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/Bg_s6Urd.js","_app/immutable/chunks/C7xj7bG7.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/D3Udx6Tc.js","_app/immutable/chunks/olrWEycU.js","_app/immutable/chunks/DvCtD7-J.js","_app/immutable/chunks/BKIZ6DVm.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/CkKZvwkP.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/BBmpnScm.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BVg1Ve38.js","_app/immutable/chunks/uwwh77eV.js","_app/immutable/chunks/DLc22tvY.js","_app/immutable/chunks/DauuFb4p.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/CaYKuVCU.js","_app/immutable/chunks/D0rD5wlT.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=8-BDgmrStr.js.map
