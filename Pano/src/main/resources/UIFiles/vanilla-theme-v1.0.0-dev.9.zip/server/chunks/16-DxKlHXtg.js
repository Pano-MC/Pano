import { aa as getContext, a8 as store_get, a9 as unsubscribe_stores, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-Y8cLa6Di.js';

async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: ProfileSidebar };
}
function Settings($$payload, $$props) {
  push();
  var $$store_subs;
  let resetPasswordError;
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.title"))}</h5> <div class="row mb-3"><label class="col-md-4 col-form-label" for="resetPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.title"))}</label> <div class="col col-form-label"><button${attr("class", `btn btn-outline-primary ${stringify([""].filter(Boolean).join(" "))}`)}${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)} aria-describedby="resetPassword validationResetPassword" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.description"))}</button> <div id="validationResetPassword" class="invalid-feedback">${escape_html(resetPasswordError)}</div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></div> <div class="row mb-3"><label class="col-md-4 col-form-label" for="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.title"))}</label> <div class="col col-form-label"><form><div class="row">`;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="col-12">`;
    {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<button type="button" class="btn btn-outline-primary" aria-describedby="userEmail"${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.description"))}</button>`;
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></form></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cg9J2SOc.js')).default;
const universal_id = "src/routes/profile/settings/+page.js";
const imports = ["_app/immutable/nodes/16.cZ3G0Rd5.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/Bg_s6Urd.js","_app/immutable/chunks/C7xj7bG7.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/WX5Qb5S0.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/D9iFoRjI.js","_app/immutable/chunks/BKIZ6DVm.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/olrWEycU.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/dDg1x5k2.js","_app/immutable/chunks/DNZiy6fE.js","_app/immutable/chunks/uwwh77eV.js","_app/immutable/chunks/Bow4Oxfm.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/BBmpnScm.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BVg1Ve38.js","_app/immutable/chunks/pQu5-NQk.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/DCgJEdWQ.js"];
const stylesheets = [];
const fonts = [];

var _16 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Settings as S, _16 as _ };
//# sourceMappingURL=16-DxKlHXtg.js.map
