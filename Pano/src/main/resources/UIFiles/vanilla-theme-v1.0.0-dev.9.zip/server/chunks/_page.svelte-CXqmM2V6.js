import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { N as Notifications } from './12-CKPIv0dh.js';
import './index-server-ClX78Gki.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './language.util-BT90rPTb.js';
import './client-CjlfgChI.js';
import './attributes-JZZbhxX3.js';
import './NoContent-CRKA6SSq.js';
import './api.util-BEO4Rm0G.js';
import './Store-CS8VFGEx.js';
import './index2-DzcLzHBX.js';
import './formatDistanceToNow-B3jPtEFp.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Notifications($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CXqmM2V6.js.map
