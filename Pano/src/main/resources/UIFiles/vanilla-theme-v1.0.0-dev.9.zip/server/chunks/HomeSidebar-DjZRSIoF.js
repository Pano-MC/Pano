import { a8 as store_get, a9 as unsubscribe_stores, t as pop, a1 as writable, p as push, ac as ensure_array_like, ab as stringify } from './index3-CeMfA1rb.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import './client-CjlfgChI.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { b as ApiUtil } from './api.util-BEO4Rm0G.js';
import { a as attr } from './attributes-JZZbhxX3.js';

const data = writable({});
const load = async (event) => {
  data.set(await ApiUtil.get({ path: "/api/sidebar/home", request: event }));
};
function HomeSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let serverOnline;
  serverOnline = store_get($$store_subs ??= {}, "$data", data).mainServer && store_get($$store_subs ??= {}, "$data", data).mainServer.status === "ONLINE";
  Sidebar($$payload, {
    children: ($$payload2) => {
      const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$data", data).lastRegisteredUsers);
      $$payload2.out += `<div class="mb-3"><button class="btn btn-lg btn-secondary w-100" type="button">${escape_html(store_get($$store_subs ??= {}, "$data", data).ipAddress)}</button></div> <div class="mb-3"><div class="card"><div class="card-body"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.server-status"))}</h5> <ul class="list-group list-group-flush"><li class="list-group-item">`;
      if (serverOnline) {
        $$payload2.out += "<!--[-->";
        $$payload2.out += `${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.online"))}`;
      } else {
        $$payload2.out += "<!--[!-->";
        $$payload2.out += `${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.offline"))}`;
      }
      $$payload2.out += `<!--]--></li> <li class="list-group-item">`;
      if (store_get($$store_subs ??= {}, "$data", data).mainServer) {
        $$payload2.out += "<!--[-->";
        $$payload2.out += `${escape_html(store_get($$store_subs ??= {}, "$data", data).mainServer.playerCount)}/${escape_html(store_get($$store_subs ??= {}, "$data", data).mainServer.maxPlayerCount)}`;
      } else {
        $$payload2.out += "<!--[!-->";
        $$payload2.out += `0/0 playing`;
      }
      $$payload2.out += `<!--]--></li> <li class="list-group-item">${escape_html(store_get($$store_subs ??= {}, "$data", data).serverGameVersion)} version</li></ul></div></div></div> <div class="mb-3"><div class="card"><div class="card-body"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.home.last-registrants"))}</h5> <div class="row mt-3"><!--[-->`;
      for (let index = 0, $$length = each_array.length; index < $$length; index++) {
        let player = each_array[index];
        $$payload2.out += `<div class="col-3"><a${attr("href", `/player/${stringify(player)}`)}><img${attr("alt", player)} class="rounded"${attr("src", `https://minotar.net/avatar/${stringify(player)}`)} width="48" height="48" onload="this.__e=event" onerror="this.__e=event"></a></div>`;
      }
      $$payload2.out += `<!--]--></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

export { HomeSidebar as H, load as l };
//# sourceMappingURL=HomeSidebar-DjZRSIoF.js.map
