import { ab as stringify, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import './client-CjlfgChI.js';
import { b as getPostDetail, P as Post } from './posts2-1yGbq9eM.js';
import { e as error } from './index2-DzcLzHBX.js';
import { l as load$1, H as HomeSidebar } from './HomeSidebar-DjZRSIoF.js';
import { a as attr } from './attributes-JZZbhxX3.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0,
      url: ""
    },
    previousPost: "-",
    nextPost: "-"
  };
  await load$1(event);
  await getPostDetail({ url: event.params.url, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "POST_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return { ...data, sidebar: HomeSidebar };
}
function PostDetail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  Post($$payload, { post: data.post, detail: true });
  $$payload.out += `<!----> <div class="row justify-content-between"><div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.previousPost === "-" ? "" : data.previousPost.url)}`)}${attr("class", `btn btn-link ps-0 ${stringify([data.previousPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.previous-post"))}</a></div> <div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.nextPost === "-" ? "" : data.nextPost.url)}`)}${attr("class", `btn btn-link pe-0 ${stringify([data.nextPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.next-post"))}</a></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D0nJlJvB.js')).default;
const universal_id = "src/routes/blog/post/[url]/+page.js";
const imports = ["_app/immutable/nodes/11.D41gvIS1.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/Bg_s6Urd.js","_app/immutable/chunks/C7xj7bG7.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/BKIZ6DVm.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/uwwh77eV.js","_app/immutable/chunks/oQYJN9FL.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/DauuFb4p.js","_app/immutable/chunks/olrWEycU.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/pQu5-NQk.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/D3Udx6Tc.js","_app/immutable/chunks/DvCtD7-J.js","_app/immutable/chunks/CkKZvwkP.js","_app/immutable/chunks/BBmpnScm.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BVg1Ve38.js"];
const stylesheets = [];
const fonts = [];

var _11 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PostDetail as P, _11 as _ };
//# sourceMappingURL=11-CThKRaPz.js.map
