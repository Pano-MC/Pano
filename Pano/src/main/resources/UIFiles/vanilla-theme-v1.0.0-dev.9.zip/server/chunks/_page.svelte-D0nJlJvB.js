import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as PostDetail } from './11-CThKRaPz.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './posts2-1yGbq9eM.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './attributes-JZZbhxX3.js';
import './html-FW6Ia4bL.js';
import './api.util-BEO4Rm0G.js';
import './index2-DzcLzHBX.js';
import './HomeSidebar-DjZRSIoF.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PostDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-D0nJlJvB.js.map
