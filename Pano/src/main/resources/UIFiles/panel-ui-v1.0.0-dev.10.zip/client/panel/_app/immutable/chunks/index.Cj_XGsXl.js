import{H as e,R as o}from"./entry.DBHk3FA4.js";function i(r,t){throw new e(r,t)}function c(r,t){throw new o(r,t.toString())}new TextEncoder;export{i as e,c as r};
