import{a as t}from"../chunks/entry.DBHk3FA4.js";export{t as start};
