import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { D as Dashboard } from './11-qMJY5_Ej.js';
import './api.util-CzxmL1-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './NoContent-N-qOzDdv.js';
import './TicketStatusBadge-zPZI-o9b.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Dashboard, "Dashboard").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-IvT1lt1w.js.map
