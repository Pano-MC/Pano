const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-kTRfs0_B.js')).default;
const imports = ["_app/immutable/nodes/1.LSrI-xSW.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/runtime.1YxGkSe-.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js","_app/immutable/chunks/stores.Bv0yHjcy.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-Ro5Gd98a.js.map
