import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each, i as createEventDispatcher, b as add_classes, d as add_attribute } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { A as ApiUtil } from './api.util-CzxmL1-R.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import { D as Date_1 } from './Date-BK0ZOKAA.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-DRnpye9y.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-C1uMKg14.js';

const PostRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { post } = $$props;
  let { pageType } = $$props;
  let { buttonsLoading } = $$props;
  createEventDispatcher();
  if ($$props.post === void 0 && $$bindings.post && post !== void 0) $$bindings.post(post);
  if ($$props.pageType === void 0 && $$bindings.pageType && pageType !== void 0) $$bindings.pageType(pageType);
  if ($$props.buttonsLoading === void 0 && $$bindings.buttonsLoading && buttonsLoading !== void 0) $$bindings.buttonsLoading(buttonsLoading);
  $$unsubscribe__();
  return `<tr${add_classes((post.selected ? "table-primary" : "").trim())}><th scope="row"><div class="dropdown position-static"><a role="button" href="javascript:void(0);" class="btn btn-sm btn-link" data-bs-toggle="dropdown"${add_attribute("title", $_("components.post-row.actions"), 0)}><span class="fas fa-ellipsis-v"></span></a> <div class="dropdown-menu dropdown-menu-start animate__animated animate__fadeIn"><a class="dropdown-item" target="_blank" href="${escape("", true) + "/preview/post/" + escape(post.id, true)}"><i class="fas fa-eye me-2"></i> ${escape($_("components.post-row.view"))}</a> ${pageType !== PageTypes.DRAFT ? `<a class="${["dropdown-item", buttonsLoading ? "disabled" : ""].join(" ").trim()}" href="javascript:void(0);"><span><i class="fa-solid fa-box-archive me-2"></i> ${escape($_("components.post-row.move-to-draft"))}</span></a>` : ``} ${pageType !== PageTypes.PUBLISHED ? `<a class="${["dropdown-item", buttonsLoading ? "disabled" : ""].join(" ").trim()}" href="javascript:void(0);"><span><i class="fas fa-globe-americas me-2"></i> ${escape($_("components.post-row.publish"))}</span></a>` : ``} <a class="dropdown-item link-danger" href="javascript:void(0);"><i class="fas fa-trash me-2"></i> ${pageType !== PageTypes.TRASH ? `${escape($_("components.post-row.move-to-trash"))}` : `${escape($_("components.post-row.delete"))}`}</a></div></div></th> <td class="align-middle text-nowrap"><a${add_attribute("href", base + "/posts/post/" + post.id, 0)}${add_attribute("title", $_("components.post-row.edit"), 0)}>${escape(post.title)}</a></td> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.post-row.filter"), 0)} href="${escape(base, true) + "/posts/category/" + escape(post.category.url, true)}">${escape(post.category.title === "-" ? $_("components.post-row.no-category") : post.category.title)}</a></td> <td class="align-middle text-nowrap">${escape(post.views)}</td> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/players/player/" + escape(post.writer.username, true)}"><img${add_attribute("alt", post.writer.username, 0)} class="rounded-circle" height="32" src="${"https://minotar.net/avatar/" + escape(post.writer.username, true)}" width="32"></a></td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: post.date }, {}, {})}</td> </tr>`;
});
const PageTypes = Object.freeze({
  PUBLISHED: "PUBLISHED",
  DRAFT: "DRAFT",
  TRASH: "TRASH"
});
const DefaultPageType = PageTypes.PUBLISHED;
async function loadData({ page, pageType, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/posts?page=${page}&pageType=${pageType.toUpperCase()}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        data.pageType = pageType;
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event, pageType = DefaultPageType) {
  const { parent } = event;
  const parentData = await parent();
  pageType = pageType.toUpperCase();
  let data = {
    postCount: 0,
    posts: [],
    totalPage: 1,
    page: 1
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    pageType,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const Posts = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  let buttonsLoading = false;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set($_("pages.posts.title", {
        values: {
          pageType: data.pageType === PageTypes.PUBLISHED ? $_("pages.posts.published") + " " : data.pageType === PageTypes.DRAFT ? $_("pages.posts.draft") + " " : data.pageType === PageTypes.TRASH ? $_("pages.posts.trash") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    middle: () => {
      return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
        default: () => {
          return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/posts", startsWith: true }, {}, {
            default: () => {
              return `${escape($_("pages.post-categories.posts"))}`;
            }
          })} ${validate_component(CardMenuItem, "CardMenuItem").$$render(
            $$result,
            {
              href: "/posts/categories",
              startsWith: true
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.post-categories-button"))}`;
              }
            }
          )} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { disabled: true }, {}, {
            default: () => {
              return `Etiketler`;
            }
          })}`;
        }
      })}`;
    },
    right: () => {
      return `<a href="${escape(base, true) + "/posts/create-post"}" class="btn btn-secondary ms-auto" role="button" slot="right"><i class="fas fa-plus me-2"></i> ${escape($_("pages.posts.create-post-button"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts/published",
              active: data.pageType === PageTypes.PUBLISHED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.published"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts/draft",
              active: data.pageType === PageTypes.DRAFT
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.draft"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/posts/trash",
              active: data.pageType === PageTypes.TRASH
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.posts.trash"))}`;
              }
            }
          )}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.posts.table-title", {
        values: {
          postCount: data.postCount,
          pageType: data.pageType === PageTypes.PUBLISHED ? $_("pages.posts.published") + " " : data.pageType === PageTypes.DRAFT ? $_("pages.posts.draft") + " " : data.pageType === PageTypes.BANNED ? $_("pages.posts.banned") + " " : ""
        }
      }))}</h5>`;
    }
  })}  ${data.postCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th scope="col"></th> <th class="align-middle" scope="col">${escape($_("pages.posts.table.title"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.category"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.views"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.author"))}</th> <th scope="col" class="align-middle">${escape($_("pages.posts.table.last-update"))}</th></tr></thead> <tbody>${each(data.posts, (post, index) => {
    return `${validate_component(PostRow, "PostRow").$$render(
      $$result,
      {
        post,
        pageType: data.pageType,
        buttonsLoading
      },
      {},
      {}
    )}`;
  })}</tbody></table></div>`}  <div class="d-flex justify-content-sm-start justify-content-center">${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div> </div></div> </article>`;
});

export { PostRow as P, PageTypes as a, Posts as b, load as l };
//# sourceMappingURL=Posts-wGZWwfrK.js.map
