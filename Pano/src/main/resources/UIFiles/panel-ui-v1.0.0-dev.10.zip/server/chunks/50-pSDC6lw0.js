const index = 50;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BuatRS7s.js')).default;
const imports = ["_app/immutable/nodes/50.BiL7cEou.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/ServerSettings.DJPe8wUZ.js","_app/immutable/chunks/runtime.1YxGkSe-.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js","_app/immutable/chunks/Store.NX9fI2Q7.js","_app/immutable/chunks/api.util.Dm1JeMNl.js","_app/immutable/chunks/stores.Bv0yHjcy.js","_app/immutable/chunks/Toast.CrsjMNob.js","_app/immutable/chunks/each.BbucQ6WL.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=50-pSDC6lw0.js.map
