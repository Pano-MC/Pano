const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BaLBcg6l.js')).default;
const imports = ["_app/immutable/nodes/15.CeVUC_-f.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-D5WFwBe8.js.map
