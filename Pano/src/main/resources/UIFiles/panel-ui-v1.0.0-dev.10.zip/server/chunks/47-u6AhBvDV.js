import { c as create_ssr_component, f as getContext } from './ssr-ffuobYCI.js';
import './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';

async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = { server: {}, connectedServerCount: 0 };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  return data;
}
const ServerMonitoring = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.server.monitoring.title");
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `Monitoring page`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 47;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-YVN6soik.js')).default;
const universal_id = "src/routes/server/monitoring/+page.js";
const imports = ["_app/immutable/nodes/47.8jQpAWIx.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/runtime.1YxGkSe-.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js"];
const stylesheets = [];
const fonts = [];

var _47 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ServerMonitoring as S, _47 as _ };
//# sourceMappingURL=47-u6AhBvDV.js.map
