import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { M as MainLayout } from './0-CZ9n8V9Z.js';
import './api.util-CzxmL1-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import 'fs';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './language.util-DgXijOeV.js';
import './stores-BDx4Az-R.js';
import './NoContent-N-qOzDdv.js';
import './auth.util-BRaxc5Jt.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './formatDistanceToNow-wbEYwSfo.js';
import './differenceInSeconds-C8IiJITI.js';

const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(MainLayout, "MainLayout").$$render($$result, { data }, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout as default };
//# sourceMappingURL=_layout.svelte-B6uaEkXN.js.map
