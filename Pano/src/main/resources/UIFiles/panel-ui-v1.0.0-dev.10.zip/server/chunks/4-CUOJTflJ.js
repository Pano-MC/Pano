import { c as create_ssr_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_PERMISSION_GROUPS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const PermGroupsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-x_ml262I.js')).default;
const universal_id = "src/routes/players/perm-groups/+layout.js";
const imports = ["_app/immutable/nodes/4.CY1CIrU0.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/auth.util.CQWb1cEw.js","_app/immutable/chunks/stores.Bv0yHjcy.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js","_app/immutable/chunks/index.Cj_XGsXl.js"];
const stylesheets = [];
const fonts = [];

var _4 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { PermGroupsLayout as P, _4 as _ };
//# sourceMappingURL=4-CUOJTflJ.js.map
