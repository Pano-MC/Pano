import { c as create_ssr_component, a as subscribe, i as createEventDispatcher, b as add_classes, d as add_attribute, e as escape, v as validate_component } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { D as Date_1 } from './Date-BK0ZOKAA.js';
import { T as TicketStatusBadge } from './TicketStatusBadge-zPZI-o9b.js';

const TicketRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $checkedList, $$unsubscribe_checkedList;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { ticket } = $$props;
  let { checkedList } = $$props;
  $$unsubscribe_checkedList = subscribe(checkedList, (value) => $checkedList = value);
  createEventDispatcher();
  if ($$props.ticket === void 0 && $$bindings.ticket && ticket !== void 0) $$bindings.ticket(ticket);
  if ($$props.checkedList === void 0 && $$bindings.checkedList && checkedList !== void 0) $$bindings.checkedList(checkedList);
  $$unsubscribe__();
  $$unsubscribe_checkedList();
  return `<tr${add_classes((ticket.selected ? "table-primary" : "").trim())}><th scope="row" class="align-middle"><div class="form-check"><input${add_attribute("title", $_("components.ticket-row.select"), 0)} class="form-check-input" id="${"postCheck" + escape(ticket.id, true)}" type="checkbox"${add_attribute("checked", $checkedList[ticket.id], 1)}></div></th> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/tickets/ticket/" + escape(ticket.id, true)}"${add_attribute("title", $_("components.ticket-row.view"), 0)}>#${escape(ticket.id)} ${escape(ticket.title)}</a></td> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.ticket-row.filter"), 0)} href="${escape(base, true) + "/tickets/category/" + escape(ticket.category.url, true)}">${escape(ticket.category.title === "-" ? $_("components.ticket-row.no-category") : ticket.category.title)}</a></td> <td class="align-middle text-nowrap"><a href="${escape(base, true) + "/players/player/" + escape(ticket.writer.username, true)}"${add_attribute("title", $_("components.ticket-row.view"), 0)}><img src="${"https://minotar.net/avatar/" + escape(ticket.writer.username, true) + "/32"}"${add_attribute("alt", $_("components.ticket-row.player-name"), 0)} class="rounded-circle animate__animated animate__zoomIn me-2" height="32" width="32"> ${escape(ticket.writer.username)}</a></td> <td class="align-middle text-nowrap">${validate_component(TicketStatusBadge, "TicketStatusBadge").$$render($$result, { status: ticket.status }, {}, {})}</td> <td class="align-middle text-nowrap">${validate_component(Date_1, "Date").$$render($$result, { time: ticket.lastUpdate }, {}, {})}</td> </tr>`;
});

export { TicketRow as T };
//# sourceMappingURL=TicketRow-CvSni0kK.js.map
