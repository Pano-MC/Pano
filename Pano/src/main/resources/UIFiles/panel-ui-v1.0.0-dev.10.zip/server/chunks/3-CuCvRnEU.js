import { c as create_ssr_component, v as validate_component, a as subscribe, f as getContext, d as add_attribute, e as escape, h as each } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import './ToastContainer-CKzXwJro.js';

const dialogID$4 = "editPlayerModal";
const player$4 = writable({});
const defaultErrors = {
  "username": "",
  "email": "",
  "newPassword": "",
  "newPasswordRepeat": ""
};
const errors = writable(defaultErrors);
const EditPlayerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $errors, $$unsubscribe_errors;
  let $player, $$unsubscribe_player;
  let $user, $$unsubscribe_user;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_errors = subscribe(errors, (value) => $errors = value);
  $$unsubscribe_player = subscribe(player$4, (value) => $player = value);
  const user = getContext("user");
  $$unsubscribe_user = subscribe(user, (value) => $user = value);
  $$unsubscribe__();
  $$unsubscribe_errors();
  $$unsubscribe_player();
  $$unsubscribe_user();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$4, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" data-svelte-h="svelte-1u0hndq">Edit Player Information</h5> <button title="Close" type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><div class="row"><div class="col-12"><input class="${["form-control form-control-lg", !!$errors.username ? "is-invalid" : ""].join(" ").trim()}" id="username"${add_attribute("placeholder", $_("components.modals.edit-player.inputs.username.placeholder"), 0)} type="text" aria-describedby="validationEditUsernameInModal"${add_attribute("value", $player.username, 0)}> <div id="validationEditUsernameInModal" class="invalid-feedback">${!!$errors["username"] ? `${$errors["username"] === "INVALID" ? `${escape($_("components.modals.edit-player.inputs.username.errors.invalid"))}` : ``} ${$errors["username"] === "EXISTS" ? `${escape($_("components.modals.edit-player.inputs.username.errors.exists"))}` : ``}` : ``}</div></div> <div class="col-12 mb-3"></div> <div class="col-12 mb-3"><label for="email">${escape($_("components.modals.edit-player.inputs.email.title"))}</label> <input class="${["form-control", !!$errors.email ? "is-invalid" : ""].join(" ").trim()}" id="email" type="text" aria-describedby="validationEditEmailInModal"${add_attribute("value", $player.email, 0)}> <div id="validationEditEmailInModal" class="invalid-feedback">${!!$errors["email"] ? `${$errors["email"] === "INVALID" ? `${escape($_("components.modals.edit-player.inputs.email.errors.invalid"))}` : ``} ${$errors["email"] === "EXISTS" ? `${escape($_("components.modals.edit-player.inputs.email.errors.exists"))}` : ``}` : ``}</div></div> <div class="col-6 mb-3"><label for="newPassword">${escape($_("components.modals.edit-player.inputs.new-password.title"))}</label> <input class="${["form-control", !!$errors.newPassword ? "is-invalid" : ""].join(" ").trim()}" id="newPassword" type="password" aria-describedby="validationEditPasswordInModal"${add_attribute("value", $player.newPassword, 0)}> <div id="validationEditPasswordInModal" class="invalid-feedback">${!!$errors["newPassword"] ? `${$errors["newPassword"] === "INVALID" ? `${escape($_("components.modals.edit-player.inputs.new-password.errors.invalid"))}` : ``}` : ``}</div></div> <div class="col-6 mb-3"><label for="newPasswordRepeat">${escape($_("components.modals.edit-player.inputs.new-password-repeat.title"))}</label> <input class="${["form-control", !!$errors.newPasswordRepeat ? "is-invalid" : ""].join(" ").trim()}" id="newPasswordRepeat" type="password" aria-describedby="validationEditNewPasswordInModal"${add_attribute("value", $player.newPasswordRepeat, 0)}> <div id="validationEditNewPasswordInModal" class="invalid-feedback">${!!$errors["newPasswordRepeat"] ? `${$errors["newPasswordRepeat"] === "NOT_MATCH" ? `${escape($_("components.modals.edit-player.inputs.new-password-repeat.errors.not-match"))}` : ``}` : ``}</div></div> <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" aria-checked="true" role="switch" id="canCreateTicketCheckbox" ${$user.username === $player.username ? "disabled" : ""}${add_attribute("checked", $player.canCreateTicket, 1)}> <label class="form-check-label" for="canCreateTicketCheckbox">${escape($_("components.modals.edit-player.inputs.can-open-ticket"))}</label></div></div> <div class="col-6"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" aria-checked="true" id="emailVerifiedCheckbox" ${$user.username === $player.username ? "disabled" : ""}${add_attribute("checked", $player.isEmailVerified, 1)}> <label class="form-check-label" for="emailVerifiedCheckbox">${escape($_("components.modals.edit-player.inputs.email-verified"))}</label></div></div></div></div> <div class="modal-footer"><button class="${["btn btn-primary w-100", ""].join(" ").trim()}" type="submit">${escape($_("components.modals.edit-player.save"))}</button></div></form></div></div> </div>`;
});
const dialogID$3 = "authorizePlayerModal";
const player$3 = writable({});
const loading$1 = writable(true);
const permissionGroups = writable([]);
const submitLoading = writable(false);
const AuthorizePlayerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $loading, $$unsubscribe_loading;
  let $_, $$unsubscribe__;
  let $$unsubscribe_player;
  let $permissionGroups, $$unsubscribe_permissionGroups;
  let $submitLoading, $$unsubscribe_submitLoading;
  $$unsubscribe_loading = subscribe(loading$1, (value) => $loading = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_player = subscribe(player$3, (value) => value);
  $$unsubscribe_permissionGroups = subscribe(permissionGroups, (value) => $permissionGroups = value);
  $$unsubscribe_submitLoading = subscribe(submitLoading, (value) => $submitLoading = value);
  $$unsubscribe_loading();
  $$unsubscribe__();
  $$unsubscribe_player();
  $$unsubscribe_permissionGroups();
  $$unsubscribe_submitLoading();
  return ` <div class="modal fade"${add_attribute("id", dialogID$3, 0)} tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">${$loading ? `<div class="modal-body" data-svelte-h="svelte-79dvbl"><div class="text-center"><div class="spinner-border text-primary" role="status"></div></div></div>` : `<div class="modal-header"><h5 class="modal-title" id="exampleModalLabel">${escape($_("components.modals.authorize-player.title"))}</h5> <button type="button" class="btn-close" data-bs-dismiss="modal"${add_attribute("aria-label", $_("components.modals.authorize-player.close"), 0)}></button></div> <div class="modal-body"><select class="form-control" id="selectPermGroup"><option class="text-primary" value="-">${escape($_("components.modals.authorize-player.player"))}</option>${each($permissionGroups, (permissionGroup, index) => {
    return `<option${add_attribute("value", permissionGroup.name, 0)}>${escape(permissionGroup.name)}</option>`;
  })}</select></div> <div class="modal-footer"><button type="button" class="${["btn btn-primary w-100", $submitLoading ? "disabled" : ""].join(" ").trim()}">${escape($_("components.modals.authorize-player.save"))}</button></div>`}</div></div> </div>`;
});
const dialogID$2 = "banPlayerModal";
const player$2 = writable({});
const sendNotification = writable(true);
const ConfirmBanPlayerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_player;
  let $sendNotification, $$unsubscribe_sendNotification;
  let $_, $$unsubscribe__;
  $$unsubscribe_player = subscribe(player$2, (value) => value);
  $$unsubscribe_sendNotification = subscribe(sendNotification, (value) => $sendNotification = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_player();
  $$unsubscribe_sendNotification();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$2, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-ban-player.title"))} <div class="form-check d-inline-block text-center mt-3"><input class="form-check-input" type="checkbox" value="" id="notifyBanEmail"${add_attribute("checked", $sendNotification, 1)}> <label class="form-check-label" for="notifyBanEmail">${escape($_("components.modals.confirm-ban-player.notify-with-email"))}</label></div></div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-ban-player.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-ban-player.yes"))}</button></div></div></div> </div>`;
});
const dialogID$1 = "unbanPlayerModal";
const player$1 = writable({});
const UnbanPlayerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_player;
  let $_, $$unsubscribe__;
  $$unsubscribe_player = subscribe(player$1, (value) => value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_player();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$1, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.unban-player.title"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.unban-player.camcel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.unban-player.yes"))}</button></div></div></div> </div>`;
});
const dialogID = "deletePlayerModal";
const player = writable({});
const loading = writable(false);
const passwordError = writable(false);
const currentPassword = writable("");
const ConfirmDeletePlayerModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let yesButtonDisabled;
  let $loading, $$unsubscribe_loading;
  let $passwordError, $$unsubscribe_passwordError;
  let $$unsubscribe_player;
  let $currentPassword, $$unsubscribe_currentPassword;
  let $_, $$unsubscribe__;
  $$unsubscribe_loading = subscribe(loading, (value) => $loading = value);
  $$unsubscribe_passwordError = subscribe(passwordError, (value) => $passwordError = value);
  $$unsubscribe_player = subscribe(player, (value) => value);
  $$unsubscribe_currentPassword = subscribe(currentPassword, (value) => $currentPassword = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  yesButtonDisabled = $loading || !$currentPassword;
  $$unsubscribe_loading();
  $$unsubscribe_passwordError();
  $$unsubscribe_player();
  $$unsubscribe_currentPassword();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><form><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-16uwuuf"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-delete-player.title"))} <input class="${[
    "form-control d-inline-block text-center mt-3",
    $passwordError ? "border-danger" : ""
  ].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.confirm-delete-player.inputs.password.placeholder"), 0)} type="password"${add_attribute("value", $currentPassword, 0)}></div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", $loading ? "disabled" : ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-player.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", yesButtonDisabled ? "disabled" : ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-player.yes"))}</button></div></form></div></div> </div>`;
});
async function load({ parent, url: { pathname } }) {
  const parentData = await parent();
  const { user } = parentData;
  if (pathname.startsWith("/players/player/")) {
    return parentData;
  }
  if (!hasPermission(Permissions.MANAGE_PLAYERS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const PlayersLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``} ${validate_component(EditPlayerModal, "EditPlayerModal").$$render($$result, {}, {}, {})} ${validate_component(AuthorizePlayerModal, "AuthorizePlayerModal").$$render($$result, {}, {}, {})} ${validate_component(ConfirmBanPlayerModal, "ConfirmBanPlayerModal").$$render($$result, {}, {}, {})} ${validate_component(ConfirmDeletePlayerModal, "ConfirmDeletePlayerModal").$$render($$result, {}, {}, {})} ${validate_component(UnbanPlayerModal, "UnbanPlayerModal").$$render($$result, {}, {}, {})}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-BlL6AoIy.js')).default;
const universal_id = "src/routes/players/+layout.js";
const imports = ["_app/immutable/nodes/3.Cm1jG1k4.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/auth.util.CQWb1cEw.js","_app/immutable/chunks/stores.Bv0yHjcy.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js","_app/immutable/chunks/index.Cj_XGsXl.js","_app/immutable/chunks/AuthorizePlayerModal.b2GMNhDP.js","_app/immutable/chunks/runtime.1YxGkSe-.js","_app/immutable/chunks/Store.NX9fI2Q7.js","_app/immutable/chunks/api.util.Dm1JeMNl.js","_app/immutable/chunks/Toast.CrsjMNob.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/UnbanPlayerModal.DDb5l52F.js","_app/immutable/chunks/ConfirmDeletePlayerModal.BBPbCoja.js"];
const stylesheets = [];
const fonts = [];

var _3 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { PlayersLayout as P, _3 as _ };
//# sourceMappingURL=3-CuCvRnEU.js.map
