import { l as load$1, P as PageTypes } from './Addons-C9IQS6rp.js';
import './ssr-ffuobYCI.js';
import './api.util-CzxmL1-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './index2-Dyghn50Q.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';
import './CardFilters-C1uMKg14.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './NoContent-N-qOzDdv.js';

async function load(params) {
  return load$1(params, PageTypes.ACTIVE);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CtOhYkpb.js')).default;
const universal_id = "src/routes/addons/active/+page.js";
const imports = ["_app/immutable/nodes/13.CM4vDhvW.js","_app/immutable/chunks/Addons.K2uogkBC.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/api.util.Dm1JeMNl.js","_app/immutable/chunks/stores.Bv0yHjcy.js","_app/immutable/chunks/entry.DBHk3FA4.js","_app/immutable/chunks/paths.Cyt5adKP.js","_app/immutable/chunks/tooltip.util.CxKaFCDk.js","_app/immutable/chunks/Store.NX9fI2Q7.js","_app/immutable/chunks/Toast.CrsjMNob.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.DFlsL7UD.js","_app/immutable/chunks/runtime.1YxGkSe-.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.CdjpjxhP.js","_app/immutable/chunks/NoContent.B8YRs9Nq.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=13-B6fI_j56.js.map
