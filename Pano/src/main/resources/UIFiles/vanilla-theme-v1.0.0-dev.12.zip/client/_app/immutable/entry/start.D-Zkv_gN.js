import{a as t}from"../chunks/Da96ZOq9.js";export{t as start};
