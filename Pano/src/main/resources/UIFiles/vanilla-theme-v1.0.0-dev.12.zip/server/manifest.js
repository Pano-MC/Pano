const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/green.svg","assets/img/minecraft-logo.png","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".txt":"text/plain"},
	_: {
		client: {"start":"_app/immutable/entry/start.D-Zkv_gN.js","app":"_app/immutable/entry/app.Q3-5yd8C.js","imports":["_app/immutable/entry/start.D-Zkv_gN.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/entry/app.Q3-5yd8C.js","_app/immutable/chunks/B3FIjOHi.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/QBbPbGZz.js","_app/immutable/chunks/YmbrKmY7.js","_app/immutable/chunks/R9t45OW8.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./chunks/0-D0_VxcRN.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-DKRTy8Nm.js')),
			__memo(() => import('./chunks/2-DeV3npeV.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/3-DqVn66Zg.js')),
			__memo(() => import('./chunks/4-DWJKxZc8.js')),
			__memo(() => import('./chunks/5-Dyf9z23F.js')),
			__memo(() => import('./chunks/6-Dk_ubcb_.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-CUjutoqY.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/8-dyZSMGA3.js')),
			__memo(() => import('./chunks/9-xvQ1gKGp.js')),
			__memo(() => import('./chunks/10-q0RKIHbB.js')),
			__memo(() => import('./chunks/11-CIFb0S41.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/12-BEoIVfJ1.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/13-DJdzPtR9.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/14-ClmyfNf0.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-ctmgdHAW.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/16-Bb65Jo9c.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/17-wON2Vz3P.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-uf6FJHNH.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/19-DhOM24TR.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/20-DaVCmGnY.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/21-ClUI3rN1.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/22-C-GDkS_G.js')),
			__memo(() => import('./chunks/23-BaljZz0u.js')),
			__memo(() => import('./chunks/24-ByzeuKHK.js')),
			__memo(() => import('./chunks/25-BMbijO8W.js')),
			__memo(() => import('./chunks/26-cA92rNoA.js')),
			__memo(() => import('./chunks/27-Dm3SU6HO.js')),
			__memo(() => import('./chunks/28-xA9ScoXN.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/activate-new-email",
				pattern: /^\/activate-new-email\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/activate",
				pattern: /^\/activate\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]",
				pattern: /^\/blog\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]/[page]",
				pattern: /^\/blog\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/blog/page/[page]",
				pattern: /^\/blog\/page\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/blog/post/[url]",
				pattern: /^\/blog\/post\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/player/[player]",
				pattern: /^\/player\/([^/]+?)\/?$/,
				params: [{"name":"player","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Duh1hDwD.js'))
			},
			{
				id: "/preview/post/[id]",
				pattern: /^\/preview\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/profile/settings",
				pattern: /^\/profile\/settings\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/renew-password",
				pattern: /^\/renew-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/reset-password",
				pattern: /^\/reset-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/support",
				pattern: /^\/support\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/theme-api/languages",
				pattern: /^\/theme-api\/languages\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-J3hjOU-B.js'))
			},
			{
				id: "/theme-api/languages/[language].json",
				pattern: /^\/theme-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-h-GTtCCu.js'))
			},
			{
				id: "/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/tickets/all",
				pattern: /^\/tickets\/all\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/tickets/all/[page]",
				pattern: /^\/tickets\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]",
				pattern: /^\/tickets\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]/[page]",
				pattern: /^\/tickets\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/tickets/closed",
				pattern: /^\/tickets\/closed\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/tickets/closed/[page]",
				pattern: /^\/tickets\/closed\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/ticket/create",
				pattern: /^\/ticket\/create\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/ticket/[id]",
				pattern: /^\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 20 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
