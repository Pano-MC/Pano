import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-C_6jIVDG.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-DSMMHM8Y.js';
import { a as getProfile } from './profile2-C_g7BwjG.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BrmLTJAv.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.T6PkS0bK.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/C9MgkVyf.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/YmbrKmY7.js","_app/immutable/chunks/DQZmTahU.js","_app/immutable/chunks/CSMfOcCl.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/JK_Xl-qa.js","_app/immutable/chunks/BIGVZOOL.js","_app/immutable/chunks/fuHGBAMs.js","_app/immutable/chunks/32hVgHvJ.js","_app/immutable/chunks/Cky89bvi.js","_app/immutable/chunks/Dr7JzEfL.js","_app/immutable/chunks/CEjg1i76.js","_app/immutable/chunks/QBbPbGZz.js","_app/immutable/chunks/CWYy74Sf.js","_app/immutable/chunks/BX__R84Z.js","_app/immutable/chunks/LBNOOL22.js","_app/immutable/chunks/DNuTiruo.js","_app/immutable/chunks/CqZ3J_1M.js","_app/immutable/chunks/Bq950o7f.js","_app/immutable/chunks/NlkVlA3i.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-ctmgdHAW.js.map
