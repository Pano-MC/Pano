const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DVSVVHqG.js')).default;
const imports = ["_app/immutable/nodes/1.Cr4_LNAN.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/C9MgkVyf.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/fuHGBAMs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DKRTy8Nm.js.map
