import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { C as CategoryPosts } from './CategoryPosts-BFOHtOkB.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-DcYh2ZVZ.js';
import './posts2-CG2EHrs6.js';
import './Date-C_6jIVDG.js';
import './language.util-BXmV5FUa.js';
import './html-FW6Ia4bL.js';
import './api.util-Tc1TMIE8.js';
import './NoContent-CRKA6SSq.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  CategoryPosts($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DChZM1Ea.js.map
