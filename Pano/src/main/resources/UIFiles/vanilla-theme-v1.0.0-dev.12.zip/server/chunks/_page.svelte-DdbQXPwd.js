import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as PlayerProfile } from './13-DJdzPtR9.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-C_6jIVDG.js';
import './language.util-BXmV5FUa.js';
import './client-CjlfgChI.js';
import './index2-DzcLzHBX.js';
import './index-server-ClX78Gki.js';
import './Sidebar-BJnCaXJE.js';
import './attributes-JZZbhxX3.js';
import './PlayerHead-76jvL1tB.js';
import './api.util-Tc1TMIE8.js';
import './profile2-C_g7BwjG.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PlayerProfile($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DdbQXPwd.js.map
