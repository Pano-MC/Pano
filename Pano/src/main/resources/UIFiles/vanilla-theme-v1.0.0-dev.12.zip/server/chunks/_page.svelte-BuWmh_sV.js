import { R as ResetPassword } from './18-uf6FJHNH.js';
import './index3-CeMfA1rb.js';
import './ErrorAlert-DidMNNkl.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './SuccessAlert-xdL2cry4.js';
import './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import './Store-CS8VFGEx.js';
import './index2-DzcLzHBX.js';

function _page($$payload) {
  ResetPassword($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BuWmh_sV.js.map
