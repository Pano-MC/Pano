import { a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { P as PreviewPost } from './14-ClmyfNf0.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './posts2-CG2EHrs6.js';
import './client-CjlfgChI.js';
import './Date-C_6jIVDG.js';
import './language.util-BXmV5FUa.js';
import './attributes-JZZbhxX3.js';
import './html-FW6Ia4bL.js';
import './api.util-Tc1TMIE8.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  PreviewPost($$payload, { post: data.post });
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CII8CsWC.js.map
