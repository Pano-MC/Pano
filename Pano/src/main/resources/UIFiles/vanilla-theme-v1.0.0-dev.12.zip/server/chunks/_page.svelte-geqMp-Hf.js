import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as PostDetail } from './11-CIFb0S41.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './posts2-CG2EHrs6.js';
import './Date-C_6jIVDG.js';
import './language.util-BXmV5FUa.js';
import './attributes-JZZbhxX3.js';
import './html-FW6Ia4bL.js';
import './api.util-Tc1TMIE8.js';
import './index2-DzcLzHBX.js';
import './HomeSidebar-Dt9bHHvb.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PostDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-geqMp-Hf.js.map
