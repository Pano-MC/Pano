import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { c as getPostPreview, P as Post } from './posts2-CG2EHrs6.js';

async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  const { session } = parentData;
  const { user } = session;
  if (!user && !user.panelAccess) {
    return { status: 302, redirect: "/" };
  }
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0
    },
    previousPost: "-",
    nextPost: "-"
  };
  await getPostPreview({ id: event.params.id, request: event }).then((body) => {
    if (body.error) {
      data = {};
      return;
    }
    data.post = body;
  });
  return data;
}
function PreviewPost($$payload, $$props) {
  push();
  var $$store_subs;
  let post = $$props["post"];
  $$payload.out += `<h5 class="card-title mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.preview-post.title", { values: { postTitle: post.title } }))}</h5> `;
  Post($$payload, { post, detail: true });
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { post });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 14;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CII8CsWC.js')).default;
const universal_id = "src/routes/preview/post/[id]/+page.js";
const imports = ["_app/immutable/nodes/14.2wN5KRyn.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/C9MgkVyf.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/YmbrKmY7.js","_app/immutable/chunks/Cx4ycgir.js","_app/immutable/chunks/BIGVZOOL.js","_app/immutable/chunks/QBbPbGZz.js","_app/immutable/chunks/DDQQR8R6.js","_app/immutable/chunks/CSMfOcCl.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/CWYy74Sf.js","_app/immutable/chunks/fuHGBAMs.js","_app/immutable/chunks/NlkVlA3i.js","_app/immutable/chunks/CqZ3J_1M.js","_app/immutable/chunks/BX__R84Z.js","_app/immutable/chunks/LBNOOL22.js"];
const stylesheets = [];
const fonts = [];

var _14 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PreviewPost as P, _14 as _ };
//# sourceMappingURL=14-ClmyfNf0.js.map
