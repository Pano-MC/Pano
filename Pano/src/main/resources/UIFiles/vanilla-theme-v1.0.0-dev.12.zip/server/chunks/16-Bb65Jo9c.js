import { aa as getContext, a8 as store_get, a9 as unsubscribe_stores, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-DSMMHM8Y.js';

async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: ProfileSidebar };
}
function Settings($$payload, $$props) {
  push();
  var $$store_subs;
  let resetPasswordError;
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.title"))}</h5> <div class="row mb-3"><label class="col-md-4 col-form-label" for="resetPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.title"))}</label> <div class="col col-form-label"><button${attr("class", `btn btn-outline-primary ${stringify([""].filter(Boolean).join(" "))}`)}${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)} aria-describedby="resetPassword validationResetPassword" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.description"))}</button> <div id="validationResetPassword" class="invalid-feedback">${escape_html(resetPasswordError)}</div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></div> <div class="row mb-3"><label class="col-md-4 col-form-label" for="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.title"))}</label> <div class="col col-form-label"><form><div class="row">`;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="col-12">`;
    {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<button type="button" class="btn btn-outline-primary" aria-describedby="userEmail"${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.description"))}</button>`;
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></form></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Ck2gLKEW.js')).default;
const universal_id = "src/routes/profile/settings/+page.js";
const imports = ["_app/immutable/nodes/16.DwK7rLgm.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/C9MgkVyf.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/QBbPbGZz.js","_app/immutable/chunks/CWYy74Sf.js","_app/immutable/chunks/JK_Xl-qa.js","_app/immutable/chunks/DcV3UcoS.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/DQZmTahU.js","_app/immutable/chunks/CSMfOcCl.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BIGVZOOL.js","_app/immutable/chunks/fuHGBAMs.js","_app/immutable/chunks/32hVgHvJ.js","_app/immutable/chunks/Cky89bvi.js","_app/immutable/chunks/Dr7JzEfL.js","_app/immutable/chunks/CEjg1i76.js","_app/immutable/chunks/YmbrKmY7.js","_app/immutable/chunks/BX__R84Z.js","_app/immutable/chunks/LBNOOL22.js","_app/immutable/chunks/DNuTiruo.js","_app/immutable/chunks/CqZ3J_1M.js","_app/immutable/chunks/Bq950o7f.js"];
const stylesheets = [];
const fonts = [];

var _16 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Settings as S, _16 as _ };
//# sourceMappingURL=16-Bb65Jo9c.js.map
