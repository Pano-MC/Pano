import { ac as ensure_array_like, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import { b as getTicketCategories } from './TicketStatus-D7dIz8nE.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar-C2Wn5Tbl.js';
import { e as error } from './index2-DzcLzHBX.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { categories: [], categoryPage: 0 };
  await load$1(event);
  await getTicketCategories({ page: data.categoryPage, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return {
    ...data,
    sidebar: TicketCreateAndDetailSidebar
  };
}
function TicketCreate($$payload, $$props) {
  push();
  var $$store_subs;
  let isButtonDisabled;
  let data = $$props["data"];
  let error2;
  let title = "";
  let message = "";
  isButtonDisabled = title === "";
  const each_array = ensure_array_like(data.categories);
  $$payload.out += `<div class="card"><div class="card-body"><div class="row justify-content-between mb-3"><div class="col-auto"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.title"))}</h4></div></div> `;
  ErrorAlert($$payload, { error: error2 });
  $$payload.out += `<!----> <div class="mb-3"><input type="text" class="form-control form-control-lg mb-3"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.title"))}${attr("value", title)}> <select class="form-select" id="datalistOptions"><option${attr("value", -1)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.no-category"))}</option><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let category = each_array[index];
    $$payload.out += `<option${attr("value", category.id)}>${escape_html(category.title)}</option>`;
  }
  $$payload.out += `<!--]--></select></div> <div class="mb-3"><textarea class="form-control" rows="6">`;
  const $$body = escape_html(message);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea></div> <button${attr("class", `btn btn-primary w-100 ${stringify([isButtonDisabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", isButtonDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.create-button"))}</button></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 21;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DgUnhGCG.js')).default;
const universal_id = "src/routes/ticket/create/+page.js";
const imports = ["_app/immutable/nodes/21.Dt06cwWk.js","_app/immutable/chunks/Bihh3cao.js","_app/immutable/chunks/CXSy5v3k.js","_app/immutable/chunks/C9MgkVyf.js","_app/immutable/chunks/Da96ZOq9.js","_app/immutable/chunks/DQduJsNl.js","_app/immutable/chunks/BxrIe_lb.js","_app/immutable/chunks/CWYy74Sf.js","_app/immutable/chunks/JK_Xl-qa.js","_app/immutable/chunks/DcV3UcoS.js","_app/immutable/chunks/YmbrKmY7.js","_app/immutable/chunks/CCHvVFfu.js","_app/immutable/chunks/QBbPbGZz.js","_app/immutable/chunks/BIGVZOOL.js","_app/immutable/chunks/fuHGBAMs.js","_app/immutable/chunks/DNuTiruo.js","_app/immutable/chunks/CqZ3J_1M.js","_app/immutable/chunks/BsYDTlYL.js","_app/immutable/chunks/CSMfOcCl.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/C1H8-Czc.js","_app/immutable/chunks/DPngeZIi.js","_app/immutable/chunks/CelOSzzX.js","_app/immutable/chunks/Dr7JzEfL.js"];
const stylesheets = [];
const fonts = [];

var _21 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { TicketCreate as T, _21 as _ };
//# sourceMappingURL=21-ClUI3rN1.js.map
