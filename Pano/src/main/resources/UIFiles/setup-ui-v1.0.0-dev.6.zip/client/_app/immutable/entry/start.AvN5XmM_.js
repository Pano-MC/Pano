import{a as t}from"../chunks/CuDMowqM.js";export{t as start};
