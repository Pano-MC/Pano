import { ac as fallback, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index2-BSgs6Xxn.js';
import { $ as $format } from './runtime-us51QdR2.js';
import { e as escape_html } from './client-DcSItIJ-.js';
import { a as attr } from './attributes-BEm38Kz9.js';
import './ToastContainer-DLmocSoA.js';
import { E as ErrorAlert } from './ErrorAlert-CWi-wjrX.js';

function ConfirmRemovePanoAccountModal($$payload, $$props) {
  push();
  var $$store_subs;
  $$payload.out += `<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-pano-account.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr("class", `btn btn-link col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr("class", `btn btn-danger col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function load({ parent, url: { searchParams } }) {
  const { stepInfo: { account, panoAccount } } = await parent();
  const failed = searchParams.get("failed");
  const encodedData = searchParams.get("encodedData");
  const state = searchParams.get("state");
  return {
    stepInfo: {
      account,
      panoAccount,
      failed,
      encodedData,
      state
    }
  };
}
function Step4($$payload, $$props) {
  push();
  var $$store_subs;
  let disabled;
  let account = fallback($$props["account"], () => ({ username: "", password: "", email: "" }), true);
  let panoAccount = $$props["panoAccount"];
  let failed = $$props["failed"];
  let encodedData = $$props["encodedData"];
  let state = $$props["state"];
  let loading = false;
  let error = null;
  let connecting = !panoAccount && state && encodedData;
  let disconnecting;
  disabled = account.username === "" || account.password === "" || account.email === "";
  $$payload.out += `<div class="animate__animated animate__fadeIn"><div class="animate__animated animate__slideInUp"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.title"))}</h4> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.description"))}</p></div> <form>`;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  if (!panoAccount && failed) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="alert alert-danger alert-dismissible fade show mb-0" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert"${attr("aria-label", store_get($$store_subs ??= {}, "$_", $format)("buttons.close"))}></button> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("connect-failed-alert"))}</div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div class="mb-3"><label for="admin-email">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.email"))}</label> <input class="form-control" id="admin-email" type="email"${attr("value", account.email)}></div> <div class="row"><div class="col-6"><div class="mb-3"><label for="admin-username">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.username"))}</label> <input class="form-control" id="admin-username" type="text"${attr("value", account.username)}></div></div> <div class="col-6"><div class="mb-3"><label for="admin-password">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.password"))}</label> <input class="form-control" id="admin-password" placeholder="************"${attr("value", account.password)}> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.inputs.password-help-text"))}</small></div></div></div> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.online-account"))}</h5> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.online-account-description"))}</p> `;
  if (panoAccount) {
    $$payload.out += "<!--[-->";
    $$payload.out += `${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.account.online-account-connected"))} <br> <span class="text-muted">${escape_html(panoAccount.email)}</span> <button type="button" class="btn btn-sm btn-outline-danger ms-2"${attr("disabled", disconnecting, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.remove"))}</button>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<button type="button" class="btn btn-sm btn-outline-primary lh-base"${attr("disabled", connecting, true)}><img src="/assets/img/logo.svg" width="20" height="20" class="me-2 bg-dark p-1 rounded" alt="Pano"> ${escape_html(connecting ? store_get($$store_subs ??= {}, "$_", $format)("buttons.connecting") : store_get($$store_subs ??= {}, "$_", $format)("buttons.connect"))} `;
    if (connecting) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<span class="spinner-border spinner-border-sm text-primary" role="status"></span>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--></button>`;
  }
  $$payload.out += `<!--]--> <div class="row pt-3"><div class="col-6"><a${attr("class", `btn btn-link w-100 ${stringify([""].filter(Boolean).join(" "))}`)} role="button" href="javascript:void(0);"${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</a></div> <div class="col-6"><div class="animate__animated animate__zoomIn"><button type="submit"${attr("class", `btn btn-secondary w-100 ${stringify([disabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", disabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.finish"))} `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></button></div></div></div></form></div> `;
  ConfirmRemovePanoAccountModal($$payload);
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, {
    account,
    panoAccount,
    failed,
    encodedData,
    state
  });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DkcaUlmu.js')).default;
const universal_id = "src/routes/step-4/+page.js";
const imports = ["_app/immutable/nodes/7.IjfwJY51.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/uBxQ3371.js","_app/immutable/chunks/D_C3fpxp.js","_app/immutable/chunks/CuDMowqM.js","_app/immutable/chunks/B0Z4_C0J.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/CFqJ9rIX.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/RYNJSc8L.js","_app/immutable/chunks/DO8W7KWV.js","_app/immutable/chunks/CF9aIN3Y.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/DJiSYrUa.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Step4 as S, _7 as _ };
//# sourceMappingURL=7-CV8U3aTn.js.map
