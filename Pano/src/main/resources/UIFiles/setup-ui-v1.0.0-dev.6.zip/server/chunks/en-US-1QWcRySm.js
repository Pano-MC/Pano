const buttons = { "connect": "Connect", "connecting": "Connecting...", "remove": "Remove", "close": "Close", "skip": "Skip", "next": "Next", "back": "Back", "finish": "Finish", "other": "Other", "yes": "Yes", "cancel": "Cancel" };
const title = "Pano Installer";
const steps = { "website": { "title": "Title", "description": "The title and description will appear in search engines.", "inputs": { "title": "Title", "description": "Description" } }, "database": { "title": "Database", "description": "Enter database information so that the Pano can store and process data.", "help-link-text": "How do I find out my database information?", "databases": { "mysql-or-mariadb": "MySQL or MariaDB" }, "inputs": { "address": "Database Address", "name": "Database Name", "username": "Database Username", "password": "Database Password", "prefix": "Database Table Prefix" } }, "email": { "title": "E-Mail (SMTP)", "description": "Pano requires an email provider to be able to send emails. Please log in with the e-mail service you want to use.", "help-link-text": "More about setting SMTP email", "return-back-to-service-list-text": "Back to service list", "inputs": { "username": "Username (Address)", "password": "Password", "details-button": "Details", "ssl": "Use SSL", "tls-setting": "TLS Setting", "sending-address": "Sender Address", "hostname": "Hostname", "port": "Port", "auth-method": "Auth Method" } }, "account": { "title": "Account", "description": "You need an administrator account to login the Pano.", "online-account": "Online Account", "online-account-description": "Connect your online Pano account to access plugins, themes, and updates.", "online-account-connected": "Online account connected:", "inputs": { "email": "E-Mail", "username": "Minecraft Username", "password": "Password", "password-help-text": "Minimum 6 letters." } } };
const components = { "modals": { "confirm-remove-pano-account": { "title": "Are you sure to disconnect your online Pano account?" }, "confirm-skip-smtp": { "title": "Are you sure to skip setting up E-Mail (SMTP)?", "description": "Skipping this step may result in missing/not working features such as Password Reset or E-Mail validation." } }, "toasts": { "pano-account-connect-success": "Your Pano account has been successfully connected!", "pano-account-disconnect-success": "Pano account removed successfully!", "pano-account-disconnect-fail": "An error occurred during the removing Pano account!" } };
const enUS = {
  buttons,
  title,
  "welcome-title": "Welcome",
  "welcome-description": "Let's start the installation with language selection.",
  "start-button": "Start",
  steps,
  "connect-failed-alert": "Connecting your Pano account has been failed! Try again.",
  components
};

export { buttons, components, enUS as default, steps, title };
//# sourceMappingURL=en-US-1QWcRySm.js.map
