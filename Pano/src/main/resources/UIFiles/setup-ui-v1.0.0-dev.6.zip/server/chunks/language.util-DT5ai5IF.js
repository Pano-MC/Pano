import { af as get, a1 as writable } from './index2-BSgs6Xxn.js';
import { i as init$1, r as registerLocaleLoader, w as waitLocale, a as $locale } from './runtime-us51QdR2.js';

const Languages = Object.freeze({
  EN_US: {
    locale: "en-US",
    file: () => import('./en-US-1QWcRySm.js'),
    name: "English (US)"
  },
  TR: {
    locale: "tr",
    file: () => import('./tr-BuL8pzUm.js'),
    derivatives: ["tr-tr"],
    name: "Türkçe (TR)"
  }
});
const loadedLanguages = writable([]);
const languageLoading = writable(false);
const currentLanguage = writable(null);
async function init(initialLocale) {
  const language = getLanguageByLocale(get($locale));
  const languageToLoad = get(currentLanguage) || (language === null ? Languages.EN_US : language);
  await loadLanguage(languageToLoad);
  currentLanguage.set(languageToLoad);
  init$1({
    fallbackLocale: "en-US",
    initialLocale
  });
}
function getAcceptedLanguage(headers) {
  const header = headers.get("accept-language");
  if (typeof header === "undefined" || !header) {
    return "";
  }
  const split = header.split(",");
  if (split.length === 0) {
    return "";
  }
  return split[0];
}
async function loadLanguage(language) {
  if (get(loadedLanguages).indexOf(language) !== -1) {
    return;
  }
  loadedLanguages.update((list) => {
    list.push(language);
    return list;
  });
  registerLocaleLoader(language.locale, language.file);
  await waitLocale(language.locale);
  if (language.derivatives) {
    for (const derivative of language.derivatives) {
      registerLocaleLoader(derivative, language.file);
      await waitLocale(language.locale);
    }
  }
}
function getLanguageByLocale(locale) {
  let foundLanguage = null;
  Object.keys(Languages).forEach((language) => {
    if (language.locale === locale) {
      foundLanguage = language;
    }
  });
  return foundLanguage;
}

export { Languages as L, currentLanguage as c, getAcceptedLanguage as g, init as i, languageLoading as l };
//# sourceMappingURL=language.util-DT5ai5IF.js.map
