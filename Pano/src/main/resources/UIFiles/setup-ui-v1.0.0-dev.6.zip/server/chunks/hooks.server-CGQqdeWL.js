import { C as COOKIE_PREFIX, a as CSRF_TOKEN_COOKIE_NAME } from './variables-CdsVAjOE.js';
import { g as getAcceptedLanguage } from './language.util-DT5ai5IF.js';
import './index2-BSgs6Xxn.js';
import './runtime-us51QdR2.js';

async function handle({
  event,
  event: {
    cookies,
    request: { headers }
  },
  resolve
}) {
  event.locals.acceptedLanguage = getAcceptedLanguage(headers);
  event.locals.CSRFToken = cookies.get(COOKIE_PREFIX + CSRF_TOKEN_COOKIE_NAME);
  return resolve(event);
}

export { handle };
//# sourceMappingURL=hooks.server-CGQqdeWL.js.map
