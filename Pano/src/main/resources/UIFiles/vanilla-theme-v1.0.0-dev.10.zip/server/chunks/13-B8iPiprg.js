import { a6 as bind_props, t as pop, a8 as store_get, a9 as unsubscribe_stores, a1 as writable, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { e as error } from './index2-DzcLzHBX.js';
import { o as onDestroy } from './index-server-ClX78Gki.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { P as PlayerHead, a as PlayerPermissionBadge } from './PlayerHead-76jvL1tB.js';
import { b as ApiUtil } from './api.util-BEO4Rm0G.js';
import { g as getPlayerProfile } from './profile2-D54TozTk.js';

const data = writable({
  username: "",
  lastActivityTime: 0,
  inGame: false,
  permissionGroupName: ""
});
const load$1 = async (event) => {
  data.set({
    ...await ApiUtil.get({
      path: `/api/sidebars/profiles/${event.params.player}`,
      request: event
    }),
    username: event.params.player
  });
};
String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerProfileSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let checkTime = 0;
  let interval;
  let side = $$props["side"];
  onDestroy(() => {
    clearInterval(interval);
  });
  Sidebar($$payload, {
    side,
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3"><div class="card"><div class="card-body">`;
      PlayerHead($$payload2, {
        username: store_get($$store_subs ??= {}, "$data", data).username,
        inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
        lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
        checkTime
      });
      $$payload2.out += `<!----> <div class="text-center"><h2 class="my-3">${escape_html(store_get($$store_subs ??= {}, "$data", data).username)}</h2> `;
      PlayerPermissionBadge($$payload2, {
        permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName
      });
      $$payload2.out += `<!----></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { side });
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  let data2 = { registerDate: 0 };
  await load$1(event);
  await getPlayerProfile({ username: event.params.player, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data2 = body;
  });
  return {
    ...data2,
    sidebar: PlayerProfileSidebar,
    sidebarProps: { side: "left" }
  };
}
function PlayerProfile($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  $$payload.out += `<div class="card"><div class="card-body"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.title"))}</h4> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data2.registerDate });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DYuPkNV-.js')).default;
const universal_id = "src/routes/player/[player]/+page.js";
const imports = ["_app/immutable/nodes/13.u1r89_bv.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/DAMlPHdW.js","_app/immutable/chunks/D3uXKt-d.js","_app/immutable/chunks/Do-GVcL3.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/C0s3kGKs.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/PNeb7KMw.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/BBmpnScm.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BVg1Ve38.js","_app/immutable/chunks/yZ7j2uOu.js","_app/immutable/chunks/CrVqL45t.js"];
const stylesheets = [];
const fonts = [];

var _13 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PlayerProfile as P, _13 as _ };
//# sourceMappingURL=13-B8iPiprg.js.map
