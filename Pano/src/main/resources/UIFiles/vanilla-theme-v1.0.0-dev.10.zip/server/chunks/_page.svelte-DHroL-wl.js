import { S as Settings } from './16-CPCB-SJf.js';
import './index3-CeMfA1rb.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import './ProfileSidebar-CpfbYp9H.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './api.util-BEO4Rm0G.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload) {
  Settings($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DHroL-wl.js.map
