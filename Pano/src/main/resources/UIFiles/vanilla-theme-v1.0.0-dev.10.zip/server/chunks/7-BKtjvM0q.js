import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { S as SuccessAlert } from './SuccessAlert-xdL2cry4.js';

async function load({ parent, url: { searchParams } }) {
  await parent();
  const token = searchParams.get("token") || "";
  return { token };
}
function ActivateNewEmail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let error;
  let successMessage = null;
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.title"))}</h3> <img alt="Allay" src="https://cdn3.emoji.gg/emojis/8182-allay-dancing.gif"> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message: successMessage });
  $$payload.out += `<!----> <button${attr("class", `btn btn-secondary w-100 ${stringify([
    ""
  ].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.activate-button"))}</button></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-AQBWP-sF.js')).default;
const universal_id = "src/routes/activate-new-email/+page.js";
const imports = ["_app/immutable/nodes/7.Ctc1shd4.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/CnS6N66L.js","_app/immutable/chunks/D3uXKt-d.js","_app/immutable/chunks/Bf5DHBFu.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/BNuLYJla.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ActivateNewEmail as A, _7 as _ };
//# sourceMappingURL=7-BKtjvM0q.js.map
