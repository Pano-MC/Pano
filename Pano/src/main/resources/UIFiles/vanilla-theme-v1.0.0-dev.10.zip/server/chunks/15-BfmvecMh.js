import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-CpfbYp9H.js';
import { a as getProfile } from './profile2-D54TozTk.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BfDm4hBT.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.ByY4d5Fz.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/CrT9Vb2J.js","_app/immutable/chunks/PNeb7KMw.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/D3uXKt-d.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/Dff21_42.js","_app/immutable/chunks/CnS6N66L.js","_app/immutable/chunks/DAMlPHdW.js","_app/immutable/chunks/C0s3kGKs.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/BBmpnScm.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BVg1Ve38.js","_app/immutable/chunks/Do-GVcL3.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/yZ7j2uOu.js","_app/immutable/chunks/CrVqL45t.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-BfmvecMh.js.map
