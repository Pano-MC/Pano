const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DVSVVHqG.js')).default;
const imports = ["_app/immutable/nodes/1.Bbx2yoxS.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/C0VxgYhX.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DsQCorBT.js.map
