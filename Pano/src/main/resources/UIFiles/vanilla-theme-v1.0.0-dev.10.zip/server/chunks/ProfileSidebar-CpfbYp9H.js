import { aa as getContext, a8 as store_get, a9 as unsubscribe_stores, t as pop, a1 as writable, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { o as onDestroy } from './index-server-ClX78Gki.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { p as page } from './stores-BPGm-Oli.js';
import { b as ApiUtil } from './api.util-BEO4Rm0G.js';
import './client-CjlfgChI.js';
import './index2-DzcLzHBX.js';
import { P as PlayerHead, a as PlayerPermissionBadge } from './PlayerHead-76jvL1tB.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { a as attr } from './attributes-JZZbhxX3.js';

const data = writable({
  lastActivityTime: 0,
  inGame: false,
  permissionGroupName: ""
});
const load = async (event) => {
  data.set(await ApiUtil.get({ path: "/api/sidebars/profile", request: event }));
};
String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
function ProfileSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let user;
  const session = getContext("session");
  let checkTime = 0;
  let interval;
  function matching(path, pathName, startsWith = false) {
    return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
  }
  onDestroy(() => {
    clearInterval(interval);
  });
  user = store_get($$store_subs ??= {}, "$session", session).user ? store_get($$store_subs ??= {}, "$session", session).user : {};
  Sidebar($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3"><div class="card"><div class="card-body">`;
      PlayerHead($$payload2, {
        username: user.username,
        inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
        lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
        checkTime
      });
      $$payload2.out += `<!----> <div class="text-center"><h2 class="mt-3">${escape_html(user.username)}</h2> <p>${escape_html(user.email)}</p> `;
      PlayerPermissionBadge($$payload2, {
        permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName
      });
      $$payload2.out += `<!----></div></div></div></div> <div class="card"><div class="card-body"><ul class="nav nav-pills nav-fill flex-column"><li class="nav-item"><a${attr("class", `nav-link ${stringify([
        matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/profile") ? "active" : ""
      ].filter(Boolean).join(" "))}`)} href="/profile">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.profile.links.statistics"))}</a></li> <li class="nav-item"><a${attr("class", `nav-link ${stringify([
        matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/tickets", true) ? "active" : ""
      ].filter(Boolean).join(" "))}`)} href="/tickets">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.profile.links.tickets"))}</a></li> <li class="nav-item"><a${attr("class", `nav-link ${stringify([
        matching(store_get($$store_subs ??= {}, "$page", page).url.pathname, "/profile/settings", true) ? "active" : ""
      ].filter(Boolean).join(" "))}`)} href="/profile/settings">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.profile.links.settings"))}</a></li> <li class="nav-item"><button class="nav-link link-danger" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("sidebars.profile.links.logout"))}</button></li></ul></div></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

export { ProfileSidebar as P, load as l };
//# sourceMappingURL=ProfileSidebar-CpfbYp9H.js.map
