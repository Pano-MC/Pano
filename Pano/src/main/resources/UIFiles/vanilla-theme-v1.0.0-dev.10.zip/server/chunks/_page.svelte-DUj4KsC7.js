import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { H as Home } from './Home-5SNthIdy.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-pQvViTnv.js';
import './posts2-1yGbq9eM.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './html-FW6Ia4bL.js';
import './api.util-BEO4Rm0G.js';
import './NoContent-CRKA6SSq.js';
import './HomeSidebar-D13Jte22.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Home($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DUj4KsC7.js.map
