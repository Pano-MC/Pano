import { t as pop, aa as getContext, a8 as store_get, ab as stringify, a9 as unsubscribe_stores, a6 as bind_props, a1 as writable, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { O as OnlineAdmins } from './OnlineAdmins-BRQUy31Y.js';
import { b as ApiUtil } from './api.util-BEO4Rm0G.js';
import { a as attr } from './attributes-JZZbhxX3.js';

const data = writable({ onlineAdmins: [] });
const load$1 = async (event) => {
  data.set(await ApiUtil.get({ path: "/api/sidebars/support", request: event }));
};
function SupportSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  Sidebar($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3">`;
      OnlineAdmins($$payload2, {
        onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins
      });
      $$payload2.out += `<!----></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: SupportSidebar };
}
function Support($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.title"))}</h3> <p>Sana nasıl yardımcı olabiliriz?</p> <ul class="list-group list-group-horizontal text-center"><a href="/ticket/create" class="list-group-item list-group-item-action"><i class="fas fa-ticket fa-2x my-3"></i> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.description"))}</small></a> <a${attr("href", `mailto:${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.supportEmail)}`)} class="list-group-item list-group-item-action"><i class="fas fa-envelope fa-2x my-3"></i> <div class="col-auto"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.description", {
    values: {
      websiteName: store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName
    }
  }))}</small></div></a></ul></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 19;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BdY4n1gV.js')).default;
const universal_id = "src/routes/support/+page.js";
const imports = ["_app/immutable/nodes/19.DL7hyaTM.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/D3uXKt-d.js","_app/immutable/chunks/Do-GVcL3.js","_app/immutable/chunks/BnTEGfB9.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/D1bzFQjl.js","_app/immutable/chunks/DauuFb4p.js","_app/immutable/chunks/PNeb7KMw.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/C0VxgYhX.js"];
const stylesheets = [];
const fonts = [];

var _19 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Support as S, _19 as _ };
//# sourceMappingURL=19-BUpM3YEE.js.map
