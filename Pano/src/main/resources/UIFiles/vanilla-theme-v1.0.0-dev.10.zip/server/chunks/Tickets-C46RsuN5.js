import { a8 as store_get, ab as stringify, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import './client-CjlfgChI.js';
import { P as Pagination } from './Pagination-DT_5Txbj.js';
import { T as Tickets } from './Tickets2-DPZ643ZI.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { d as getTickets } from './TicketStatus-BpCBTGm1.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-CpfbYp9H.js';

const PageTypes = Object.freeze({ ALL: "ALL", CLOSED: "CLOSED" });
const DefaultPageType = PageTypes.ALL;
async function load(event, pageType = DefaultPageType) {
  const { parent } = event;
  await parent();
  pageType = pageType.toUpperCase();
  let data = {
    tickets: [],
    ticketCount: 0,
    page: 1,
    totalPage: 1,
    pageType
  };
  await load$1(event);
  await getTickets({
    page: event.params.page || 1,
    pageType,
    request: event
  }).then((body) => {
    if (body.error) {
      data = {};
      return;
    }
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Tickets_1($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><div class="row justify-content-between pb-3 align-items-center"><div class="col-auto"><h4 class="card-title mb-md-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.title"))}</h4></div> <div class="col-md-auto col-12 text-md-right text-center"><div class="btn-group"><a${attr("class", `btn btn-sm btn-outline-light btn-link ${stringify([
    data.pageType === PageTypes.ALL ? "active" : ""
  ].filter(Boolean).join(" "))}`)} role="button" href="/tickets/all">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.all"))}</a> <a${attr("class", `btn btn-sm btn-outline-light btn-link text-danger ${stringify([
    data.pageType === PageTypes.CLOSED ? "active" : ""
  ].filter(Boolean).join(" "))}`)} role="button" href="/tickets/closed">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.tickets.closed"))}</a></div></div></div> `;
  Tickets($$payload, { tickets: data.tickets });
  $$payload.out += `<!----></div></div> <br> `;
  if (data.ticketCount > 0) {
    $$payload.out += "<!--[-->";
    Pagination($$payload, {
      page: data.page,
      totalPage: data.totalPage,
      loading: false
    });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

export { PageTypes as P, Tickets_1 as T, load as l };
//# sourceMappingURL=Tickets-C46RsuN5.js.map
