import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { S as SuccessAlert } from './SuccessAlert-xdL2cry4.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';

async function load({ parent, url: { searchParams } }) {
  await parent();
  const token = searchParams.get("token") || "";
  return { token };
}
function RenewPassword($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let error;
  let message;
  let newPassword = "";
  let newPasswordRepeat = "";
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.title"))}</h3> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message });
  $$payload.out += `<!----> <form><div class="mb-3"><label for="newPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.inputs.new-password"))}</label> <input type="password" id="newPassword" class="form-control"${attr("value", newPassword)}></div> <div class="mb-3"><label for="newPasswordRepeat">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.inputs.new-password-repeat"))}</label> <input type="password" id="newPasswordRepeat" class="form-control"${attr("value", newPasswordRepeat)}></div> <button type="submit"${attr("class", `btn btn-secondary w-100 ${stringify([""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.renew-password.change-password-button"))}</button></form></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 17;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CpCSWTXQ.js')).default;
const universal_id = "src/routes/renew-password/+page.js";
const imports = ["_app/immutable/nodes/17.Dq_W0tPF.js","_app/immutable/chunks/DEfbUX9q.js","_app/immutable/chunks/2gUck4vf.js","_app/immutable/chunks/C-X8FQm1.js","_app/immutable/chunks/CAaQ_Q_j.js","_app/immutable/chunks/BYWgTFxB.js","_app/immutable/chunks/BJWfMXI2.js","_app/immutable/chunks/DPTVSyqZ.js","_app/immutable/chunks/WX5Qb5S0.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/pRQoV16s.js","_app/immutable/chunks/C0VxgYhX.js","_app/immutable/chunks/Bf5DHBFu.js","_app/immutable/chunks/Brgnft6Q.js","_app/immutable/chunks/BNuLYJla.js","_app/immutable/chunks/CnS6N66L.js","_app/immutable/chunks/D3uXKt-d.js"];
const stylesheets = [];
const fonts = [];

var _17 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { RenewPassword as R, _17 as _ };
//# sourceMappingURL=17-Rbt64zu9.js.map
