import{a as t}from"../chunks/CAaQ_Q_j.js";export{t as start};
