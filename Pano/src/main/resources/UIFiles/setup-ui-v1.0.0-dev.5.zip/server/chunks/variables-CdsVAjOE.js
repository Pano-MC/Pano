let API_URL = "http://localhost:8088/api";
const COOKIE_PREFIX = "pano_";
const CSRF_TOKEN_COOKIE_NAME = "csrf_token";
const CSRF_HEADER = "X-CSRF-Token";
function updateApiUrl(apiUrl) {
  API_URL = apiUrl;
}

export { API_URL as A, COOKIE_PREFIX as C, CSRF_TOKEN_COOKIE_NAME as a, CSRF_HEADER as b, updateApiUrl as u };
//# sourceMappingURL=variables-CdsVAjOE.js.map
