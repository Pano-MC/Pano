const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-BPdEx6h9.js')).default;
const imports = ["_app/immutable/nodes/1.CeMJMexz.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CcuSMkx4.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-C6ieEmIN.js.map
