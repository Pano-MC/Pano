const buttons = { "connect": "Bağla", "connecting": "Bağlanıyor...", "remove": "Kaldır", "close": "Kapat", "skip": "Atla", "next": "İleri", "back": "Geri", "finish": "Tamamla", "other": "Diğer", "yes": "Evet", "cancel": "İptal" };
const title = "Pano Kurulum";
const steps = { "website": { "title": "İsim", "description": "Site ismi ve açıklam arama motorlarında görünecektir.", "inputs": { "title": "Başlık", "description": "Açıklama" } }, "database": { "title": "Veri Tabanı", "description": "Pano'nun veri depolayabilmesi ve işleyebilmesi için veri tabanı bilgilerini girin.", "help-link-text": "Veri tabanı bilgilerimi nasıl öğrenirim?", "databases": { "mysql-or-mariadb": "MySQL veya MariaDB" }, "inputs": { "address": "Veri Tabanı Adresi", "name": "Veri Tabanı Adı", "username": "Veri Tabanı Kullanıcı Adı", "password": "Veri Tabanı Şifresi", "prefix": "Veri Tabanı Tablo Ön Eki" } }, "email": { "title": "E-Posta (SMTP)", "description": "Pano, e-posta gönderebilmek için bir e-posta sağlayıcısına ihtiyaç duyar. Lütfen kullanmak istediğiniz e-posta servisi ile oturum açın.", "help-link-text": "SMTP E-Posta ayarlama hakkında daha fazla", "return-back-to-service-list-text": "Servis listesine geri dön", "inputs": { "username": "Kullanıcı Adı (Adres)", "password": "Şifre", "details-button": "Ayrıntılar", "ssl": "SSL Kullan", "tls-setting": "TLS Ayarı", "sending-address": "Gönderici Adresi", "hostname": "Sağlayıcı Adresi", "port": "Port", "auth-method": "Giriş Methodu" } }, "account": { "title": "Hesap", "description": "Pano'ya giriş yapabilmek için bir yönetici hesabına ihtiyacınız var.", "online-account": "Çevrimiçi Hesap", "online-account-description": "Eklenti, tema ve güncellemelere erişebilmek için çevrimiçi Pano hesabınızı bağlayın.", "online-account-connected": "Pano hesabı bağlandı:", "inputs": { "email": "E-Posta", "username": "Minecraft Kullanıcı Adı", "password": "Şifre", "password-help-text": "Minimum 6 karakter." } } };
const components = { "modals": { "confirm-remove-pano-account": { "title": "Çevrimiçi Pano hesabınızı kaldırmak istediğinize emin misiniz?" }, "confirm-skip-smtp": { "title": "E-Posta (SMTP) kurulumunu atlamak istediğinize emin misiniz?", "description": "Bu adımı atlamak, Şifre Sıfırlama veya E-Posta doğrulama gibi özelliklerin eksik veya çalışmamasına neden olabilir." } }, "toasts": { "pano-account-connect-success": "Pano hesabın başarıyla bağlandı!", "pano-account-disconnect-success": "Pano hesabı başarıyla kaldırıldı!", "pano-account-disconnect-fail": "Pano hesabı kaldırılırken hata oluştu!" } };
const tr = {
  buttons,
  title,
  "welcome-title": "Hoş geldiniz",
  "welcome-description": "Kuruluma ilk olarak dil seçimi ile başlayalım.",
  "start-button": "Başla",
  steps,
  "connect-failed-alert": "Pano hesabınıza bağlanırken hata oluştu! Lütfen tekrar deneyin.",
  components
};

export { buttons, components, tr as default, steps, title };
//# sourceMappingURL=tr-n6Uqb-K2.js.map
