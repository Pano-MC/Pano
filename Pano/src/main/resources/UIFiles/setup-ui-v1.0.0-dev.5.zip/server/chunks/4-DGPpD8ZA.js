import { ac as fallback, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index2-BSgs6Xxn.js';
import { a as attr } from './attributes-BEm38Kz9.js';
import { e as escape_html } from './client-DcSItIJ-.js';
import { $ as $format } from './runtime-us51QdR2.js';

async function load({ parent }) {
  const { stepInfo: { websiteName, websiteDescription } } = await parent();
  return { stepInfo: { websiteName, websiteDescription } };
}
function Step1($$payload, $$props) {
  push();
  var $$store_subs;
  let disabled;
  let loading = false;
  let websiteName = fallback($$props["websiteName"], "");
  let websiteDescription = fallback($$props["websiteDescription"], "");
  disabled = websiteName === "" || websiteDescription === "";
  $$payload.out += `<div class="animate__animated animate__fadeIn"><div class="animate__animated animate__slideInUp"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.title"))}</h4> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.description"))}</p></div> <form><label for="websiteName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.title"))}</label> <input id="websiteName" class="form-control form-control-lg mb-3" placeholder="Panocraft" type="text"${attr("value", websiteName)}> <label for="websiteName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.website.inputs.description"))}</label> <textarea id="websiteDescription" class="form-control mb-3" rows="2">`;
  const $$body = escape_html(websiteDescription);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea> <div class="row"><div class="col-6"><a href="javascript:void(0);"${attr("class", `btn btn-link w-100 ${stringify([""].filter(Boolean).join(" "))}`)} role="button"${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</a></div> <div class="col-6"><div class="animate__animated animate__zoomIn"><button type="submit"${attr("class", `btn btn-primary w-100 ${stringify([disabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", disabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.next"))}</button></div></div></div></form></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { websiteName, websiteDescription });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bj-wVlzF.js')).default;
const universal_id = "src/routes/step-1/+page.js";
const imports = ["_app/immutable/nodes/4.-ViJxaQi.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/5f_pjZ0A.js","_app/immutable/chunks/CcuSMkx4.js","_app/immutable/chunks/B0Z4_C0J.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js"];
const stylesheets = [];
const fonts = [];

var _4 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Step1 as S, _4 as _ };
//# sourceMappingURL=4-DGPpD8ZA.js.map
