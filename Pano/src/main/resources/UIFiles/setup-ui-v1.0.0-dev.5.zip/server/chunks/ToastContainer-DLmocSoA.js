import { p as push, aa as ensure_array_like, a8 as store_get, ad as spread_props, a9 as unsubscribe_stores, t as pop, a1 as writable } from './index2-BSgs6Xxn.js';

const toasts = writable([]);
Array.prototype.insert = function(index, item) {
  this.splice(index, 0, item);
  return this;
};
Array.prototype.remove = function(index) {
  this.splice(index, 1);
  return this;
};
function ToastContainer($$payload, $$props) {
  push();
  var $$store_subs;
  const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$toasts", toasts));
  $$payload.out += `<div class="toast-container position-fixed bottom-0 start-50 translate-middle-x mb-3"><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let toast = each_array[index];
    $$payload.out += `<!---->`;
    toast.component?.($$payload, spread_props([{ id: toast.id }, toast.params]));
    $$payload.out += `<!---->`;
  }
  $$payload.out += `<!--]--></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

export { ToastContainer as T };
//# sourceMappingURL=ToastContainer-DLmocSoA.js.map
