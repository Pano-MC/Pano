const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BVOeF0bZ.js')).default;
const imports = ["_app/immutable/nodes/3.CqFWMRxw.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-DgRnZNYI.js.map
