const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BUCAKqYC.js')).default;
const imports = ["_app/immutable/nodes/2.D-9aJ4xV.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/5f_pjZ0A.js","_app/immutable/chunks/CcuSMkx4.js","_app/immutable/chunks/H_5URby_.js","_app/immutable/chunks/C1FmrZbK.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=2-D0-Zg47k.js.map
