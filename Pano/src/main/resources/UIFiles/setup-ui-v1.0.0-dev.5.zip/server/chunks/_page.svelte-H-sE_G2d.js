import { ad as spread_props, a6 as bind_props, t as pop, p as push } from './index2-BSgs6Xxn.js';
import { S as Step3 } from './6-BrrGfTsP.js';
import './runtime-us51QdR2.js';
import './attributes-BEm38Kz9.js';
import './client-DcSItIJ-.js';
import './ErrorAlert-CWi-wjrX.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  Step3($$payload, spread_props([data.stepInfo]));
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-H-sE_G2d.js.map
