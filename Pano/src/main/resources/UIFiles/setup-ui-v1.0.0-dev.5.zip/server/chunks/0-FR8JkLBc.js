import { a1 as writable, a5 as head, a6 as bind_props, t as pop, a7 as slot, p as push, a8 as store_get, a9 as unsubscribe_stores, aa as ensure_array_like, ab as stringify } from './index2-BSgs6Xxn.js';
import { $ as $format } from './runtime-us51QdR2.js';
import { E as ErrorAlert } from './ErrorAlert-CWi-wjrX.js';
import { e as escape_html } from './client-DcSItIJ-.js';
import { A as API_URL, u as updateApiUrl, b as CSRF_HEADER } from './variables-CdsVAjOE.js';
import { a as attr } from './attributes-BEm38Kz9.js';
import { T as ToastContainer } from './ToastContainer-DLmocSoA.js';
import { i as init } from './language.util-h1m3Uz3y.js';
import { r as redirect } from './index3-DyoisQP2.js';

function App($$payload, $$props) {
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!---->`;
}
const NETWORK_ERROR = "NETWORK_ERROR";
const ApiUtil = {
  get({ path, request, csrfToken, token }) {
    return this.customRequest({ path, request, csrfToken, token });
  },
  post({ path, request, body, headers, csrfToken, token }) {
    return this.customRequest({
      path,
      data: {
        method: "POST",
        credentials: "include",
        body,
        headers
      },
      request,
      csrfToken,
      token
    });
  },
  put({ path, request, body, headers, csrfToken, token }) {
    return this.customRequest({
      path,
      data: {
        method: "PUT",
        credentials: "include",
        body,
        headers
      },
      request,
      csrfToken,
      token
    });
  },
  delete({ path, request, headers, csrfToken, token }) {
    return this.customRequest({
      path,
      data: {
        method: "DELETE",
        headers
      },
      request,
      csrfToken,
      token
    });
  },
  async customRequest({ path, data = {}, request, csrfToken, token }) {
    if (!csrfToken) {
      let session2;
      if (request) {
        const parentData = await request.parent();
        const { session: parentSession } = parentData;
        session2 = parentSession;
      }
      csrfToken = session2 && session2.csrfToken;
    }
    const CSRFHeader = {};
    if (csrfToken) CSRFHeader[CSRF_HEADER] = csrfToken;
    if (!(data.body instanceof FormData)) {
      data.body = JSON.stringify(data.body);
      data.headers = {
        "Content-Type": "application/json",
        ...data.headers
      };
    }
    const options = {
      ...data,
      headers: csrfToken ? { ...data.headers, ...CSRFHeader } : data.headers
    };
    if (token) {
      options.headers["Authorization"] = `Bearer ${token}`;
    } else {
      const isCredentialsSupported = "credentials" in Request.prototype;
      if (isCredentialsSupported) {
        options["credentials"] = "include";
      }
    }
    path = `${API_URL}/${path.replace("/api/", "")}`;
    const fetchRequest = request && request.fetch ? request.fetch(path, options) : fetch(path, options);
    return fetchRequest.then((r) => r.text()).then((json) => {
      try {
        return JSON.parse(json);
      } catch (err) {
        return json;
      }
    });
  }
};
const session = writable({});
const currentStep = writable(0);
function checkRoute(step, pathname) {
  const stepLocation = "/step-" + step;
  if (step === 0 && pathname !== "/") {
    return "/";
  } else if (step !== 0 && pathname !== stepLocation) {
    return stepLocation;
  } else {
    return null;
  }
}
async function checkCurrentStep() {
  return ApiUtil.get({ path: "/api/setup/step" }).then((body) => {
    if (body.error) {
      return { ...body, step: 0 };
    }
    return body;
  }).catch(() => {
    return { error: NETWORK_ERROR, step: 0 };
  });
}
const steps = [
  {
    name: "steps.website.title",
    icon: "fa-solid fa-globe"
  },
  {
    name: "steps.database.title",
    icon: "fa-solid fa-database"
  },
  {
    name: "steps.email.title",
    icon: "fa-solid fa-envelope"
  },
  {
    name: "steps.account.title",
    icon: "fa-solid fa-user"
  }
];
function Navbar($$payload, $$props) {
  push();
  var $$store_subs;
  const each_array = ensure_array_like(steps);
  $$payload.out += `<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent"><ul class="navbar-nav text-lg-center mt-lg-0 mt-2"><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let step = each_array[index];
    $$payload.out += `<li class="nav-item"><a${attr("class", `nav-link ${stringify([
      store_get($$store_subs ??= {}, "$currentStep", currentStep) === index + 1 ? "active" : "",
      store_get($$store_subs ??= {}, "$currentStep", currentStep) > index + 1 ? "link-success" : ""
    ].filter(Boolean).join(" "))}`)}${attr("href", store_get($$store_subs ??= {}, "$currentStep", currentStep) <= index + 1 ? null : "javascript:void(0);")}>`;
    if (store_get($$store_subs ??= {}, "$currentStep", currentStep) > index + 1) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<i class="fa-solid fa-check-circle me-lg-1"></i>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<i${attr("class", `${stringify(step.icon)} me-lg-1`)}></i>`;
    }
    $$payload.out += `<!--]--> ${escape_html(index + 1)}. ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(step.name))}</a></li>`;
  }
  $$payload.out += `<!--]--></ul></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function loadServer(input) {
  const {
    url: { pathname },
    locals: { acceptedLanguage, CSRFToken }
  } = input;
  const apiUrlEnv = process.env.API_URL;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  const stepInfo = await checkCurrentStep();
  const { step } = stepInfo;
  const route = checkRoute(step, pathname);
  if (route) {
    throw redirect(302, route);
  }
  return {
    stepInfo,
    acceptedLanguage,
    CSRFToken,
    apiUrlEnv
  };
}
async function load({
  data,
  data: {
    stepInfo: { step },
    acceptedLanguage,
    CSRFToken,
    apiUrlEnv
  }
}) {
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  session.set({ CSRFToken });
  currentStep.set(step);
  await init(acceptedLanguage);
  return data;
}
function MainLayout($$payload, $$props) {
  push();
  var $$store_subs;
  let stepInfo = $$props["stepInfo"];
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("title"))}${escape_html(store_get($$store_subs ??= {}, "$currentStep", currentStep) !== 0 ? ` ${store_get($$store_subs ??= {}, "$currentStep", currentStep)}/4` : "")}</title>`;
  });
  App($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="bg-light min-vh-100 bg-light overflow-scroll"><div class="navbar bg-primary navbar-dark navbar-expand-lg"><div class="container"><a href="https://panomc.com" target="_blank" class="navbar-brand"><img alt="Pano" src="/assets/img/logo.svg" class="d-inline-block align-text-top me-2" width="18"> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("title"))}</a> <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa-solid fa-bars"></i></button> `;
      Navbar($$payload2);
      $$payload2.out += `<!----></div></div> <div class="pt-3"><div class="container">`;
      ErrorAlert($$payload2, { error: stepInfo.error });
      $$payload2.out += `<!----> <div class="card"><div class="card-body"><!---->`;
      slot($$payload2, $$props, "default", {});
      $$payload2.out += `<!----></div></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  ToastContainer($$payload);
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { stepInfo });
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

var _layout_server = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: loadServer
});

const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Bf29pz9v.js')).default;
const universal_id = "src/routes/+layout.js";
const server_id = "src/routes/+layout.server.js";
const imports = ["_app/immutable/nodes/0.jwNY5FZc.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/CFqJ9rIX.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/RYNJSc8L.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/H_5URby_.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/5f_pjZ0A.js","_app/immutable/chunks/CcuSMkx4.js","_app/immutable/chunks/DO8W7KWV.js","_app/immutable/chunks/uBxQ3371.js"];
const stylesheets = ["_app/immutable/assets/0.BrzJZLD8.css"];
const fonts = [];

var _0 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  server: _layout_server,
  server_id: server_id,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { MainLayout as M, _0 as _ };
//# sourceMappingURL=0-FR8JkLBc.js.map
