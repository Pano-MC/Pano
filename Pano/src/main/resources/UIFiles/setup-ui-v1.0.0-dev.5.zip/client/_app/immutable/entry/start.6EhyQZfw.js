import{a as t}from"../chunks/CcuSMkx4.js";export{t as start};
