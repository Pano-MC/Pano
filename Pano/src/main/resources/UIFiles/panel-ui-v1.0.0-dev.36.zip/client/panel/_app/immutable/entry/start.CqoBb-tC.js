import{b as a}from"../chunks/entry.D8bb_ly-.js";export{a as start};
