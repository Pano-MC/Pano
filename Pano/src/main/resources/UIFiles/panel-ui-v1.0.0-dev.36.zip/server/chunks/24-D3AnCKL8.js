import { l as load$1, M as Modes } from './PermissionGroupDetail-BFYWF71r.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 24;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C0OYJbpH.js')).default;
const universal_id = "src/routes/players/perm-groups/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/24.DGy7siOl.js","_app/immutable/chunks/PermissionGroupDetail.Cm_zwdXa.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/index.C7T7Jm2u.js","_app/immutable/chunks/entry.D8bb_ly-.js","_app/immutable/chunks/paths.B8XadqNy.js","_app/immutable/chunks/api.util.DekGRgvx.js","_app/immutable/chunks/stores.BBaGVmNN.js","_app/immutable/chunks/runtime.CovcRGgu.js","_app/immutable/chunks/tooltip.util.Bu7vgOjl.js","_app/immutable/chunks/ToastContainer.DsahjZSI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=24-D3AnCKL8.js.map
