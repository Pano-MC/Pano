const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CfyWTmuf.js')).default;
const imports = ["_app/immutable/nodes/8.BZBrbPQ8.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.CovcRGgu.js","_app/immutable/chunks/entry.D8bb_ly-.js","_app/immutable/chunks/paths.B8XadqNy.js","_app/immutable/chunks/stores.BBaGVmNN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-DxD4u1HB.js.map
