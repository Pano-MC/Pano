import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as TicketCategories } from './40-B5JZbzT7.js';
import './index-DzcLzHBX.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Pagination--ODwq86l.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(TicketCategories, "TicketCategories").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-BhF5aN1K.js.map
