import { l as load$1, M as Modes } from './PostEditor-jc_AU7mE.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CNgXF1Vs.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';
import './paths-C6LjEmZF.js';

async function load(params) {
  return load$1(params, Modes.CREATE);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 27;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-oh3ImhRk.js')).default;
const universal_id = "src/routes/posts/create-post/+page.js";
const imports = ["_app/immutable/nodes/27.b2QN_Z6G.js","_app/immutable/chunks/PostEditor._W-OZcNk.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.C7T7Jm2u.js","_app/immutable/chunks/entry.D8bb_ly-.js","_app/immutable/chunks/paths.B8XadqNy.js","_app/immutable/chunks/api.util.DekGRgvx.js","_app/immutable/chunks/stores.BBaGVmNN.js","_app/immutable/chunks/runtime.CovcRGgu.js","_app/immutable/chunks/tooltip.util.Bu7vgOjl.js","_app/immutable/chunks/ConfirmDeletePostModal.CBJOwuzn.js","_app/immutable/chunks/ToastContainer.DsahjZSI.js","_app/immutable/chunks/AddEditPostCategoryModal.BQh9TxjJ.js","_app/immutable/chunks/Editor.rW1a1bpO.js","_app/immutable/chunks/NoContent.PVJgHyT6.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardMenuItem.CNq7YrXn.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=27-qbRD_ssX.js.map
