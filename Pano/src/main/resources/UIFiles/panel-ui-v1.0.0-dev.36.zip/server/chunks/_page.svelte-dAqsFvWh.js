import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardHeader } from './CardHeader-npnb-NGS.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-CshGiVuB.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import './exports-CTha0ECg.js';
import './paths-C6LjEmZF.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';

const Updates = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Güncellemeler");
  return ` <div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div slot="right" data-svelte-h="svelte-462h3r"><button type="button" class="btn btn-link">Update All</button> <button class="btn btn-secondary"><i class="fa-regular fa-arrows-rotate me-2"></i> Check Updates</button></div>`;
    },
    left: () => {
      return `<div slot="left"><span class="small" data-svelte-h="svelte-psh5v8"><i class="fa-regular fa-clock me-2"></i>
        DATE</span></div>`;
    }
  })} <div class="alert alert-warning animate__animated animate__slideInUp mb-0" role="alert" data-svelte-h="svelte-ym6hcb"><h5 class="alert-heading">Yenide başlat</h5> <p>Platform güncellemesinin uygulanabilmesi için yeniden başlatma gerekiyor.</p> <p>Tahmini süre: <b>TIME</b></p> <a class="alert-link" type="button"><i class="fa-solid fa-power-off me-2"></i>
      Yeniden Başlat</a></div> <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title" slot="left" data-svelte-h="svelte-d64xnv">Platform Updates (1)</h5>`;
    }
  })}   ${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})} <ul class="list-group" data-svelte-h="svelte-195a9p9"> <li class="list-group-item"><div class="row"><div class="col"><h5 class="card-title">ID</h5></div> <div class="col-auto"><button class="btn btn-sm btn-secondary" type="button">Update</button></div> <div class="col-auto ps-0"><a href="#" tabindex="0" class="link-danger" data-bs-toggle="popover" data-bs-trigger="focus" data-bs-custom-class="font-monospace" data-bs-title="Error Log" data-bs-content="ERR LOG"><i class="fa-solid fa-circle-exclamation fa-1x"></i></a></div></div> <div class="progress my-3" role="progressbar" aria-label="Example 1px high" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="height: 3px"><div class="progress-bar bg-secondary" style="width: 25%"></div></div> <details><summary>Changelog</summary> <p class="pt-3">CHANGELOG</p></details></li></ul></div></div> <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/", active: true }, {}, {
            default: () => {
              return `Tümü`;
            }
          })} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/" }, {}, {
            default: () => {
              return `Eklentiler`;
            }
          })} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render($$result, { href: "/" }, {}, {
            default: () => {
              return `Temalar`;
            }
          })}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left" data-svelte-h="svelte-521nlg">Resource Updates</h5>`;
    }
  })}  ${validate_component(NoContent, "NoContent").$$render(
    $$result,
    {
      icon: "fas fa-sync fa-3x",
      text: "Kaynak güncellemeleri alabilmek için lütfen Çevrimiçi Hesap bağlayın.",
      dark: false
    },
    {},
    {}
  )}</div></div> </div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Updates, "Updates").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-dAqsFvWh.js.map
