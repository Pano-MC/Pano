const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DuvkOSaP.js')).default;
const imports = ["_app/immutable/nodes/1.B-amBDJg.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.CovcRGgu.js","_app/immutable/chunks/entry.D8bb_ly-.js","_app/immutable/chunks/paths.B8XadqNy.js","_app/immutable/chunks/stores.BBaGVmNN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-Bci1Dx5E.js.map
