const index = 42;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BfVhfdQ0.js')).default;
const imports = ["_app/immutable/nodes/42.B9EoFfUW.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=42-MRhmH03c.js.map
