import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { V as ViewLayout } from './11-DuUVBATY.js';
import './auth.util-BRaxc5Jt.js';
import './stores-BDx4Az-R.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './index-DzcLzHBX.js';
import './CardMenuItem-BPNNofjf.js';
import './paths-C6LjEmZF.js';

const Layout_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ViewLayout, "Layout").$$render($$result, {}, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout_1 as default };
//# sourceMappingURL=_layout.svelte-v3K-QFUc.js.map
