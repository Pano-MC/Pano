import { l as load } from './Addons-CBcvVJWs.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardFilters-CshGiVuB.js';
import './NoContent-Cd8O1sR9.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DwAnsQHJ.js')).default;
const universal_id = "src/routes/addons/+page.js";
const imports = ["_app/immutable/nodes/13.DAOF86q-.js","_app/immutable/chunks/Addons.BFc4bVJe.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.C7T7Jm2u.js","_app/immutable/chunks/entry.D8bb_ly-.js","_app/immutable/chunks/paths.B8XadqNy.js","_app/immutable/chunks/api.util.DekGRgvx.js","_app/immutable/chunks/stores.BBaGVmNN.js","_app/immutable/chunks/tooltip.util.Bu7vgOjl.js","_app/immutable/chunks/ToastContainer.DsahjZSI.js","_app/immutable/chunks/runtime.CovcRGgu.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.CjMNuYL-.js","_app/immutable/chunks/CardFilters.Cs_RwTbd.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.kt6vQAl_.js","_app/immutable/chunks/NoContent.PVJgHyT6.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=13-DR9vfYhC.js.map
