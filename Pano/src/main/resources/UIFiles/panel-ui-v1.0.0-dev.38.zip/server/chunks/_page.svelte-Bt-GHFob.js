import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { S as Statistics } from './38-DpvIVy18.js';
import './index-DzcLzHBX.js';
import './api.util-CD801QWb.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './format-DZNhO2Yc.js';
import './differenceInYears-DblCvIx9.js';
import './differenceInSeconds-C8IiJITI.js';
import './CardHeader-npnb-NGS.js';
import './language.util-2VlJt8zV.js';
import './paths-C6LjEmZF.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Statistics, "Statistics").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-Bt-GHFob.js.map
