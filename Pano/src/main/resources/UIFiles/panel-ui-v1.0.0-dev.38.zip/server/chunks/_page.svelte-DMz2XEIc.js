import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { S as ServerSettings } from './ServerSettings-DFIjO5Bw.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './ToastContainer-D6cKqDaa.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ServerSettings, "ServerSettings").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DMz2XEIc.js.map
