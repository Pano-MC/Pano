import { w as writable } from './index2-Dyghn50Q.js';
import { i as init$1, r as registerLocaleLoader, w as waitLocale } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { g as get_store_value } from './ssr-ffuobYCI.js';

const loadedLanguages = writable([]);
const currentLanguage = writable(null);
const Languages = writable({});
async function fetchLanguages(event) {
  const response = await event.fetch(base + "/panel-api/languages");
  const languages = await response.json();
  Languages.set(languages);
}
async function init(initialLocale, event) {
  await fetchLanguages(event);
  const language = getLanguageByLocale(initialLocale);
  const languageToLoad = language || get_store_value(Languages)["en-US"];
  await loadLanguage(languageToLoad, event);
  currentLanguage.set(languageToLoad);
  init$1({
    fallbackLocale: "en-US",
    initialLocale: languageToLoad.locale
  });
}
async function loadLanguage(language, event) {
  if (get_store_value(loadedLanguages).indexOf(language) !== -1) {
    return;
  }
  loadedLanguages.update((list) => {
    list.push(language);
    return list;
  });
  const useFetch = event ? event.fetch : fetch;
  const response = await useFetch(base + `/panel-api/languages/${language.locale}.json`);
  const languageFile = await response.json();
  registerLocaleLoader(language.locale, async () => languageFile);
  await waitLocale(language.locale);
  if (language.derivatives) {
    for (const derivative of language.derivatives) {
      registerLocaleLoader(derivative, async () => languageFile);
      await waitLocale(language.locale);
    }
  }
}
function getLanguageByLocale(locale) {
  let foundLanguage = null;
  const languages = get_store_value(Languages);
  Object.keys(languages).forEach((key) => {
    const language = languages[key];
    if (language.locale === locale) {
      foundLanguage = language;
    }
  });
  return foundLanguage;
}

export { Languages as L, currentLanguage as c, init as i };
//# sourceMappingURL=language.util-2VlJt8zV.js.map
