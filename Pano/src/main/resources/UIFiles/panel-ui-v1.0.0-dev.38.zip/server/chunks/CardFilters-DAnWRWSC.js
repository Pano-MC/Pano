import { c as create_ssr_component, d as add_attribute } from './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import './runtime-DMBi37QM.js';

const CardFiltersItem = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { href } = $$props;
  let { active = false } = $$props;
  if ($$props.href === void 0 && $$bindings.href && href !== void 0) $$bindings.href(href);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0) $$bindings.active(active);
  return `<li class="nav-item"><a class="${["nav-link text-truncate pt-0", active ? "active" : ""].join(" ").trim()}"${add_attribute("href", base + href, 0)}>${slots.default ? slots.default({}) : ``}</a> </li>`;
});
const CardFilters = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<ul class="nav nav-underline small col-sm-auto col justify-content-md-start justify-content-center">${slots.default ? slots.default({}) : ``}</ul>`;
});

export { CardFilters as C, CardFiltersItem as a };
//# sourceMappingURL=CardFilters-DAnWRWSC.js.map
