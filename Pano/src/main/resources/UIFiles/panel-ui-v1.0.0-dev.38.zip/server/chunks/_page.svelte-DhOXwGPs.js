import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PostEditor } from './PostEditor-DrHQmJrW.js';
import './index-DzcLzHBX.js';
import './api.util-CD801QWb.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CNgXF1Vs.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';
import './paths-C6LjEmZF.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(PostEditor, "PostEditor").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DhOXwGPs.js.map
