import { c as create_ssr_component, v as validate_component, a as subscribe, f as getContext, e as escape, d as add_attribute } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { p as page } from './stores-BDx4Az-R.js';
import { b as base } from './paths-C6LjEmZF.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';

const Error = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  let $_, $$unsubscribe__;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const pageTitle = getContext("pageTitle");
  pageTitle.set($_("pages.error.title", { values: { status: $page.status } }));
  $$unsubscribe_page();
  $$unsubscribe__();
  return ` <div class="container"><div class="alert alert-danger animated bounceInDown" role="alert">${escape($_("page-error." + $page.status) || $page.error.message)}</div> <img${add_attribute("alt", $_("pages.error.title", { values: { status: $page.status } }), 0)} class="img-fluid d-block m-auto" src="${escape(base, true) + "/assets/img/404.png"}" width="280"> </div>`;
});
const Error_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Error, "Error").$$render($$result, {}, {}, {})}`;
});

export { Error_1 as default };
//# sourceMappingURL=_error.svelte-DuvkOSaP.js.map
