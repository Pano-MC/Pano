import { l as load } from './PermissionGroupDetail-B1ZG9qP4.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-CD801QWb.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 23;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BlbMciNC.js')).default;
const universal_id = "src/routes/players/perm-groups/create/+page.js";
const imports = ["_app/immutable/nodes/23.CoZjVy0n.js","_app/immutable/chunks/PermissionGroupDetail.DjqTKKPn.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/index.B389owzx.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/api.util.Dg842-21.js","_app/immutable/chunks/stores.CsUY_SYv.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/tooltip.util.B9pXg_0U.js","_app/immutable/chunks/ToastContainer.x2jPa-x4.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=23-DG9gb9ZW.js.map
