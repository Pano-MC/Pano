const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DuvkOSaP.js')).default;
const imports = ["_app/immutable/nodes/1.BowaqVnq.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/stores.CsUY_SYv.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-Bht94dy8.js.map
