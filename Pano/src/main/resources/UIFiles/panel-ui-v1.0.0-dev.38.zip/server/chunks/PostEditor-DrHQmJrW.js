import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, d as add_attribute, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { b as ApiUtil } from './api.util-CD801QWb.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';
import { A as AddEditPostCategoryModal } from './AddEditPostCategoryModal-BamjU8eK.js';
import { E as Editor_1 } from './Editor-CNgXF1Vs.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { P as PageActions } from './PageActions-EhVg4ruf.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-BPNNofjf.js';

const Modes = Object.freeze({ EDIT: "edit", CREATE: "create" });
const StatusTypes = Object.freeze({
  PUBLISHED: "PUBLISHED",
  DRAFT: "DRAFT",
  TRASH: "TRASH"
});
const DefaultMode = Modes.CREATE;
async function load(event, mode = DefaultMode) {
  const { parent } = event;
  await parent();
  let data = {
    post: {
      id: -1,
      title: "",
      text: "",
      category: -1,
      status: -1,
      date: 0,
      thumbnailUrl: ""
    },
    categoryCount: 0,
    categories: [],
    mode,
    error: {}
  };
  if (mode === Modes.EDIT) {
    const id = parseInt(event.params.id) || -1;
    const postBody = await ApiUtil.get({
      path: `/api/panel/posts/${id}`,
      request: event
    });
    if (postBody.error) {
      if (postBody.error === "POST_NOT_FOUND") {
        throw error(404, postBody.error);
      }
      throw error(500, postBody.error);
    }
    postBody.id = id;
    data.post = postBody.post;
  }
  const categoriesBody = await ApiUtil.get({
    path: "/api/panel/post/categories",
    request: event
  });
  data = { ...data, ...categoriesBody };
  return data;
}
function getStatusByPostStatus(status) {
  return status === StatusTypes.TRASH ? "pages.post-editor.trash" : status === StatusTypes.PUBLISHED ? "pages.post-editor.published" : status === StatusTypes.DRAFT ? "pages.post-editor.draft" : "pages.post-editor.new";
}
const PostEditor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  let isEditorEmpty = true;
  const pageTitle = getContext("pageTitle");
  pageTitle.set(data.mode === Modes.EDIT ? "pages.post-editor.title-edit" : "pages.post-editor.title-create");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  let $$settled;
  let $$rendered;
  let previous_head = $$result.head;
  do {
    $$settled = true;
    $$result.head = previous_head;
    $$rendered = `<article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
      right: () => {
        return `<div slot="right">${data.mode === Modes.EDIT ? `<button class="btn btn-link text-danger" type="button" data-svelte-h="svelte-uvwztz"><i class="fas fa-trash"></i></button>` : ``} ${data.post.status !== StatusTypes.DRAFT && data.mode === Modes.EDIT ? `<button class="${["btn btn-link", ""].join(" ").trim()}" type="button" data-svelte-h="svelte-r4luig"><i class="fa-solid fa-box-archive"></i></button>` : ``} <a class="btn btn-link" role="button" target="_blank" href="${escape("", true) + "/preview/post/" + escape(data.post.id, true)}"><i class="fas fa-eye"></i></a> ${data.post.status !== StatusTypes.PUBLISHED ? `<button class="${[
          "btn btn-primary",
          isEditorEmpty || data.post.title.length === 0 ? "disabled" : ""
        ].join(" ").trim()}" type="button">${escape($_("pages.post-editor.save"))}</button>` : ``} <button class="${[
          "btn btn-secondary",
          isEditorEmpty || data.post.title.length === 0 ? "disabled" : ""
        ].join(" ").trim()}" type="button">${escape(data.post.status === StatusTypes.PUBLISHED ? $_("pages.post-editor.update") : $_("pages.post-editor.publish"))}</button></div>`;
      },
      middle: () => {
        return `${validate_component(CardMenu, "CardMenu").$$render($$result, { slot: "middle" }, {}, {
          default: () => {
            return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/posts" }, {}, {
              default: () => {
                return `${escape($_("pages.post-categories.posts"))}`;
              }
            })} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/posts/categories" }, {}, {
              default: () => {
                return `${escape($_("pages.posts.post-categories-button"))}`;
              }
            })}`;
          }
        })}`;
      }
    })}  <section class="row g-3 animate__animated animate__fadeIn"> <div class="col-lg-9"><div class="card h-100 w-100"><div class="card-body"><input class="form-control form-control-lg" type="text"${add_attribute("placeholder", $_("pages.post-editor.inputs.title.placeholder"), 0)}${add_attribute("value", data.post.title, 0)}> <div class="align-self-center w-100 h-75"> ${validate_component(Editor_1, "Editor").$$render(
      $$result,
      {
        content: data.post.text,
        isEmpty: isEditorEmpty
      },
      {
        content: ($$value) => {
          data.post.text = $$value;
          $$settled = false;
        },
        isEmpty: ($$value) => {
          isEditorEmpty = $$value;
          $$settled = false;
        }
      },
      {}
    )} </div></div></div></div>  <div class="col-lg-3"><div class="card"><div class="card-body"><ul class="list-group p-0 m-0"><li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape($_("pages.post-editor.status"))} <div>${escape($_(getStatusByPostStatus(data.post.status)))}</div></div></li> <li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape($_("pages.post-editor.views"))} <div>${escape(data.mode === Modes.CREATE ? "0" : data.post.views)}</div></div></li> <li class="list-group-item"><div class="d-flex justify-content-between align-items-center">${escape($_("pages.post-editor.category"))} <form><select class="form-control form-control-sm"><option class="text-primary"${add_attribute("value", -1, 0)}>${escape($_("pages.post-editor.no-category"))}</option>${each(data.categories, (category, index) => {
      return `<option${add_attribute("value", category.id, 0)}>${escape(category.title)}</option>`;
    })}</select></form></div></li> <li class="list-group-item form-group"><div class="d-flex justify-content-between align-items-center">${escape($_("pages.post-editor.thumbnail"))} ${data.post.thumbnailUrl ? `<button class="btn btn-link link-danger">${escape($_("pages.post-editor.clear"))}</button>` : `<button class="btn btn-sm btn-primary">${escape($_("pages.post-editor.add"))}</button>`}</div> ${data.post.thumbnailUrl ? `<a href="javascript:void(0);"><img${add_attribute("src", data.post.thumbnailUrl, 0)} class="border rounded img-fluid"${add_attribute("title", $_("pages.post-editor.small-image"), 0)}${add_attribute("alt", $_("pages.post-editor.small-image"), 0)}></a>` : `${validate_component(NoContent, "NoContent").$$render(
      $$result,
      {
        icon: "fas fa-image fa-3x",
        text: $_("pages.post-editor.thumbnail-not-determined")
      },
      {},
      {}
    )}`} <input class="d-none" type="file" id="uploadPostThumbnailInput"></li></ul></div></div></div></section></article> ${validate_component(AddEditPostCategoryModal, "AddEditPostCategoryModal").$$render($$result, {}, {}, {})}`;
  } while (!$$settled);
  $$unsubscribe__();
  return $$rendered;
});

export { Modes as M, PostEditor as P, load as l };
//# sourceMappingURL=PostEditor-DrHQmJrW.js.map
