import { g as get_store_value, c as create_ssr_component, a as subscribe, f as getContext, o as onDestroy, e as escape, h as each, v as validate_component, d as add_attribute } from './ssr-ffuobYCI.js';
import { b as ApiUtil } from './api.util-CD801QWb.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { l as locales } from './locale-gCQSfw7h.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';
import { N as NoContent } from './NoContent-Cd8O1sR9.js';
import { c as currentLanguage } from './language.util-2VlJt8zV.js';
import { f as formatDistanceToNow } from './formatDistanceToNow-wbEYwSfo.js';

const dialogID = "confirmDeleteAllNotifications";
const ConfirmRemoveAllNotificationsModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let loading;
  $$unsubscribe__();
  return `<div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-remove-all-notifications.title"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-remove-all-notifications.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-remove-all-notifications.yes"))}</button></div></div></div> </div>`;
});
const notifications = writable([]);
const count = writable(0);
Array.prototype.insert = function(index, item) {
  this.splice(index, 0, item);
  return this;
};
Array.prototype.remove = function(index) {
  this.splice(index, 1);
  return this;
};
function setNotifications(newNotifications) {
  if (get_store_value(notifications).length === 0 || newNotifications.length === 0) notifications.set(newNotifications);
  else {
    const listOfFilterIsNotificationExists = [];
    newNotifications.forEach((item, index) => {
      listOfFilterIsNotificationExists[index] = get_store_value(notifications).filter((filterItem) => filterItem.id === item.id);
    });
    newNotifications.forEach((item, index) => {
      if (listOfFilterIsNotificationExists[index].length === 0) {
        notifications.set(get_store_value(notifications).insert(index, item));
      }
    });
  }
}
async function load(event) {
  const { parent } = event;
  await parent();
  const body = await ApiUtil.get({
    path: "/api/panel/notifications",
    request: event
  });
  setNotifications(body.notifications);
  count.set(parseInt(body.notificationCount));
  return body;
}
let page = 0;
const Notifications = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $notifications, $$unsubscribe_notifications;
  let $_, $$unsubscribe__;
  let $currentLanguage, $$unsubscribe_currentLanguage;
  let $count, $$unsubscribe_count;
  $$unsubscribe_notifications = subscribe(notifications, (value) => $notifications = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_currentLanguage = subscribe(currentLanguage, (value) => $currentLanguage = value);
  $$unsubscribe_count = subscribe(count, (value) => $count = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.notifications.title");
  let checkTime = 0;
  let interval;
  function stopnotificationCountdown() {
    clearInterval(interval);
  }
  function getTime(check, time, locale) {
    return formatDistanceToNow(time, { addSuffix: true });
  }
  onDestroy(() => {
    stopnotificationCountdown();
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe_notifications();
  $$unsubscribe__();
  $$unsubscribe_currentLanguage();
  $$unsubscribe_count();
  return `<div class="container vstack gap-3"> <div class="row justify-content-end animate__animated animate__slideInUp">${$notifications.length !== 0 ? `<div class="col-auto"><button type="button" class="btn btn-danger">${escape($_("pages.notifications.delete-all"))}</button></div>` : ``}</div>  <div class="card"><div class="card-body"><div class="list-group list-group-flush">${each($notifications, (notification, index) => {
    return `<a href="javascript:void(0);" class="${[
      "list-group-item list-group-item-action text-wrap",
      notification.status === "NOT_READ" ? "notification-unread" : ""
    ].join(" ").trim()}">${escape(notification.type)} <br> <small class="text-muted">${escape(getTime(checkTime, parseInt(notification.date), locales[$currentLanguage["date-fns-code"]]))}</small> </a>`;
  })}</div> ${$notifications.length === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ``} ${$notifications.length < $count && $count > 10 + 10 * page ? `<div class="mt-3"><button class="${["btn btn-link bg-light d-block m-auto", ""].join(" ").trim()}">${escape($_("pages.notifications.show-more", {
    values: { count: $count - $notifications.length }
  }))}</button></div>` : ``}</div></div></div> ${validate_component(ConfirmRemoveAllNotificationsModal, "ConfirmRemoveAllNotificationsModal").$$render($$result, {}, {}, {})}`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 19;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-hmZxrKnE.js')).default;
const universal_id = "src/routes/notifications/+page.js";
const imports = ["_app/immutable/nodes/19.D-wjLhe8.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/api.util.Dg842-21.js","_app/immutable/chunks/stores.CsUY_SYv.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/ToastContainer.x2jPa-x4.js","_app/immutable/chunks/formatDistanceToNow.xoZqF94o.js","_app/immutable/chunks/differenceInSeconds.C8Wb6Etw.js","_app/immutable/chunks/NoContent.D2aAa_Bh.js","_app/immutable/chunks/language.util._YIcuF_L.js"];
const stylesheets = [];
const fonts = [];

var _19 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Notifications as N, _19 as _ };
//# sourceMappingURL=19-BF0VJG-r.js.map
