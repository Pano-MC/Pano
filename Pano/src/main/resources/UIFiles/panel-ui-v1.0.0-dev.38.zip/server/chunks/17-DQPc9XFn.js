import { l as load$1, P as PageTypes } from './Addons-BEH5V-MP.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-CD801QWb.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-D6cKqDaa.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardFilters-DAnWRWSC.js';
import './NoContent-Cd8O1sR9.js';

async function load(params) {
  return load$1(params, PageTypes.DISABLED);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 17;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-WQV_E50-.js')).default;
const universal_id = "src/routes/addons/disabled/+page.js";
const imports = ["_app/immutable/nodes/17.MG20kPTu.js","_app/immutable/chunks/Addons.DAu1zMLU.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.B389owzx.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/api.util.Dg842-21.js","_app/immutable/chunks/stores.CsUY_SYv.js","_app/immutable/chunks/tooltip.util.B9pXg_0U.js","_app/immutable/chunks/ToastContainer.x2jPa-x4.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardHeader.CjMNuYL-.js","_app/immutable/chunks/CardFilters.B36K2fXK.js","_app/immutable/chunks/ConfirmDisableAddonWillCauseMoreDisableModal.0U34tpBp.js","_app/immutable/chunks/NoContent.D2aAa_Bh.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=17-DQPc9XFn.js.map
