import { c as create_ssr_component, v as validate_component, a as subscribe, d as add_attribute, e as escape } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';

const dialogID$1 = "confirmCloseTicket";
const selectedTickets$1 = writable([]);
const ConfirmCloseTicketModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $selectedTickets, $$unsubscribe_selectedTickets;
  let $_, $$unsubscribe__;
  $$unsubscribe_selectedTickets = subscribe(selectedTickets$1, (value) => $selectedTickets = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let loading;
  $$unsubscribe_selectedTickets();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID$1, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($selectedTickets.length === 1 ? $_("components.modals.confirm-close-ticket.title-single") : $_("components.modals.confirm-close-ticket.title-multi"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" data-bs-dismiss="modal" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-close-ticket.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-close-ticket.yes"))}</button></div></div></div> </div>`;
});
const dialogID = "confirmDeleteTicket";
const selectedTickets = writable([]);
const ConfirmDeleteTicketModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $selectedTickets, $$unsubscribe_selectedTickets;
  let $_, $$unsubscribe__;
  $$unsubscribe_selectedTickets = subscribe(selectedTickets, (value) => $selectedTickets = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let loading;
  $$unsubscribe_selectedTickets();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($selectedTickets.length === 1 ? $_("components.modals.confirm-delete-ticket.title-single") : $_("components.modals.confirm-delete-ticket.title-multi"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-delete-ticket.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button"${add_attribute("aria-disabled", loading, 0)}>${escape($_("components.modals.confirm-delete-ticket.yes"))}</button></div></div></div> </div>`;
});
async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_TICKETS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const TicketsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``} ${validate_component(ConfirmCloseTicketModal, "ConfirmCloseTicketModal").$$render($$result, {}, {}, {})} ${validate_component(ConfirmDeleteTicketModal, "ConfirmDeleteTicketModal").$$render($$result, {}, {}, {})}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 10;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DIzRwsw7.js')).default;
const universal_id = "src/routes/tickets/+layout.js";
const imports = ["_app/immutable/nodes/10.QdjhUCDX.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.BsYBjEPW.js","_app/immutable/chunks/stores.CsUY_SYv.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/index.B389owzx.js","_app/immutable/chunks/ConfirmDeleteTicketModal.BPD3XrDp.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/api.util.Dg842-21.js","_app/immutable/chunks/ToastContainer.x2jPa-x4.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/TicketStatusBadge.D01KZIhI.js"];
const stylesheets = [];
const fonts = [];

var _10 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { TicketsLayout as T, _10 as _ };
//# sourceMappingURL=10-BUzKTjBi.js.map
