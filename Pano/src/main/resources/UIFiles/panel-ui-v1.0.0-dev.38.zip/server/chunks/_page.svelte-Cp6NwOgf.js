import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';

const ActivityLogs = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="container vstack gap-3" data-svelte-h="svelte-im3rm3"><div class="card"><div class="card-body">DATA</div></div></div>`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ActivityLogs, "ActivityLogs").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-Cp6NwOgf.js.map
