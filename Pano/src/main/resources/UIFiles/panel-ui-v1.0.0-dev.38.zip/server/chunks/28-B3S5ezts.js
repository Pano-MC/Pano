import { l as load$1, M as Modes } from './PostEditor-DrHQmJrW.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-CD801QWb.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ToastContainer-D6cKqDaa.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CNgXF1Vs.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';
import './paths-C6LjEmZF.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 28;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DhOXwGPs.js')).default;
const universal_id = "src/routes/posts/detail/[id]/+page.js";
const imports = ["_app/immutable/nodes/28.C8FAOgh7.js","_app/immutable/chunks/PostEditor.DGb5bgmK.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.B389owzx.js","_app/immutable/chunks/entry.BsJDkU6L.js","_app/immutable/chunks/paths.BsvhA4vX.js","_app/immutable/chunks/api.util.Dg842-21.js","_app/immutable/chunks/stores.CsUY_SYv.js","_app/immutable/chunks/runtime.ZnVrOd0C.js","_app/immutable/chunks/tooltip.util.B9pXg_0U.js","_app/immutable/chunks/ConfirmDeletePostModal.BOUc_30s.js","_app/immutable/chunks/ToastContainer.x2jPa-x4.js","_app/immutable/chunks/AddEditPostCategoryModal.XGHnBbDM.js","_app/immutable/chunks/Editor.BUgPx5Jz.js","_app/immutable/chunks/NoContent.D2aAa_Bh.js","_app/immutable/chunks/PageActions.C-NRwf0v.js","_app/immutable/chunks/CardMenuItem.CEBANiS9.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=28-B3S5ezts.js.map
