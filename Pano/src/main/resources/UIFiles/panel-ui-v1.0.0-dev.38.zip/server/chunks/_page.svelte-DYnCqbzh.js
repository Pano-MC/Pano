import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';

const ConfirmDeleteThemeModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return ` <div aria-hidden="true" class="modal fade" id="confirmDeleteTheme" role="dialog" tabindex="-1" data-svelte-h="svelte-i5847u"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div>
        Bu temayı kalıcı olarak silmek istediğinizden emin misiniz?</div> <div class="modal-footer"><button class="btn btn-link text-muted" data-bs-dismiss="modal" type="button">İptal</button> <button class="btn btn-danger" type="button">Evet</button></div></div></div></div>`;
});
const Themes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Temalar");
  return ` ${validate_component(ConfirmDeleteThemeModal, "ConfirmDeleteThemeModal").$$render($$result, {}, {}, {})}`;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(Themes, "Themes").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DYnCqbzh.js.map
