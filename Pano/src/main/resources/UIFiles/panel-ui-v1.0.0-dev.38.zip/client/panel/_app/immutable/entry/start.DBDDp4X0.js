import{b as a}from"../chunks/entry.BsJDkU6L.js";export{a as start};
