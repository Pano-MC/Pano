import{a as t}from"../chunks/entry.BzEQwkwN.js";export{t as start};
