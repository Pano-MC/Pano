import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import { P as PlayerRow } from './PlayerRow-Dn-RjN1r.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';

async function loadData({ page, permissionGroup, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/players?permissionGroup=${permissionGroup}&page=${parseInt(page)}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    playerCount: 0,
    players: [],
    totalPage: 1,
    page: 1,
    permissionGroup: {
      id: -1,
      name: event.params.permissionGroup
    }
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    permissionGroup: event.params.permissionGroup,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const PlayersByPermissionGroup = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set($_("pages.players-by-permission-group.title", {
    values: {
      permissionGroupName: data.permissionGroup.name === "-" ? $_("pages.players-by-permission-group.player") : data.permissionGroup.name
    }
  }));
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <div class="container"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players"}" slot="left"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.players-by-permission-group.players"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.players-by-permission-group.table-title", { values: { count: data.playerCount } }))}</h5>`;
    }
  })}  ${data.playerCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col"></th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players-by-permission-group.table.player"))}</th> <th class="align-middle text-nowrap table-primary" scope="col">${escape($_("pages.players-by-permission-group.table.permission-group"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players-by-permission-group.table.status"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players-by-permission-group.table.last-login"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players-by-permission-group.table.register-date"))}</th></tr></thead> <tbody>${each(data.players, (player, index) => {
    return `${validate_component(PlayerRow, "PlayerRow").$$render($$result, { player }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </div>`;
});

export { PlayersByPermissionGroup as P, load as l };
//# sourceMappingURL=PlayersByPermissionGroup-C3c9eWfp.js.map
