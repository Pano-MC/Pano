import { l as load } from './TicketCategories-Bb6SizMA.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-BcrTWKQe.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 60;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-v0d2Hzzn.js')).default;
const universal_id = "src/routes/tickets/categories/page/+page.js";
const imports = ["_app/immutable/nodes/60.Covf5Mr2.js","_app/immutable/chunks/TicketCategories.BKP6QM2f.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.DDzQTuOI.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/Store.BIVD_fLK.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/Pagination.CVYLEMsu.js","_app/immutable/chunks/Toast.DKtYi-jV.js","_app/immutable/chunks/NoContent.DGPybuky.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=60-C_qJ9oB9.js.map
