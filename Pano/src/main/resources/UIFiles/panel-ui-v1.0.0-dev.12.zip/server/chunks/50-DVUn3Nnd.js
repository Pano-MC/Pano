const index = 50;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BuatRS7s.js')).default;
const imports = ["_app/immutable/nodes/50.CNLVZwyz.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/ServerSettings.D4oSJSlP.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/Store.BIVD_fLK.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/Toast.DKtYi-jV.js","_app/immutable/chunks/each.BbucQ6WL.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=50-DVUn3Nnd.js.map
