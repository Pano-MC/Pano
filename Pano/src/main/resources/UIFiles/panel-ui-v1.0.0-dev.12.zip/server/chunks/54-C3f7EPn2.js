const index = 54;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-De0E4zMP.js')).default;
const imports = ["_app/immutable/nodes/54.BF8ojIwW.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/tooltip.util.VekvBMMm.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js","_app/immutable/chunks/CardFilters.BRT2jOz8.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/NoContent.DGPybuky.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=54-C3f7EPn2.js.map
