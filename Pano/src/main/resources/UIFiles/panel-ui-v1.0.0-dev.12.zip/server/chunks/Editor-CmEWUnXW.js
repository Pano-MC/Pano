import { c as create_ssr_component, a as subscribe, o as onDestroy, d as add_attribute } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './client-CnCRRyPd.js';

const Editor_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => value);
  let element;
  let { content = "" } = $$props;
  let { isEmpty = true } = $$props;
  onDestroy(() => {
  });
  if ($$props.content === void 0 && $$bindings.content && content !== void 0) $$bindings.content(content);
  if ($$props.isEmpty === void 0 && $$bindings.isEmpty && isEmpty !== void 0) $$bindings.isEmpty(isEmpty);
  $$unsubscribe__();
  return `${``}  <div class="bg-light rounded"${add_attribute("this", element, 0)}></div>`;
});

export { Editor_1 as E };
//# sourceMappingURL=Editor-CmEWUnXW.js.map
