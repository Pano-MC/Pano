import { w as writable } from './index2-Dyghn50Q.js';
import { i as init$1, r as registerLocaleLoader, w as waitLocale } from './runtime-DMBi37QM.js';
import { g as get_store_value } from './ssr-ffuobYCI.js';

const Languages = Object.freeze({
  EN_US: {
    locale: "en-US",
    file: () => import('./en-US-CMcMWvCM.js'),
    name: "English (US)",
    "date-fns-code": "en-US"
  },
  TR: {
    locale: "tr",
    file: () => import('./tr-CiDOUCZ4.js'),
    derivatives: ["tr-tr"],
    name: "Türkçe (TR)",
    "date-fns-code": "tr"
  }
});
const loadedLanguages = writable([]);
const currentLanguage = writable(null);
async function init(initialLocale) {
  const language = getLanguageByLocale(initialLocale);
  const languageToLoad = language || Languages.EN_US;
  await loadLanguage(languageToLoad);
  currentLanguage.set(languageToLoad);
  init$1({
    fallbackLocale: "en-US",
    initialLocale: languageToLoad.locale
  });
}
async function loadLanguage(language) {
  if (get_store_value(loadedLanguages).indexOf(language) !== -1) {
    return;
  }
  loadedLanguages.update((list) => {
    list.push(language);
    return list;
  });
  registerLocaleLoader(language.locale, language.file);
  await waitLocale(language.locale);
  if (language.derivatives) {
    for (const derivative of language.derivatives) {
      registerLocaleLoader(derivative, language.file);
      await waitLocale(language.locale);
    }
  }
}
function getLanguageByLocale(locale) {
  let foundLanguage = null;
  Object.keys(Languages).forEach((key) => {
    const language = Languages[key];
    if (language.locale === locale) {
      foundLanguage = language;
    }
  });
  return foundLanguage;
}

export { Languages as L, currentLanguage as c, init as i };
//# sourceMappingURL=language.util-DgXijOeV.js.map
