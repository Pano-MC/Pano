import { c as create_ssr_component, a as subscribe, d as add_attribute, e as escape, b as add_classes } from './ssr-ffuobYCI.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';

const dialogID = "postCategoriesAddEditCategory";
const mode = writable("create");
const category = writable({});
const errors = writable([]);
const AddEditPostCategoryModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let buttonDisabled;
  let $category, $$unsubscribe_category;
  let $mode, $$unsubscribe_mode;
  let $_, $$unsubscribe__;
  let $errors, $$unsubscribe_errors;
  $$unsubscribe_category = subscribe(category, (value) => $category = value);
  $$unsubscribe_mode = subscribe(mode, (value) => $mode = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_errors = subscribe(errors, (value) => $errors = value);
  buttonDisabled = !$category.title;
  $$unsubscribe_category();
  $$unsubscribe_mode();
  $$unsubscribe__();
  $$unsubscribe_errors();
  return ` <div class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape($mode === "create" ? $_("components.modals.add-edit-post-category.create-category") : $_("components.modals.add-edit-post-category.edit-category"))}</h5> <button${add_attribute("title", $_("components.modals.add-edit-post-category.close"), 0)} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><input class="${["form-control form-control-lg mb-3", $errors.title ? "border-danger" : ""].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.add-edit-post-category.inputs.title.placeholder"), 0)} id="category" type="text"${add_attribute("value", $category.title, 0)}> <textarea class="${["form-control mb-3", $errors.description ? "border-danger" : ""].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.add-edit-post-category.inputs.description.placeholder"), 0)} id="categoryDescription" type="text" rows="5">${escape($category.description || "")}</textarea> <div class="mb-3 input-group"><span class="input-group-text" data-svelte-h="svelte-1ylwm05">/category/</span> <input class="${["form-control", $errors.url ? "is-invalid" : ""].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.add-edit-post-category.inputs.url.placeholder"), 0)} id="categoryURL" type="text"${add_attribute("value", $category.url, 0)}></div> <small${add_classes(($errors.url ? "text-danger" : "").trim())}>${escape($_("components.modals.add-edit-post-category.inputs.url.helper"))}</small></div> <div class="modal-footer"><button class="${[
    "btn w-100",
    ($mode === "create" ? "btn-secondary" : "") + " " + ($mode === "edit" ? "btn-primary" : "") + " " + (buttonDisabled ? "disabled" : "")
  ].join(" ").trim()}" type="submit"><span>${$mode === "edit" ? `${escape($_("components.modals.add-edit-post-category.save"))}` : `${escape($_("components.modals.add-edit-post-category.create"))}`}</span></button></div></form></div></div> </div>`;
});

export { AddEditPostCategoryModal as A };
//# sourceMappingURL=AddEditPostCategoryModal-BamjU8eK.js.map
