import { c as create_ssr_component, a as subscribe, f as getContext, o as onDestroy, v as validate_component, e as escape, h as each } from './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { e as error } from './index-DzcLzHBX.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import { P as PlayerRow } from './PlayerRow-Dn-RjN1r.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-C1uMKg14.js';

const PageTypes = Object.freeze({
  ALL: "all",
  HAS_PERM: "hasPerm",
  BANNED: "banned"
});
const DefaultPageType = PageTypes.ALL;
async function loadData({ page, pageType, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/players?page=${page}&status=${pageType}`,
      body: { page: parseInt(page) },
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        data.pageType = pageType;
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event, pageType = DefaultPageType) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    playerCount: 0,
    players: [],
    totalPage: 1,
    page: 1,
    pageType
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    pageType,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const Players = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  let checkTime = 0;
  let interval;
  const pageTitle = getContext("pageTitle");
  onDestroy(() => {
    clearInterval(interval);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set($_("pages.players.title", {
        values: {
          pageType: data.pageType === PageTypes.HAS_PERM ? $_("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? $_("pages.players.banned") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe__();
  return ` <div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    left: () => {
      return `<div slot="left">${hasPermission(Permissions.MANAGE_PERMISSION_GROUPS) ? `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players/perm-groups"}"><i class="fas fa-user-circle me-2"></i> ${escape($_("pages.players.perm-groups"))}</a>` : ``}</div>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players/all",
              active: data.pageType === PageTypes.ALL
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.all"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players/hasPerm",
              active: data.pageType === PageTypes.HAS_PERM
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.authorized"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/players/banned",
              active: data.pageType === PageTypes.BANNED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.players.banned"))}`;
              }
            }
          )}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.players.table-title", {
        values: {
          playerCount: data.playerCount,
          pageType: data.pageType === PageTypes.HAS_PERM ? $_("pages.players.authorized") + " " : data.pageType === PageTypes.BANNED ? $_("pages.players.banned") + " " : ""
        }
      }))}</h5>`;
    }
  })}  ${data.playerCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col"></th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.name"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.permission"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.status"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.last-entrance"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.players.table.register-date"))}</th></tr></thead> <tbody>${each(data.players, (player, index) => {
    return `${validate_component(PlayerRow, "PlayerRow").$$render($$result, { player, checkTime }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </div>`;
});

export { PageTypes as P, Players as a, load as l };
//# sourceMappingURL=Players-VlH10sWj.js.map
