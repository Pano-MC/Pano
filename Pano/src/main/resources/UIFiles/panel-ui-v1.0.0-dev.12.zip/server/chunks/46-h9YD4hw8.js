import { c as create_ssr_component, a as subscribe, f as getContext, o as onDestroy, e as escape, v as validate_component } from './ssr-ffuobYCI.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { D as Date_1 } from './Date-BK0ZOKAA.js';
import { a as addMonths, b as addDays, d as differenceInYears, c as differenceInDays, e as differenceInHours, f as differenceInMinutes } from './differenceInYears-DblCvIx9.js';
import { t as toDate, c as constructFrom } from './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import { a as differenceInMonths, d as differenceInSeconds } from './differenceInSeconds-C8IiJITI.js';
import { d as differenceInCalendarDays } from './format-DZNhO2Yc.js';

/**
 * @name add
 * @category Common Helpers
 * @summary Add the specified years, months, weeks, days, hours, minutes and seconds to the given date.
 *
 * @description
 * Add the specified years, months, weeks, days, hours, minutes and seconds to the given date.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 *
 * @param date - The date to be changed
 * @param duration - The object with years, months, weeks, days, hours, minutes and seconds to be added.
 *
 * | Key            | Description                        |
 * |----------------|------------------------------------|
 * | years          | Amount of years to be added        |
 * | months         | Amount of months to be added       |
 * | weeks          | Amount of weeks to be added        |
 * | days           | Amount of days to be added         |
 * | hours          | Amount of hours to be added        |
 * | minutes        | Amount of minutes to be added      |
 * | seconds        | Amount of seconds to be added      |
 *
 * All values default to 0
 *
 * @returns The new date with the seconds added
 *
 * @example
 * // Add the following duration to 1 September 2014, 10:19:50
 * const result = add(new Date(2014, 8, 1, 10, 19, 50), {
 *   years: 2,
 *   months: 9,
 *   weeks: 1,
 *   days: 7,
 *   hours: 5,\\-7
 *   minutes: 9,
 *   seconds: 30,
 * })
 * //=> Thu Jun 15 2017 15:29:20
 */
function add(date, duration) {
  const {
    years = 0,
    months = 0,
    weeks = 0,
    days = 0,
    hours = 0,
    minutes = 0,
    seconds = 0,
  } = duration;

  // Add years and months
  const _date = toDate(date);
  const dateWithMonths =
    months || years ? addMonths(_date, months + years * 12) : _date;

  // Add weeks and days
  const dateWithDays =
    days || weeks ? addDays(dateWithMonths, days + weeks * 7) : dateWithMonths;

  // Add days, hours, minutes and seconds
  const minutesToAdd = minutes + hours * 60;
  const secondsToAdd = seconds + minutesToAdd * 60;
  const msToAdd = secondsToAdd * 1000;
  const finalDate = constructFrom(date, dateWithDays.getTime() + msToAdd);

  return finalDate;
}

/**
 * @name intervalToDuration
 * @category Common Helpers
 * @summary Convert interval to duration
 *
 * @description
 * Convert a interval object to a duration object.
 *
 * @typeParam DateType - The `Date` type, the function operates on. Gets inferred from passed arguments. Allows to use extensions like [`UTCDate`](https://github.com/date-fns/utc).
 *
 * @param interval - The interval to convert to duration
 *
 * @returns The duration object
 *
 * @example
 * // Get the duration between January 15, 1929 and April 4, 1968.
 * intervalToDuration({
 *   start: new Date(1929, 0, 15, 12, 0, 0),
 *   end: new Date(1968, 3, 4, 19, 5, 0)
 * })
 * // => { years: 39, months: 2, days: 20, hours: 7, minutes: 5, seconds: 0 }
 */
function intervalToDuration(interval) {
  const start = toDate(interval.start);
  const end = toDate(interval.end);

  const duration = {};

  const years = differenceInYears(end, start);
  if (years) duration.years = years;

  const remainingMonths = add(start, { years: duration.years });

  const months = differenceInMonths(end, remainingMonths);
  if (months) duration.months = months;

  const remainingDays = add(remainingMonths, { months: duration.months });

  const days = differenceInDays(end, remainingDays);
  if (days) duration.days = days;

  const remainingHours = add(remainingDays, { days: duration.days });

  const hours = differenceInHours(end, remainingHours);
  if (hours) duration.hours = hours;

  const remainingMinutes = add(remainingHours, { hours: duration.hours });

  const minutes = differenceInMinutes(end, remainingMinutes);
  if (minutes) duration.minutes = minutes;

  const remainingSeconds = add(remainingMinutes, { minutes: duration.minutes });

  const seconds = differenceInSeconds(end, remainingSeconds);
  if (seconds) duration.seconds = seconds;

  return duration;
}

const ServerStatus = Object.freeze({ ONLINE: "ONLINE", OFFLINE: "OFFLINE" });
async function loadData({ request, selectedServer }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/servers/${selectedServer.id}/dashboard`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  const { selectedServer } = parentData;
  let data = { server: {}, connectedServerCount: 0 };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({ request: event, selectedServer }).then((body) => {
    data = { ...data, ...body };
  });
  return data;
}
const ServerDashboard = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.server.dashboard.title");
  let { data } = $$props;
  let interval;
  function getUptime(time, checkTime) {
    const now = /* @__PURE__ */ new Date();
    const duration = intervalToDuration({ start: time, end: now });
    const days = differenceInCalendarDays(time, now);
    const hours = duration["hours"];
    const minutes = duration["minutes"];
    const seconds = duration["seconds"];
    return `${days}:${hours}:${minutes}:${seconds}`;
  }
  onDestroy(() => {
    clearInterval(interval);
  });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return `<div class="container"><div class="row justify-content-between mb-3 animate__animated animate__slideInUp"><div class="col-4"><div class="${[
    "card bg-opacity-25",
    (data.server.status === ServerStatus.ONLINE ? "bg-success" : "") + " " + (data.server.status === ServerStatus.OFFLINE ? "bg-danger" : "")
  ].join(" ").trim()}"><div class="card-body"><p class="${[
    "mb-0",
    (data.server.status === ServerStatus.ONLINE ? "text-success" : "") + " " + (data.server.status === ServerStatus.OFFLINE ? "text-danger" : "")
  ].join(" ").trim()}">${escape($_("pages.server.dashboard.server-status", {
    values: {
      status: data.server.status === ServerStatus.ONLINE ? $_("pages.server.dashboard.online") : $_("pages.server.dashboard.offline")
    }
  }))}</p></div></div></div> <div class="col-4"><div class="card bg-primary bg-opacity-25"><div class="card-body"><p class="mb-0 text-primary">${escape($_("pages.server.dashboard.player", {
    values: {
      playerCount: data.server.playerCount,
      maxPlayerCount: data.server.maxPlayerCount
    }
  }))}</p></div></div></div> <div class="col-4"><div class="card"><div class="card-body"><p class="mb-0 text-dark">${data.server.status === ServerStatus.ONLINE ? `${escape($_("pages.server.dashboard.player", {
    values: {
      upTime: getUptime(data.server.startTime)
    }
  }))}` : `${escape($_("pages.server.dashboard.last-online"))} ${validate_component(Date_1, "DateComponent").$$render($$result, { time: data.server.stopTime }, {}, {})}`}</p></div></div></div></div>  <div class="card"><div class="card-body"><h5 class="card-title">${escape($_("pages.server.dashboard.statistics"))}</h5> <div class="table-responsive"><table class="table table-hover m-0"><tbody class="text-muted"><tr><th scope="row">${escape($_("pages.server.dashboard.server-name"))}</th> <td>${escape(data.server.name)}</td></tr> <tr><th scope="row">${escape($_("pages.server.dashboard.server-type"))}</th> <td>${escape(data.server.type)}</td></tr> <tr><th scope="row">${escape($_("pages.server.dashboard.local-ip-address"))}</th> <td>${escape(data.server.host)}:${escape(data.server.port)}</td></tr> <tr><th scope="row">${escape($_("pages.server.dashboard.server-version"))}</th> <td>${escape(data.server.version)}</td></tr> <tr><th scope="row">${escape($_("pages.server.dashboard.total-connected-servers"))}</th> <td>${escape(data.connectedServerCount)}</td></tr> <tr><th scope="row">${escape($_("pages.server.dashboard.date-added"))}</th> <td>${validate_component(Date_1, "DateComponent").$$render($$result, { time: data.server.acceptedTime }, {}, {})}</td></tr></tbody></table></div></div></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 46;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CfSnvoLS.js')).default;
const universal_id = "src/routes/server/dashboard/+page.js";
const imports = ["_app/immutable/nodes/46.DiDdtozs.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/Date.Cdl1BN1I.js","_app/immutable/chunks/locale.CymR1DFj.js","_app/immutable/chunks/en-US.CN304kjH.js","_app/immutable/chunks/tooltip.util.VekvBMMm.js","_app/immutable/chunks/language.util.B3WjgmaS.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/format.CFOniNCu.js","_app/immutable/chunks/differenceInYears.CinWb3iI.js","_app/immutable/chunks/differenceInSeconds.C8Wb6Etw.js"];
const stylesheets = [];
const fonts = [];

var _46 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ServerDashboard as S, _46 as _ };
//# sourceMappingURL=46-h9YD4hw8.js.map
