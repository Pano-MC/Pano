import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as TicketDetail } from './65-Cl1ugTyp.js';
import './index-DzcLzHBX.js';
import './Editor-CmEWUnXW.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './TicketStatusBadge-zPZI-o9b.js';
import './paths-C6LjEmZF.js';
import './api.util-BcrTWKQe.js';
import './ToastContainer-CKzXwJro.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(TicketDetail, "TicketDetail").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DJB3rMiY.js.map
