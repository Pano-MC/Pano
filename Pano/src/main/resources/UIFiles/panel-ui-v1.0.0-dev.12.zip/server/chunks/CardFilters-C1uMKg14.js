import { c as create_ssr_component, d as add_attribute } from './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import { b as base } from './paths-C6LjEmZF.js';
import './runtime-DMBi37QM.js';

const CardFiltersItem = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { href } = $$props;
  let { active } = $$props;
  if ($$props.href === void 0 && $$bindings.href && href !== void 0) $$bindings.href(href);
  if ($$props.active === void 0 && $$bindings.active && active !== void 0) $$bindings.active(active);
  return `<a class="${["btn btn-sm btn-outline-primary text-truncate", active ? "active" : ""].join(" ").trim()}" role="button"${add_attribute("href", base + href, 0)}>${slots.default ? slots.default({}) : ``} </a>`;
});
const CardFilters = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="btn-group col-sm-auto col">${slots.default ? slots.default({}) : ``}</div>`;
});

export { CardFilters as C, CardFiltersItem as a };
//# sourceMappingURL=CardFilters-C1uMKg14.js.map
