import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, d as add_attribute, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { w as writable } from './index2-Dyghn50Q.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import { T as TicketRow } from './TicketRow-CvSni0kK.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';
import { C as CardFilters, a as CardFiltersItem } from './CardFilters-C1uMKg14.js';

let checkedList = writable([]);
const PageTypes = Object.freeze({
  ALL: "ALL",
  WAITING_REPLY: "WAITING_REPLY",
  CLOSED: "CLOSED"
});
const DefaultPageType = PageTypes.ALL;
async function loadData({ page, pageType, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/tickets?pageType=${pageType.toUpperCase()}&page=${parseInt(page)}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        data.pageType = pageType;
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event, pageType = DefaultPageType) {
  const { parent } = event;
  const parentData = await parent();
  pageType = pageType.toUpperCase();
  let data = {
    ticketCount: 0,
    tickets: [],
    totalPage: 1,
    page: 1,
    pageType
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    pageType,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
function isAllTicketsSelected(ticketsList, selectedList) {
  let isAllSelected = true;
  ticketsList.forEach((ticket) => {
    if (!selectedList[ticket.id]) isAllSelected = false;
  });
  return isAllSelected;
}
const Tickets = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $checkedList, $$unsubscribe_checkedList;
  let $_, $$unsubscribe__;
  $$unsubscribe_checkedList = subscribe(checkedList, (value) => $checkedList = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  let firstLoad = true;
  function getListOfChecked(list) {
    const result = Object.keys(list).filter((key) => list[key]);
    if (result.length > 0) firstLoad = false;
    return result;
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set($_("pages.tickets.title", {
        values: {
          pageType: data.pageType === PageTypes.WAITING_REPLY ? $_("pages.tickets.waiting-reply") + " " : data.pageType === PageTypes.CLOSED ? $_("pages.tickets.closed") + " " : ""
        }
      }));
    }
  }
  $$unsubscribe_checkedList();
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div class="${[
        "animate__animated animate__faster " + escape(
          getListOfChecked($checkedList).length > 0 ? "animate__slideInUp" : "animate__slideOutDown",
          true
        ) + " faster",
        firstLoad ? "d-none" : ""
      ].join(" ").trim()}" slot="right"><a class="${[
        "btn btn-link link-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" role="button" href="javascript:void(0);" data-svelte-h="svelte-1warjef"><i class="fas fa-trash"></i></a> <a class="${[
        "btn btn-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" role="button" href="javascript:void(0);"><i class="fas fa-times me-2"></i> ${escape($_("pages.tickets.close-ticket-button"))}</a></div>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/tickets/categories"}" slot="left"><i class="fas fa-list-alt me-2"></i> ${escape($_("pages.tickets.ticket-categories"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    right: () => {
      return `${validate_component(CardFilters, "CardFilters").$$render($$result, { slot: "right" }, {}, {
        default: () => {
          return `${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets/all",
              active: data.pageType === PageTypes.ALL
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.all"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets/waitingReply",
              active: data.pageType === PageTypes.WAITING_REPLY
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.waiting-reply"))}`;
              }
            }
          )} ${validate_component(CardFiltersItem, "CardFiltersItem").$$render(
            $$result,
            {
              href: "/tickets/closed",
              active: data.pageType === PageTypes.CLOSED
            },
            {},
            {
              default: () => {
                return `${escape($_("pages.tickets.closed"))}`;
              }
            }
          )}`;
        }
      })}`;
    },
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.tickets.table-title", {
        values: {
          ticketCount: data.ticketCount,
          pageType: data.pageType === PageTypes.WAITING_REPLY ? $_("pages.tickets.waiting-reply") : data.pageType === PageTypes.CLOSED ? $_("pages.tickets.closed") : ""
        }
      }) + (getListOfChecked($checkedList).length > 0 ? ", " + $_("pages.tickets.amount-selected", {
        values: {
          amount: getListOfChecked($checkedList).length
        }
      }) : ""))}</h5>`;
    }
  })}  ${data.ticketCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle" scope="col"><div class="form-check"><input${add_attribute("title", $_("pages.tickets.select-all"), 0)} class="form-check-input" ${isAllTicketsSelected(data.tickets, $checkedList) ? "checked" : ""} id="selectAll" type="checkbox"></div></th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.title"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.category"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.player"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.status"))}</th> <th class="align-middle" scope="col">${escape($_("pages.tickets.table.last-reply"))}</th></tr></thead> <tbody>${each(data.tickets, (ticket, index) => {
    return `${validate_component(TicketRow, "TicketRow").$$render($$result, { ticket, checkedList }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </article>`;
});

export { PageTypes as P, Tickets as T, load as l };
//# sourceMappingURL=Tickets-CWoZi-3Y.js.map
