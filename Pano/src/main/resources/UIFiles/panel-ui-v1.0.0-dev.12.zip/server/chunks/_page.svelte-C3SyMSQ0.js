import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PostEditor } from './PostEditor-kYO6YYnl.js';
import './index-DzcLzHBX.js';
import './api.util-BcrTWKQe.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CmEWUnXW.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(PostEditor, "PostEditor").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-C3SyMSQ0.js.map
