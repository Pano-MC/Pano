import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each, d as add_attribute, i as createEventDispatcher, b as add_classes } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';

const dialogID = "permissionGroupDeleteConfirmationModal";
const permissionGroup = writable({
  id: -1,
  name: "",
  users: [],
  userCount: 0
});
const ConfirmDeletePermissionGroupModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  let $permissionGroup, $$unsubscribe_permissionGroup;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_permissionGroup = subscribe(permissionGroup, (value) => $permissionGroup = value);
  $$unsubscribe__();
  $$unsubscribe_permissionGroup();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($_("components.modals.confirm-delete-permission-group.title"))} ${$permissionGroup.userCount > 0 ? `<div class="mt-3 alert alert-warning">${escape($_("components.modals.confirm-delete-permission-group.description"))} <br> <br> <span class="badge bg-warning rounded-pill mr-1">${escape($permissionGroup.name)}</span> <div class="d-flex flex-row flex-row-reverse justify-content-center align-items-center mt-3 mr-3">${$permissionGroup.userCount > 3 ? `<small class="pl-1">+${escape($permissionGroup.userCount - 3)}</small>` : ``} ${each($permissionGroup.users, (user, index) => {
    return `<span class="overlapping-avatar"><a href="${escape(base, true) + "/players/player/" + escape(user, true)}"><img src="${"https://minotar.net/avatar/" + escape(user, true)}" width="32" height="32"${add_attribute("alt", user, 0)}></a> </span>`;
  })}</div></div>` : ``}</div> <div class="modal-footer"><button class="${["btn btn-link text-muted", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-permission-group.cancel"))}</button> <button class="${["btn btn-danger", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-permission-group.yes"))}</button></div></div></div> </div>`;
});
const PermissionGroupRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { permissionGroup: permissionGroup2 } = $$props;
  createEventDispatcher();
  if ($$props.permissionGroup === void 0 && $$bindings.permissionGroup && permissionGroup2 !== void 0) $$bindings.permissionGroup(permissionGroup2);
  $$unsubscribe__();
  return `<tr${add_classes((permissionGroup2.selected ? "table-primary" : "").trim())}><th scope="row" class="align-middle">${permissionGroup2.name !== "admin" ? `<a class="btn btn-sm btn-link link-danger" href="javascript:void(0);"${add_attribute("title", $_("components.permission-group-row.delete"), 0)}><i class="fas fa-trash"></i></a>` : ``}</th> <td class="align-middle text-nowrap"><a${add_attribute("title", $_("components.permission-group-row.edit"), 0)} href="${escape(base, true) + "/players/perm-groups/detail/" + escape(permissionGroup2.id, true)}">${escape(permissionGroup2.name)}</a></td> <td class="align-middle text-nowrap">${permissionGroup2.name === "tayyip" || permissionGroup2.name === "admin" ? ` <i class="fas fa-infinity"></i> ` : `${escape(permissionGroup2.permissionCount)}`}</td> <td class="align-middle text-nowrap">${escape(permissionGroup2.userCount)}</td> </tr>`;
});
async function loadData({ request, page }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/permissionGroups?page=${page}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        body.page = parseInt(page);
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    permissions: [],
    permissionGroups: [],
    permissionGroupCount: 0,
    permissionGroupPerms: {},
    totalPage: 1,
    page: 1
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    request: event,
    page: event.params.page || 1
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const PermissionGroups = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.permission-groups.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <div class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<a href="${escape(base, true) + "/players/perm-groups/create"}" class="btn btn-secondary" slot="right"><i class="fas fa-plus me-2"></i> ${escape($_("pages.permission-groups.create-permission-group-button"))}</a>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/players"}" slot="left"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.permission-groups.players"))}</a>`;
    }
  })} <div class="card"><div class="card-body"> ${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.permission-groups.card-title", {
        values: { count: data.permissionGroupCount }
      }))}</h5>`;
    }
  })} <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="align-middle text-nowrap" scope="col"></th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.permission-groups.name"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.permission-groups.permission-amount"))}</th> <th class="align-middle text-nowrap" scope="col">${escape($_("pages.permission-groups.player-amount"))}</th></tr></thead> <tbody>${each(data.permissionGroups, (permissionGroup2, index) => {
    return `${validate_component(PermissionGroupRow, "PermissionGroupRow").$$render($$result, { permissionGroup: permissionGroup2 }, {}, {})}`;
  })}</tbody></table>  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )} </div></div></div></div> ${validate_component(ConfirmDeletePermissionGroupModal, "ConfirmDeletePermissionGroupModal").$$render($$result, {}, {}, {})}`;
});

export { PermissionGroups as P, load as l };
//# sourceMappingURL=PermissionGroups-oDvdctyw.js.map
