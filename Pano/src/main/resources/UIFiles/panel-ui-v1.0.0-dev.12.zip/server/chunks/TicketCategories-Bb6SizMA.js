import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each, d as add_attribute, i as createEventDispatcher, b as add_classes } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import { w as writable } from './index2-Dyghn50Q.js';
import './ToastContainer-CKzXwJro.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';

const dialogID$1 = "addEditTicketCategory";
const mode = writable("create");
const category$1 = writable({});
const errors = writable([]);
const AddEditTicketCategoryModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let buttonDisabled;
  let $category, $$unsubscribe_category;
  let $mode, $$unsubscribe_mode;
  let $_, $$unsubscribe__;
  let $errors, $$unsubscribe_errors;
  $$unsubscribe_category = subscribe(category$1, (value) => $category = value);
  $$unsubscribe_mode = subscribe(mode, (value) => $mode = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_errors = subscribe(errors, (value) => $errors = value);
  buttonDisabled = !$category.title;
  $$unsubscribe_category();
  $$unsubscribe_mode();
  $$unsubscribe__();
  $$unsubscribe_errors();
  return ` <div class="modal fade"${add_attribute("id", dialogID$1, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escape($mode === "edit" ? $_("components.modals.add-edit-ticket-category.edit-category") : $_("components.modals.add-edit-ticket-category.create-category"))}</h5> <button${add_attribute("title", $_("components.modals.add-edit-ticket-category.close"), 0)} type="button" class="btn-close" data-bs-dismiss="modal"></button></div> <form><div class="modal-body"><input class="${["form-control form-control-lg mb-3", $errors.title ? "border-danger" : ""].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.add-edit-ticket-category.inputs.title.placeholder"), 0)} id="category" type="text"${add_attribute("value", $category.title, 0)}> <textarea class="${["form-control", $errors.description ? "border-danger" : ""].join(" ").trim()}"${add_attribute("placeholder", $_("components.modals.add-edit-ticket-category.inputs.description.placeholder"), 0)} id="categoryDescription" type="text" rows="5">${escape($category.description || "")}</textarea></div> <div class="modal-footer"><button class="${[
    "btn w-100",
    ($mode === "create" ? "btn-secondary" : "") + " " + ($mode === "edit" ? "btn-primary" : "") + " " + (buttonDisabled ? "disabled" : "")
  ].join(" ").trim()}" type="submit">${escape($mode === "edit" ? $_("components.modals.add-edit-ticket-category.save") : $_("components.modals.add-edit-ticket-category.create"))}</button></div></form></div></div> </div>`;
});
const dialogID = "confirmDeleteTicketCategory";
const category = writable({ tickets: [] });
const ConfirmDeleteTicketCategoryModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $category, $$unsubscribe_category;
  let $_, $$unsubscribe__;
  $$unsubscribe_category = subscribe(category, (value) => $category = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_category();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-se9wy3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${$category.ticketCount !== 0 ? `${escape($_("components.modals.confirm-delete-ticket-category.title-permanent"))} <br> <br> ${each($category.tickets, (ticket, index) => {
    return `<a href="${escape(base, true) + "/tickets/ticket/" + escape(ticket.id, true)}" target="_blank">${escape(ticket.title)}</a> <br>`;
  })} ${$category.ticketCount > 5 ? `${escape($_("components.modals.confirm-delete-ticket-category.more-tickets", {
    values: { count: $category.ticketCount - 5 }
  }))}` : ``} <br>` : ``} ${escape($_("components.modals.confirm-delete-ticket-category.title"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-ticket-category.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-ticket-category.yes"))}</button></div></div></div> </div>`;
});
const TicketCategoryRow = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { category: category2 } = $$props;
  let { index } = $$props;
  createEventDispatcher();
  if ($$props.category === void 0 && $$bindings.category && category2 !== void 0) $$bindings.category(category2);
  if ($$props.index === void 0 && $$bindings.index && index !== void 0) $$bindings.index(index);
  $$unsubscribe__();
  return `<tr${add_classes((category2.selected ? "table-primary" : "").trim())}><th scope="row" class="align-middle"><a${add_attribute("title", $_("components.ticket-category-row.delete"), 0)} class="btn btn-sm btn-link link-danger" href="javascript:void(0);"><i class="fas fa-trash"></i></a></th> <td class="text-nowrap align-middle"><a href="javascript:void(0);"${add_attribute("title", $_("components.ticket-category-row.edit"), 0)}>${escape(category2.title)}</a></td> <td class="text-nowrap align-middle">${escape(category2.description)}</td> </tr>`;
});
async function loadData({ page, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/ticket/categories?page=${page}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    categoryCount: 0,
    categories: [],
    totalPage: 1,
    page: 1
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
const TicketCategories = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  pageTitle.set("pages.ticket-categories.title");
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  $$unsubscribe__();
  return ` <article class="container vstack gap-3"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<button class="btn btn-secondary" type="button" slot="right"><i class="fas fa-plus me-2"></i>${escape($_("pages.ticket-categories.create-category-button"))}</button>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/tickets"}" slot="left"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.ticket-categories.tickets"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title" slot="left">${escape($_("pages.ticket-categories.card-title", { values: { count: data.categoryCount } }))}</h5>`;
    }
  })}  ${data.categoryCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ``}  ${data.categoryCount > 0 ? `<div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th scope="col"></th> <th class="align-middle" scope="col">${escape($_("pages.ticket-categories.category"))}</th> <th scope="col" class="align-middle">${escape($_("pages.ticket-categories.description"))}</th></tr></thead> <tbody>${each(data.categories, (category2, index) => {
    return `${validate_component(TicketCategoryRow, "TicketCategoryRow").$$render($$result, { category: category2, index }, {}, {})}`;
  })}</tbody></table></div>` : ``}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div></article>  ${validate_component(AddEditTicketCategoryModal, "AddEditTicketCategoryModal").$$render($$result, {}, {}, {})}  ${validate_component(ConfirmDeleteTicketCategoryModal, "ConfirmDeleteTicketCategoryModal").$$render($$result, {}, {}, {})}`;
});

export { TicketCategories as T, load as l };
//# sourceMappingURL=TicketCategories-Bb6SizMA.js.map
