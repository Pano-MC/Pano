const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-kTRfs0_B.js')).default;
const imports = ["_app/immutable/nodes/1.BrY_Zgxc.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/stores.7JWkmOFC.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-BsFLO_Zf.js.map
