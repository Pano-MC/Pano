import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PlatformSettings } from './53-BKSWfbPK.js';
import './api.util-BcrTWKQe.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './paths-C6LjEmZF.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './stores-BDx4Az-R.js';
import './ToastContainer-CKzXwJro.js';
import './language.util-DgXijOeV.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(PlatformSettings, "PlatformSettings").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-CV5Uq5bn.js.map
