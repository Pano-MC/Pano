import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { P as PermissionGroups } from './PermissionGroups-oDvdctyw.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-BcrTWKQe.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(PermissionGroups, "PermissionGroups").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-CJuSr2zf.js.map
