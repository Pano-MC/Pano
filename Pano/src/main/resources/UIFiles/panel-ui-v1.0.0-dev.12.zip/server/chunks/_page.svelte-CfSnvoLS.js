import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { S as ServerDashboard } from './46-h9YD4hw8.js';
import './api.util-BcrTWKQe.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-BK0ZOKAA.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-DgXijOeV.js';
import './format-DZNhO2Yc.js';
import './differenceInYears-DblCvIx9.js';
import './differenceInSeconds-C8IiJITI.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(ServerDashboard, "ServerDashboard").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-CfSnvoLS.js.map
