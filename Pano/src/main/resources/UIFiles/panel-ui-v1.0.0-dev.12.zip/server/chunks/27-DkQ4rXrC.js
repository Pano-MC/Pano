import { l as load } from './PermissionGroups-oDvdctyw.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './api.util-BcrTWKQe.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination-DWomX__u.js';
import './PageActions-CTFh4m8T.js';
import './CardHeader-DPJD8jKc.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 27;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CJuSr2zf.js')).default;
const universal_id = "src/routes/players/perm-groups/+page.js";
const imports = ["_app/immutable/nodes/27.CMMZ20r-.js","_app/immutable/chunks/PermissionGroups._KFctc_z.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.DDzQTuOI.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/Store.BIVD_fLK.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/tooltip.util.VekvBMMm.js","_app/immutable/chunks/Pagination.CVYLEMsu.js","_app/immutable/chunks/PageActions.aH27r9KG.js","_app/immutable/chunks/CardHeader.DalnAcEs.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=27-DkQ4rXrC.js.map
