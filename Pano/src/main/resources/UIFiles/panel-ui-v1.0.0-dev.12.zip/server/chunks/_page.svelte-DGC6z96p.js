import { c as create_ssr_component, v as validate_component, f as getContext } from './ssr-ffuobYCI.js';

const ThemeOptions = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const pageTitle = getContext("pageTitle");
  pageTitle.set("Tema Ayarları");
  return ``;
});
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ThemeOptions, "ThemeOptions").$$render($$result, {}, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DGC6z96p.js.map
