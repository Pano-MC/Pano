import { c as create_ssr_component, a as subscribe, f as getContext, v as validate_component, e as escape, h as each } from './ssr-ffuobYCI.js';
import { e as error } from './index-DzcLzHBX.js';
import { w as writable } from './index2-Dyghn50Q.js';
import './client-CnCRRyPd.js';
import { b as ApiUtil } from './api.util-BcrTWKQe.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { P as Pagination } from './Pagination-DWomX__u.js';
import './ToastContainer-CKzXwJro.js';
import { T as TicketRow } from './TicketRow-CvSni0kK.js';
import { N as NoContent } from './NoContent-N-qOzDdv.js';
import { P as PageActions } from './PageActions-CTFh4m8T.js';
import { C as CardHeader } from './CardHeader-DPJD8jKc.js';

let checkedList = writable([]);
async function loadData({ page, url, request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({
      path: `/api/panel/tickets?page=${page}&categoryUrl=${url}`,
      request
    }).then((body) => {
      if (body.result === "ok") {
        const data = body;
        data.page = parseInt(page);
        data.url = url;
        resolve(data);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  let data = {
    ticketCount: 0,
    tickets: [],
    totalPage: 1,
    page: 1,
    url: event.params.url,
    category: {
      id: -1,
      title: "-",
      description: "",
      url: "-"
    }
  };
  if (parentData.NETWORK_ERROR) {
    return data;
  }
  await loadData({
    page: event.params.page || 1,
    url: event.params.url,
    request: event
  }).then((body) => {
    data = { ...data, ...body };
  }).catch((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
  });
  return data;
}
function isAllTicketsSelected(ticketsList, selectedList) {
  let isAllSelected = true;
  ticketsList.forEach((ticket) => {
    if (!selectedList[ticket.id]) isAllSelected = false;
  });
  return isAllSelected;
}
const CategoryTickets = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $checkedList, $$unsubscribe_checkedList;
  let $_, $$unsubscribe__;
  $$unsubscribe_checkedList = subscribe(checkedList, (value) => $checkedList = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  let firstLoad = true;
  function getListOfChecked(list) {
    const result = Object.keys(list).filter((key) => list[key]);
    if (result.length > 0) firstLoad = false;
    return result;
  }
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  {
    {
      pageTitle.set($_("pages.category-tickets.title", {
        values: {
          category: data.category.title === "-" ? $_("pages.category-tickets.no-category") : data.category.title
        }
      }));
    }
  }
  $$unsubscribe_checkedList();
  $$unsubscribe__();
  return ` <article class="container"> ${validate_component(PageActions, "PageActions").$$render($$result, {}, {}, {
    right: () => {
      return `<div class="${[
        "animate__animated animate__faster " + escape(
          getListOfChecked($checkedList).length > 0 ? "animate__slideInUp" : "animate__slideOutDown",
          true
        ) + " faster",
        firstLoad ? "d-none" : ""
      ].join(" ").trim()}" slot="right"><a class="${[
        "btn btn-link link-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" role="button" href="javascript:void(0);"><i class="fas fa-trash me-2"></i> ${escape($_("pages.category-tickets.delete"))}</a> <a class="${[
        "btn btn-danger",
        getListOfChecked($checkedList).length === 0 ? "disabled" : ""
      ].join(" ").trim()}" role="button" href="javascript:void(0);"><i class="fas fa-times me-2"></i> ${escape($_("pages.category-tickets.close-ticket"))}</a></div>`;
    },
    left: () => {
      return `<a class="btn btn-link" role="button" href="${escape(base, true) + "/tickets"}" slot="left"><i class="fas fa-arrow-left me-2"></i> ${escape($_("pages.category-tickets.tickets"))}</a>`;
    }
  })}  <div class="card"><div class="card-body">${validate_component(CardHeader, "CardHeader").$$render($$result, {}, {}, {
    left: () => {
      return `<h5 class="card-title mb-md-0" slot="left">${escape($_("pages.category-tickets.table-title", {
        values: { ticketCount: data.ticketCount }
      }) + (getListOfChecked($checkedList).length > 0 ? ", " + $_("pages.category-tickets.amount-selected", {
        values: {
          amount: getListOfChecked($checkedList).length
        }
      }) : ""))}</h5>`;
    }
  })}  ${data.ticketCount === 0 ? `${validate_component(NoContent, "NoContent").$$render($$result, {}, {}, {})}` : ` <div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th class="text-nowrap align-middle" scope="col"><div class="form-check"><input class="form-check-input" ${isAllTicketsSelected(data.tickets, $checkedList) ? "checked" : ""} id="selectAll" type="checkbox"></div></th> <th class="align-middle" scope="col">${escape($_("pages.category-tickets.table.title"))}</th> <th class="align-middle" scope="col">${escape($_("pages.category-tickets.table.status"))}</th> <th class="align-middle table-primary" scope="col">${escape($_("pages.category-tickets.table.category"))}</th> <th class="align-middle" scope="col">${escape($_("pages.category-tickets.table.player"))}</th> <th class="align-middle" scope="col">${escape($_("pages.category-tickets.table.last-reply"))}</th></tr></thead> <tbody>${each(data.tickets, (ticket, index) => {
    return `${validate_component(TicketRow, "TicketRow").$$render($$result, { ticket, checkedList }, {}, {})}`;
  })}</tbody></table></div>`}  ${validate_component(Pagination, "Pagination").$$render(
    $$result,
    {
      page: data.page,
      totalPage: data.totalPage
    },
    {},
    {}
  )}</div></div> </article>`;
});

export { CategoryTickets as C, load as l };
//# sourceMappingURL=CategoryTickets-DqbWrP07.js.map
