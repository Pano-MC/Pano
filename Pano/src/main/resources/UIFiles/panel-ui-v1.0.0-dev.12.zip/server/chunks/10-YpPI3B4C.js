import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import './client-CnCRRyPd.js';
import { C as CardMenu, a as CardMenuItem } from './CardMenuItem-DRnpye9y.js';

async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_VIEW, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const ViewLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `  <article class="container"> <nav>${validate_component(CardMenu, "CardMenu").$$render($$result, {}, {}, {
    default: () => {
      return `${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view" }, {}, {
        default: () => {
          return `Temalar`;
        }
      })} ${validate_component(CardMenuItem, "CardMenuItem").$$render($$result, { href: "/view/theme-options" }, {}, {
        default: () => {
          return `Tema Seçenekleri`;
        }
      })}`;
    }
  })}</nav> ${slots.default ? slots.default({}) : ``} </article>`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 10;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DeIQIS9N.js')).default;
const universal_id = "src/routes/view/+layout.js";
const imports = ["_app/immutable/nodes/10.CqETJPy5.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/auth.util.hs9BjLIh.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/index.DDzQTuOI.js","_app/immutable/chunks/CardMenuItem.BRtjOUMK.js"];
const stylesheets = [];
const fonts = [];

var _10 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ViewLayout as V, _10 as _ };
//# sourceMappingURL=10-YpPI3B4C.js.map
