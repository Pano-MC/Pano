import { l as load } from './PermissionGroupDetail-D9FLSE1a.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-BcrTWKQe.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 29;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DUTGjI-W.js')).default;
const universal_id = "src/routes/players/perm-groups/create/+page.js";
const imports = ["_app/immutable/nodes/29.jCWC52v4.js","_app/immutable/chunks/PermissionGroupDetail.DU_C_D7I.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/index.DDzQTuOI.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/tooltip.util.VekvBMMm.js","_app/immutable/chunks/Store.BIVD_fLK.js","_app/immutable/chunks/Toast.DKtYi-jV.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=29-XLXWlfMS.js.map
