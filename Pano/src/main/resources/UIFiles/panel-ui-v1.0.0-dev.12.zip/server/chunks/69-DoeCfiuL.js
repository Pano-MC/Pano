const index = 69;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DYnCqbzh.js')).default;
const imports = ["_app/immutable/nodes/69.DJuqv_tg.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/paths.B9B_E_qC.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=69-DoeCfiuL.js.map
