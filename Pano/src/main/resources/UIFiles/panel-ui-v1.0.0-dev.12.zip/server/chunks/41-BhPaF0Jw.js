import { l as load$1, M as Modes } from './PostEditor-kYO6YYnl.js';
import './ssr-ffuobYCI.js';
import './index-DzcLzHBX.js';
import './api.util-BcrTWKQe.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './runtime-DMBi37QM.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './ToastContainer-CKzXwJro.js';
import './AddEditPostCategoryModal-BamjU8eK.js';
import './Editor-CmEWUnXW.js';
import '@tiptap/starter-kit';
import '@tiptap/extension-underline';
import '@tiptap/extension-link';
import '@tiptap/extension-image';
import '@tiptap/extension-text-style';
import '@tiptap/extension-color';
import './NoContent-N-qOzDdv.js';
import './PageActions-CTFh4m8T.js';

async function load(params) {
  return load$1(params, Modes.EDIT);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 41;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C3SyMSQ0.js')).default;
const universal_id = "src/routes/posts/post/[id]/+page.js";
const imports = ["_app/immutable/nodes/41.TBnzwucS.js","_app/immutable/chunks/PostEditor.C5_KsLWY.js","_app/immutable/chunks/scheduler.DXLFmiLT.js","_app/immutable/chunks/index.BA2HnbgI.js","_app/immutable/chunks/each.BbucQ6WL.js","_app/immutable/chunks/index.DDzQTuOI.js","_app/immutable/chunks/entry.BzEQwkwN.js","_app/immutable/chunks/paths.B9B_E_qC.js","_app/immutable/chunks/api.util.BR24nH2v.js","_app/immutable/chunks/stores.7JWkmOFC.js","_app/immutable/chunks/runtime.CI2qchat.js","_app/immutable/chunks/tooltip.util.VekvBMMm.js","_app/immutable/chunks/Store.BIVD_fLK.js","_app/immutable/chunks/ConfirmDeletePostModal.BGeRhgA2.js","_app/immutable/chunks/Toast.DKtYi-jV.js","_app/immutable/chunks/AddEditPostCategoryModal.BAr4abxq.js","_app/immutable/chunks/Editor.BkJOrO5j.js","_app/immutable/chunks/PostPublishedToast.B7P7Oj7N.js","_app/immutable/chunks/NoContent.DGPybuky.js","_app/immutable/chunks/PageActions.aH27r9KG.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=41-BhPaF0Jw.js.map
