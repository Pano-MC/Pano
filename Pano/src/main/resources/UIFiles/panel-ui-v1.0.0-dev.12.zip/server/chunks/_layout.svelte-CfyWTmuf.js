import { c as create_ssr_component, v as validate_component, a as subscribe, e as escape } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import { b as base } from './paths-C6LjEmZF.js';
import { p as page } from './stores-BDx4Az-R.js';
import './index2-Dyghn50Q.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';

function matching(path, pathName, startsWith = false) {
  return path.toUpperCase() === pathName.toUpperCase() || path.toUpperCase() === (pathName + "/").toUpperCase() || startsWith && path.startsWith(pathName);
}
const ServerSettingsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $page, $$unsubscribe_page;
  let $_, $$unsubscribe__;
  $$unsubscribe_page = subscribe(page, (value) => $page = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_page();
  $$unsubscribe__();
  return ` <div class="container"><div class="row justify-content-around"><div class="col-auto"> <div class="nav nav-pills d-flex flex-row justify-content-center mb-3 w-100"><a class="${[
    "nav-item nav-link",
    matching($page.url.pathname, base + "/server/settings") ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/server/settings"}">${escape($_("components.server-settings-layout.server"))}</a> <a class="${[
    "nav-item nav-link",
    matching($page.url.pathname, base + "/server/settings/game-integration", true) ? "active" : ""
  ].join(" ").trim()}" href="${escape(base, true) + "/server/settings/game-integration"}">${escape($_("components.server-settings-layout.game-integration"))}</a></div></div></div> ${slots.default ? slots.default({}) : ``} </div>`;
});
const Layout_1 = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${validate_component(ServerSettingsLayout, "Layout").$$render($$result, {}, {}, {
    default: () => {
      return `${slots.default ? slots.default({}) : ``}`;
    }
  })}`;
});

export { Layout_1 as default };
//# sourceMappingURL=_layout.svelte-CfyWTmuf.js.map
