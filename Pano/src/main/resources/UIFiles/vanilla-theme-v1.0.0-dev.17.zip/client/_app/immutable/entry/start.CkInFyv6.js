import{a as t}from"../chunks/uLBgLq7N.js";export{t as start};
