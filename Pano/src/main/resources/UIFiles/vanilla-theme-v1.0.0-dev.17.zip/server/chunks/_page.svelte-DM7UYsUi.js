import { R as ResetPassword } from './18-DLlXls77.js';
import './exports-BfEJ4K87.js';
import './ErrorAlert-X169Tyv3.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './SuccessAlert-Bqq50Pae.js';
import './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';

function _page($$payload) {
  ResetPassword($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DM7UYsUi.js.map
