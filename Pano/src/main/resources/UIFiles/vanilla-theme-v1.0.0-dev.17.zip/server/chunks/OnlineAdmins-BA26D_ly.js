import { p as push, a9 as ensure_array_like, a5 as store_get, a8 as stringify, a6 as unsubscribe_stores, a3 as bind_props, t as pop } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import './client-H9pbvEMN.js';
import { a as attr } from './attributes-CLjFMQKp.js';

function OnlineAdmins($$payload, $$props) {
  push();
  var $$store_subs;
  let onlineAdmins = $$props["onlineAdmins"];
  const each_array = ensure_array_like(onlineAdmins);
  $$payload.out += `<div class="card"><h5 class="card-body">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.online-admins.online-admins"))}</h5> <div class="card-body"><div class="row"><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let onlineAdmin = each_array[index];
    $$payload.out += `<div class="col-3"><a${attr("href", `/player/${stringify(onlineAdmin)}`)}><img alt="" class="rounded"${attr("src", `https://minotar.net/avatar/${stringify(onlineAdmin)}`)} width="24" onload="this.__e=event" onerror="this.__e=event"></a></div>`;
  }
  $$payload.out += `<!--]--></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { onlineAdmins });
  pop();
}

export { OnlineAdmins as O };
//# sourceMappingURL=OnlineAdmins-BA26D_ly.js.map
