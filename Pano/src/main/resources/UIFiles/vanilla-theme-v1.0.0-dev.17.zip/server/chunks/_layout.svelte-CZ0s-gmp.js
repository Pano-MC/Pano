import { a4 as slot } from './exports-BfEJ4K87.js';
import { P as ProfileLayout } from './2-nlM_k4gO.js';
import './Store-BE6l6YE-.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';

function _layout($$payload, $$props) {
  ProfileLayout($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-CZ0s-gmp.js.map
