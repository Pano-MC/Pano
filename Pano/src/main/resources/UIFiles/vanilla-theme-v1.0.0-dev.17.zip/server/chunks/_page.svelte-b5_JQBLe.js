import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { A as Activate } from './6-CM1Ozc4x.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import './ErrorAlert-X169Tyv3.js';
import './SuccessAlert-Bqq50Pae.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Activate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-b5_JQBLe.js.map
