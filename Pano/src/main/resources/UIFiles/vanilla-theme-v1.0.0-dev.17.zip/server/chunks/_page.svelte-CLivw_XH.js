import { a3 as bind_props, t as pop, p as push } from './exports-BfEJ4K87.js';
import { P as PreviewPost } from './14-CRRjdnic.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './posts2-DX-uGxh3.js';
import './client-H9pbvEMN.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './attributes-CLjFMQKp.js';
import './html-FW6Ia4bL.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  PreviewPost($$payload, { post: data.post });
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CLivw_XH.js.map
