import { a4 as slot, t as pop, p as push, a5 as store_get, a8 as stringify, a6 as unsubscribe_stores, $ as writable } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import { E as ErrorAlert } from './ErrorAlert-X169Tyv3.js';
import { a as attr } from './attributes-CLjFMQKp.js';
import { r as requireLogin } from './Store-BE6l6YE-.js';

const dialogID = "closeTicketConfirmModal";
const error = writable();
function CloseTicketConfirmModal($$payload, $$props) {
  push();
  var $$store_subs;
  let loading = false;
  $$payload.out += `<div aria-hidden="true" class="modal fade"${attr("id", dialogID)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center">`;
  ErrorAlert($$payload, {
    error: store_get($$store_subs ??= {}, "$error", error)
  });
  $$payload.out += `<!----> <div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.close-ticket-confirm.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr("class", `btn btn-link col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} data-bs-dismiss="modal" type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.close-ticket-confirm.cancel-button"))}</button> <button${attr("class", `btn btn-danger col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.close-ticket-confirm.yes-button"))}</button></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function TicketsLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----> `;
  CloseTicketConfirmModal($$payload);
  $$payload.out += `<!---->`;
  pop();
}

export { TicketsLayout as T, load as l };
//# sourceMappingURL=TicketsLayout-Dfuqc5Gf.js.map
