import { l as load } from './CategoryPosts-DhTAxPLL.js';
import './exports-BfEJ4K87.js';
import './client-H9pbvEMN.js';
import './Pagination-B3bMpcNW.js';
import './attributes-CLjFMQKp.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-DhViOBlQ.js';
import './posts2-DX-uGxh3.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './html-FW6Ia4bL.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './NoContent-DYbphjUk.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 9;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CLDZUUix.js')).default;
const universal_id = "src/routes/blog/category/[url]/[page]/+page.js";
const imports = ["_app/immutable/nodes/9.21UPYkh6.js","_app/immutable/chunks/Dbhi4Jjb.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/B94rtNwV.js","_app/immutable/chunks/iwVU6BAp.js","_app/immutable/chunks/nu-QtGX9.js","_app/immutable/chunks/zaaEHRCB.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/xYCgxWap.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/CVOxQNp7.js","_app/immutable/chunks/CZY_utnm.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/CH6jqJx4.js","_app/immutable/chunks/BKKDk-M3.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=9-DUsPWXiL.js.map
