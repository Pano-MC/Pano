import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { S as Support } from './19-Db2t1HJl.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Sidebar-DYK0iAPC.js';
import './attributes-CLjFMQKp.js';
import './OnlineAdmins-BA26D_ly.js';
import './client-H9pbvEMN.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Support($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DyiElr_e.js.map
