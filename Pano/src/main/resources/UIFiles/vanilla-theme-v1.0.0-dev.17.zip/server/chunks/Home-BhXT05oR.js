import { a3 as bind_props, t as pop, p as push } from './exports-BfEJ4K87.js';
import './client-H9pbvEMN.js';
import { P as Pagination } from './Pagination-B3bMpcNW.js';
import { P as Posts } from './Posts-DhViOBlQ.js';
import { l as load$1, H as HomeSidebar } from './HomeSidebar-CGpBiQ9M.js';
import { a as getPosts } from './posts2-DX-uGxh3.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    posts: [],
    postCount: 0,
    page: 1,
    totalPage: 1
  };
  await load$1(event);
  await getPosts({ page: event.params.page || 1, request: event }).then((body) => {
    if (body.error) {
      return;
    }
    data = body;
  });
  return { ...data, sidebar: HomeSidebar };
}
function Home($$payload, $$props) {
  push();
  let data = $$props["data"];
  Posts($$payload, { posts: data.posts });
  $$payload.out += `<!---->  `;
  if (data.postCount > 0) {
    $$payload.out += "<!--[-->";
    Pagination($$payload, {
      page: data.page,
      totalPage: data.totalPage,
      loading: false
    });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { data });
  pop();
}

export { Home as H, load as l };
//# sourceMappingURL=Home-BhXT05oR.js.map
