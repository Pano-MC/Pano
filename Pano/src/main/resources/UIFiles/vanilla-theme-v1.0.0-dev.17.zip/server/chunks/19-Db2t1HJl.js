import { t as pop, a7 as getContext, a5 as store_get, a8 as stringify, a6 as unsubscribe_stores, a3 as bind_props, $ as writable, p as push } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { S as Sidebar } from './Sidebar-DYK0iAPC.js';
import { O as OnlineAdmins } from './OnlineAdmins-BA26D_ly.js';
import { b as ApiUtil } from './api.util-BLY_r-ze.js';
import { a as attr } from './attributes-CLjFMQKp.js';

const data = writable({ onlineAdmins: [] });
const load$1 = async (event) => {
  data.set(await ApiUtil.get({ path: "/api/sidebars/support", request: event }));
};
function SupportSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  Sidebar($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3">`;
      OnlineAdmins($$payload2, {
        onlineAdmins: store_get($$store_subs ??= {}, "$data", data).onlineAdmins
      });
      $$payload2.out += `<!----></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: SupportSidebar };
}
function Support($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.title"))}</h3> <p>Sana nasıl yardımcı olabiliriz?</p> <ul class="list-group list-group-horizontal text-center"><a href="/ticket/create" class="list-group-item list-group-item-action"><i class="fas fa-ticket fa-2x my-3"></i> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.create-ticket.description"))}</small></a> <a${attr("href", `mailto:${stringify(store_get($$store_subs ??= {}, "$session", session).siteInfo.supportEmail)}`)} class="list-group-item list-group-item-action"><i class="fas fa-envelope fa-2x my-3"></i> <div class="col-auto"><h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.title"))}</h5> <small>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.support.options.send-email.description", {
    values: {
      websiteName: store_get($$store_subs ??= {}, "$session", session).siteInfo.websiteName
    }
  }))}</small></div></a></ul></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 19;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DyiElr_e.js')).default;
const universal_id = "src/routes/support/+page.js";
const imports = ["_app/immutable/nodes/19.CRHSefoe.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/iwVU6BAp.js","_app/immutable/chunks/DMhHDJ_C.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/UKvCIEl3.js","_app/immutable/chunks/CZY_utnm.js","_app/immutable/chunks/zaaEHRCB.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/ZN-_CbYj.js"];
const stylesheets = [];
const fonts = [];

var _19 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Support as S, _19 as _ };
//# sourceMappingURL=19-Db2t1HJl.js.map
