import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { R as RenewPassword } from './17-D9daPs6d.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ErrorAlert-X169Tyv3.js';
import './SuccessAlert-Bqq50Pae.js';
import './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  RenewPassword($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CR3VfX99.js.map
