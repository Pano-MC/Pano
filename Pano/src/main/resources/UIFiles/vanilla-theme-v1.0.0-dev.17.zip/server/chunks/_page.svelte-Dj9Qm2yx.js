import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { T as Tickets_1 } from './Tickets-21NlM19y.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-H9pbvEMN.js';
import './Pagination-B3bMpcNW.js';
import './attributes-CLjFMQKp.js';
import './Tickets2-CjS_X-Ty.js';
import './TicketStatus-s7ALczDp.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './NoContent-DYbphjUk.js';
import './ProfileSidebar-YzfM_jah.js';
import './index-server-DVwCVYmq.js';
import './stores-BwnjvE8h.js';
import './PlayerHead-D35rgeKg.js';
import './Sidebar-DYK0iAPC.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Tickets_1($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Dj9Qm2yx.js.map
