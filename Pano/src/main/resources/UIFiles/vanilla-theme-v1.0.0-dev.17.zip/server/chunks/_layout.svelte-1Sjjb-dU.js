import { a4 as slot } from './exports-BfEJ4K87.js';
import { T as TicketsLayout } from './TicketsLayout-Dfuqc5Gf.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import './ErrorAlert-X169Tyv3.js';
import './attributes-CLjFMQKp.js';
import './Store-BE6l6YE-.js';

function _layout($$payload, $$props) {
  TicketsLayout($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-1Sjjb-dU.js.map
