import { a3 as bind_props, t as pop, a5 as store_get, a6 as unsubscribe_stores, $ as writable, p as push } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { D as Date_1 } from './Date-zMnMO5nb.js';
import { e as error } from './index2-DzcLzHBX.js';
import { o as onDestroy } from './index-server-DVwCVYmq.js';
import { S as Sidebar } from './Sidebar-DYK0iAPC.js';
import { P as PlayerHead, a as PlayerPermissionBadge } from './PlayerHead-D35rgeKg.js';
import { b as ApiUtil } from './api.util-BLY_r-ze.js';
import { g as getPlayerProfile } from './profile2-EHP-UX5h.js';

const data = writable({
  username: "",
  lastActivityTime: 0,
  inGame: false,
  permissionGroupName: ""
});
const load$1 = async (event) => {
  data.set({
    ...await ApiUtil.get({
      path: `/api/sidebars/profiles/${event.params.player}`,
      request: event
    }),
    username: event.params.player
  });
};
String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerProfileSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let checkTime = 0;
  let interval;
  let side = $$props["side"];
  onDestroy(() => {
    clearInterval(interval);
  });
  Sidebar($$payload, {
    side,
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3"><div class="card"><div class="card-body">`;
      PlayerHead($$payload2, {
        username: store_get($$store_subs ??= {}, "$data", data).username,
        inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
        lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
        checkTime
      });
      $$payload2.out += `<!----> <div class="text-center"><h2 class="my-3">${escape_html(store_get($$store_subs ??= {}, "$data", data).username)}</h2> `;
      PlayerPermissionBadge($$payload2, {
        permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName
      });
      $$payload2.out += `<!----></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { side });
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  let data2 = { registerDate: 0 };
  await load$1(event);
  await getPlayerProfile({ username: event.params.player, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data2 = body;
  });
  return {
    ...data2,
    sidebar: PlayerProfileSidebar,
    sidebarProps: { side: "left" }
  };
}
function PlayerProfile($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  $$payload.out += `<div class="card"><div class="card-body"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.title"))}</h4> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data2.registerDate });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bvk-f3lU.js')).default;
const universal_id = "src/routes/player/[player]/+page.js";
const imports = ["_app/immutable/nodes/13.W7zLA-Fa.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/iwVU6BAp.js","_app/immutable/chunks/DMhHDJ_C.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/D6QBWdlh.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/zaaEHRCB.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/B9nrY-_9.js","_app/immutable/chunks/xYCgxWap.js"];
const stylesheets = [];
const fonts = [];

var _13 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PlayerProfile as P, _13 as _ };
//# sourceMappingURL=13-BKZfeXmI.js.map
