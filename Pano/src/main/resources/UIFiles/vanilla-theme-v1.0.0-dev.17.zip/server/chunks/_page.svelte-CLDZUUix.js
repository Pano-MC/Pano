import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { C as CategoryPosts } from './CategoryPosts-DhTAxPLL.js';
import './client-H9pbvEMN.js';
import './Pagination-B3bMpcNW.js';
import './attributes-CLjFMQKp.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-DhViOBlQ.js';
import './posts2-DX-uGxh3.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './html-FW6Ia4bL.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './NoContent-DYbphjUk.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  CategoryPosts($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CLDZUUix.js.map
