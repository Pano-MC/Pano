import { p as push, ac as fallback, a8 as stringify, a4 as slot, a3 as bind_props, t as pop, a5 as store_get, a6 as unsubscribe_stores } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { a as attr } from './attributes-CLjFMQKp.js';

function NoContent($$payload, $$props) {
  push();
  var $$store_subs;
  let dark = fallback($$props["dark"], false);
  let icon = fallback($$props["icon"], "fa-solid fa-ghost fa-3x");
  let text = fallback($$props["text"], () => store_get($$store_subs ??= {}, "$_", $format)("components.no-content.text"), true);
  $$payload.out += `<div class="container text-center">`;
  if (dark) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<i${attr("class", `${stringify(icon)} text-light text-opacity-25 m-3`)}></i> <p class="text-light">${escape_html(text)}</p>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<i${attr("class", `${stringify(icon)} text-dark text-opacity-25 m-3`)}></i> <small class="text-gray d-block mb-3">${escape_html(text)}</small>`;
  }
  $$payload.out += `<!--]--> <!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { dark, icon, text });
  pop();
}

export { NoContent as N };
//# sourceMappingURL=NoContent-DYbphjUk.js.map
