import { a4 as slot, t as pop, p as push } from './exports-BfEJ4K87.js';
import { r as requireLogin } from './Store-BE6l6YE-.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CZ0s-gmp.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.Ct3GI49D.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/iwVU6BAp.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-nlM_k4gO.js.map
