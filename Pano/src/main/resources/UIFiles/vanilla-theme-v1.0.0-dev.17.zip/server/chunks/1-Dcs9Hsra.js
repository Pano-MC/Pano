const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-BITsF_Qr.js')).default;
const imports = ["_app/immutable/nodes/1.BM4GkkcW.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/ZN-_CbYj.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-Dcs9Hsra.js.map
