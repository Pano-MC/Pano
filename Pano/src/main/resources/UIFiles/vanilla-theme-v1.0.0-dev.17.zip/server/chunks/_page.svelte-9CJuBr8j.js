import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { P as PostDetail } from './11-BTfCQxbY.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-H9pbvEMN.js';
import './posts2-DX-uGxh3.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './attributes-CLjFMQKp.js';
import './html-FW6Ia4bL.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './HomeSidebar-CGpBiQ9M.js';
import './Sidebar-DYK0iAPC.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PostDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-9CJuBr8j.js.map
