import { a3 as bind_props, a4 as slot } from './exports-BfEJ4K87.js';
import { M as MainLayout } from './0-Df6-uCB2.js';
import './index-server-DVwCVYmq.js';
import './stores-BwnjvE8h.js';
import './client-H9pbvEMN.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-CLjFMQKp.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './NoContent-DYbphjUk.js';
import './language.util-BzYSW87z.js';
import './html-FW6Ia4bL.js';
import './ErrorAlert-X169Tyv3.js';
import './SuccessAlert-Bqq50Pae.js';
import 'fs';
import './paths-DEXY_3zL.js';
import './formatDistanceToNow-B4adM_tS.js';

function _layout($$payload, $$props) {
  let data = $$props["data"];
  MainLayout($$payload, {
    data,
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-CNW2-xUW.js.map
