import { S as Settings } from './16-BBal6aOK.js';
import './exports-BfEJ4K87.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import './ProfileSidebar-YzfM_jah.js';
import './index-server-DVwCVYmq.js';
import './stores-BwnjvE8h.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './PlayerHead-D35rgeKg.js';
import './Sidebar-DYK0iAPC.js';

function _page($$payload) {
  Settings($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BKAJCsot.js.map
