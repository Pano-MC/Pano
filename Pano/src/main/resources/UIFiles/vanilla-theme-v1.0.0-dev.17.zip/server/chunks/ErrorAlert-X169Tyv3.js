import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { e as escape_html } from './runtime-DeeE_GqA.js';

function ErrorAlert($$payload, $$props) {
  let error = $$props["error"];
  const alwaysVisible = false;
  if (error || alwaysVisible) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="alert alert-danger">${escape_html(error)}</div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { error });
}

export { ErrorAlert as E };
//# sourceMappingURL=ErrorAlert-X169Tyv3.js.map
