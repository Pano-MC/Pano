import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push, a8 as stringify } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { a as attr } from './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import { E as ErrorAlert } from './ErrorAlert-X169Tyv3.js';
import { S as SuccessAlert } from './SuccessAlert-Bqq50Pae.js';

async function load({ parent, url: { searchParams } }) {
  await parent();
  const token = searchParams.get("token") || "";
  return { token };
}
function ActivateNewEmail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let error;
  let successMessage = null;
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.title"))}</h3> <img alt="Allay" src="https://cdn3.emoji.gg/emojis/8182-allay-dancing.gif"> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message: successMessage });
  $$payload.out += `<!----> <button${attr("class", `btn btn-secondary w-100 ${stringify([
    ""
  ].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.activate-button"))}</button></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BlSnxARm.js')).default;
const universal_id = "src/routes/activate-new-email/+page.js";
const imports = ["_app/immutable/nodes/7.Bk5EeTWy.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/iwVU6BAp.js","_app/immutable/chunks/-8nwdFtn.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/Ben4kM1J.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ActivateNewEmail as A, _7 as _ };
//# sourceMappingURL=7-pJdmrQ9n.js.map
