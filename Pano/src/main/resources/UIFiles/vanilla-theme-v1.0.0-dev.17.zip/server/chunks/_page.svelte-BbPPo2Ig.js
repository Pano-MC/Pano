import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { T as TicketCreate } from './21-B9DNe48u.js';
import './client-H9pbvEMN.js';
import './TicketStatus-s7ALczDp.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './index2-DzcLzHBX.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ErrorAlert-X169Tyv3.js';
import './attributes-CLjFMQKp.js';
import './TicketCreateAndDetailSidebar-BnffHhcG.js';
import './Sidebar-DYK0iAPC.js';
import './OnlineAdmins-BA26D_ly.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  TicketCreate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BbPPo2Ig.js.map
