import { $ as writable } from './exports-BfEJ4K87.js';
import './client-H9pbvEMN.js';
import { r as redirect } from './index2-DzcLzHBX.js';

const notificationsCount = writable(0);
const quickNotifications = writable([]);
const initialized = writable(false);
function requireLogin(session) {
  if (!session.user) {
    throw redirect(302, "/");
  }
}
function requireNotLogin(session) {
  if (session.user) {
    throw redirect(302, "/");
  }
}

export { requireNotLogin as a, initialized as i, notificationsCount as n, quickNotifications as q, requireLogin as r };
//# sourceMappingURL=Store-BE6l6YE-.js.map
