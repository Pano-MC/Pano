import { ad as current_component } from './exports-BfEJ4K87.js';

function onDestroy(fn) {
  var context = (
    /** @type {Component} */
    current_component
  );
  (context.d ??= []).push(fn);
}

export { onDestroy as o };
//# sourceMappingURL=index-server-DVwCVYmq.js.map
