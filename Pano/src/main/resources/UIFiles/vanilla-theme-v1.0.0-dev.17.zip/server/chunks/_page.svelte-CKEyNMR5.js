import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { N as Notifications } from './12-D2QP5KzY.js';
import './index-server-DVwCVYmq.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './language.util-BzYSW87z.js';
import './client-H9pbvEMN.js';
import './attributes-CLjFMQKp.js';
import './index2-DzcLzHBX.js';
import './NoContent-DYbphjUk.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './formatDistanceToNow-B4adM_tS.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Notifications($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CKEyNMR5.js.map
