import { p as push, ac as fallback, a9 as ensure_array_like, a8 as stringify, a3 as bind_props, t as pop } from './exports-BfEJ4K87.js';
import { a as attr } from './attributes-CLjFMQKp.js';
import { e as escape_html } from './runtime-DeeE_GqA.js';

function Pagination($$payload, $$props) {
  push();
  let pages;
  let page = $$props["page"];
  let loading = fallback($$props["loading"], false);
  let totalPage = fallback($$props["totalPage"], 1);
  {
    pages = [];
    for (let i = 1; i <= totalPage; i++) {
      pages.push(i);
    }
  }
  const each_array = ensure_array_like(pages);
  $$payload.out += `<nav><ul class="pagination justify-content-center"><li${attr("class", `page-item ${stringify([
    parseInt(page) === 1 || loading ? "disabled" : ""
  ].filter(Boolean).join(" "))}`)}><a class="page-link" href="javascript:void(0);"${attr("aria-hidden", parseInt(page) === 1 || loading)}><i class="fa-solid fa-caret-left"></i></a></li> <!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let index = each_array[$$index];
    $$payload.out += `<li${attr("class", `page-item ${stringify([
      parseInt(page) === index ? "active" : "",
      parseInt(page) !== index && loading ? "disabled" : ""
    ].filter(Boolean).join(" "))}`)}${attr("aria-current", parseInt(page) === index ? "page" : "")}><a class="page-link" href="javascript:void(0);"${attr("aria-hidden", parseInt(page) === index)}>${escape_html(index)}</a></li>`;
  }
  $$payload.out += `<!--]--> <li${attr("class", `page-item ${stringify([
    parseInt(page) === totalPage || loading ? "disabled" : ""
  ].filter(Boolean).join(" "))}`)}><a class="page-link"${attr("aria-hidden", parseInt(page) === totalPage || loading)} href="javascript:void(0);"><i class="fa-solid fa-caret-right"></i></a></li></ul></nav>`;
  bind_props($$props, { page, loading, totalPage });
  pop();
}

export { Pagination as P };
//# sourceMappingURL=Pagination-B3bMpcNW.js.map
