import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push } from './exports-BfEJ4K87.js';
import './client-H9pbvEMN.js';
import { P as Pagination } from './Pagination-B3bMpcNW.js';
import { P as Posts } from './Posts-DhViOBlQ.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { g as getCategoryPosts } from './posts2-DX-uGxh3.js';
import { e as error } from './index2-DzcLzHBX.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    posts: [],
    postCount: 0,
    totalPage: 1,
    page: 1,
    category: {
      id: -1,
      title: "",
      description: "",
      url: "",
      color: ""
    }
  };
  await getCategoryPosts({
    page: event.params.page || 1,
    url: event.params.url,
    request: event
  }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return data;
}
function CategoryPosts($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="row justify-content-between mb-3"><div class="col-auto"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.category-posts.title", {
    values: {
      categoryTitle: data.category.title,
      postCount: data.postCount
    }
  }))}</h4></div> <div class="col-auto"><a href="/"><i class="fas fa-arrow-left me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.category-posts.posts"))}</a></div></div> `;
  Posts($$payload, { posts: data.posts });
  $$payload.out += `<!----> `;
  if (data.postCount > 0) {
    $$payload.out += "<!--[-->";
    Pagination($$payload, {
      page: data.page,
      totalPage: data.totalPage,
      loading: false
    });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

export { CategoryPosts as C, load as l };
//# sourceMappingURL=CategoryPosts-DhTAxPLL.js.map
