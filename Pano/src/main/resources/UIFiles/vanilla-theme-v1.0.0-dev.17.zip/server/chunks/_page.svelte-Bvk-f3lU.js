import { a3 as bind_props } from './exports-BfEJ4K87.js';
import { P as PlayerProfile } from './13-BKZfeXmI.js';
import './runtime-DeeE_GqA.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-zMnMO5nb.js';
import './language.util-BzYSW87z.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import './index-server-DVwCVYmq.js';
import './Sidebar-DYK0iAPC.js';
import './attributes-CLjFMQKp.js';
import './PlayerHead-D35rgeKg.js';
import './api.util-BLY_r-ze.js';
import './Store-BE6l6YE-.js';
import './profile2-EHP-UX5h.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PlayerProfile($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Bvk-f3lU.js.map
