import { a7 as getContext, a5 as store_get, a6 as unsubscribe_stores, t as pop, p as push, a8 as stringify } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { a as attr } from './attributes-CLjFMQKp.js';
import './client-H9pbvEMN.js';
import './index2-DzcLzHBX.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-YzfM_jah.js';

async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: ProfileSidebar };
}
function Settings($$payload, $$props) {
  push();
  var $$store_subs;
  let resetPasswordError;
  const session = getContext("session");
  $$payload.out += `<div class="card"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.title"))}</h5> <div class="row mb-3"><label class="col-md-4 col-form-label" for="resetPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.title"))}</label> <div class="col col-form-label"><button${attr("class", `btn btn-outline-primary ${stringify([""].filter(Boolean).join(" "))}`)}${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)} aria-describedby="resetPassword validationResetPassword" type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.description"))}</button> <div id="validationResetPassword" class="invalid-feedback">${escape_html(resetPasswordError)}</div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></div> <div class="row mb-3"><label class="col-md-4 col-form-label" for="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.title"))}</label> <div class="col col-form-label"><form><div class="row">`;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="col-12">`;
    {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<button type="button" class="btn btn-outline-primary" aria-describedby="userEmail"${attr("disabled", !store_get($$store_subs ??= {}, "$session", session).siteInfo.emailEnabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.description"))}</button>`;
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></form></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BKAJCsot.js')).default;
const universal_id = "src/routes/profile/settings/+page.js";
const imports = ["_app/immutable/nodes/16.CZqikpIO.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/Da_Fkmyz.js","_app/immutable/chunks/uLBgLq7N.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/CxuTIO-w.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/CNYJ9T2b.js","_app/immutable/chunks/zaaEHRCB.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/iwVU6BAp.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/D6QBWdlh.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/DMhHDJ_C.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/B9nrY-_9.js"];
const stylesheets = [];
const fonts = [];

var _16 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Settings as S, _16 as _ };
//# sourceMappingURL=16-BBal6aOK.js.map
