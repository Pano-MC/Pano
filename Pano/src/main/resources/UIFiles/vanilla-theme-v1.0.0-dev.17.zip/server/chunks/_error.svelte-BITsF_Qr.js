import { a5 as store_get, a6 as unsubscribe_stores, t as pop, p as push } from './exports-BfEJ4K87.js';
import { e as escape_html, $ as $format } from './runtime-DeeE_GqA.js';
import { p as page } from './stores-BwnjvE8h.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-H9pbvEMN.js';

function Error($$payload, $$props) {
  push();
  var $$store_subs;
  $$payload.out += `<h3>${escape_html(store_get($$store_subs ??= {}, "$page", page).status)}: ${escape_html(store_get($$store_subs ??= {}, "$page", page).status === 404 ? store_get($$store_subs ??= {}, "$_", $format)("page-errors." + store_get($$store_subs ??= {}, "$page", page).status) : store_get($$store_subs ??= {}, "$page", page).error.message)}</h3>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function _error($$payload) {
  Error($$payload);
}

export { _error as default };
//# sourceMappingURL=_error.svelte-BITsF_Qr.js.map
