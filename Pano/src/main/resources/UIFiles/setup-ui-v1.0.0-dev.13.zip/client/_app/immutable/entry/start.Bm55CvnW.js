import{a as t}from"../chunks/qjUKbvNW.js";export{t as start};
