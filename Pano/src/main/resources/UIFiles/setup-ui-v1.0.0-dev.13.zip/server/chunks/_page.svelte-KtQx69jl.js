import { ad as spread_props, a6 as bind_props, t as pop, p as push } from './index2-BSgs6Xxn.js';
import { S as Step2 } from './5-DrfaZ7Nz.js';
import './runtime-BGFZ81nX.js';
import './attributes-BEm38Kz9.js';
import './client-DcSItIJ-.js';
import './ErrorAlert-CWi-wjrX.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  Step2($$payload, spread_props([data.stepInfo]));
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-KtQx69jl.js.map
