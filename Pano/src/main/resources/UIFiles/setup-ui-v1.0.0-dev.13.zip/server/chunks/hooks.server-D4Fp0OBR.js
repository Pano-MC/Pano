import { C as COOKIE_PREFIX, a as CSRF_TOKEN_COOKIE_NAME, A as API_URL } from './variables-CdsVAjOE.js';
import { g as getAcceptedLanguage } from './language.util-BUy5RBbb.js';
import './index2-BSgs6Xxn.js';
import './runtime-BGFZ81nX.js';

async function handle({
  event,
  event: {
    cookies,
    request: { headers }
  },
  resolve
}) {
  event.locals.acceptedLanguage = getAcceptedLanguage(headers);
  event.locals.CSRFToken = cookies.get(COOKIE_PREFIX + CSRF_TOKEN_COOKIE_NAME);
  return resolve(event);
}
async function handleFetch({ event, request, fetch }) {
  if (request.url.startsWith(API_URL)) {
    request.headers.set("cookie", event.request.headers.get("cookie"));
    request.headers.set("Origin", API_URL);
  }
  return fetch(request);
}

export { handle, handleFetch };
//# sourceMappingURL=hooks.server-D4Fp0OBR.js.map
