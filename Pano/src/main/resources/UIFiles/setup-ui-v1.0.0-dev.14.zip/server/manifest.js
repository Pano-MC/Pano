const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/favicon/android-icon-144x144.png","assets/favicon/android-icon-192x192.png","assets/favicon/android-icon-36x36.png","assets/favicon/android-icon-48x48.png","assets/favicon/android-icon-72x72.png","assets/favicon/android-icon-96x96.png","assets/favicon/apple-icon-114x114.png","assets/favicon/apple-icon-120x120.png","assets/favicon/apple-icon-144x144.png","assets/favicon/apple-icon-152x152.png","assets/favicon/apple-icon-180x180.png","assets/favicon/apple-icon-57x57.png","assets/favicon/apple-icon-60x60.png","assets/favicon/apple-icon-72x72.png","assets/favicon/apple-icon-76x76.png","assets/favicon/apple-icon-precomposed.png","assets/favicon/apple-icon.png","assets/favicon/browserconfig.xml","assets/favicon/favicon-16x16.png","assets/favicon/favicon-32x32.png","assets/favicon/favicon-96x96.png","assets/favicon/favicon.ico","assets/favicon/manifest.json","assets/favicon/ms-icon-144x144.png","assets/favicon/ms-icon-150x150.png","assets/favicon/ms-icon-310x310.png","assets/favicon/ms-icon-70x70.png","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/green.svg","assets/img/logo.svg","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2"]),
	mimeTypes: {".png":"image/png",".xml":"text/xml",".json":"application/json",".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2"},
	_: {
		client: {"start":"_app/immutable/entry/start.Op5BDdcm.js","app":"_app/immutable/entry/app.B_eLRmc4.js","imports":["_app/immutable/entry/start.Op5BDdcm.js","_app/immutable/chunks/jlollrcg.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/entry/app.B_eLRmc4.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/uBxQ3371.js","_app/immutable/chunks/RYNJSc8L.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/DJiSYrUa.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./chunks/0-RK0wzT42.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-Bg_c-y9J.js')),
			__memo(() => import('./chunks/2-D4lUYvQt.js')),
			__memo(() => import('./chunks/3-DgRnZNYI.js')),
			__memo(() => import('./chunks/4-CqhxkvAp.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/5-B5pLGDFt.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/6-BmEo0457.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-34uEKvdz.js').then(function (n) { return n._; }))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/setup-api/languages",
				pattern: /^\/setup-api\/languages\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-J3hjOU-B.js'))
			},
			{
				id: "/setup-api/languages/[language].json",
				pattern: /^\/setup-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-h-GTtCCu.js'))
			},
			{
				id: "/step-1",
				pattern: /^\/step-1\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/step-2",
				pattern: /^\/step-2\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/step-3",
				pattern: /^\/step-3\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/step-4",
				pattern: /^\/step-4\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/[...fallback]",
				pattern: /^(?:\/(.*))?\/?$/,
				params: [{"name":"fallback","optional":false,"rest":true,"chained":true}],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
