import { a1 as writable, a5 as head, a6 as bind_props, t as pop, a7 as slot, a8 as get, p as push, a9 as store_get, aa as unsubscribe_stores, Z as BROWSER, ab as ensure_array_like, ac as stringify } from './index2-DUtmMMEv.js';
import { $ as $format } from './runtime-C9EZ2afN.js';
import { E as ErrorAlert } from './ErrorAlert-D7MDNunu.js';
import { e as escape_html } from './client-BQPmnYFh.js';
import { u as updateApiUrl, A as API_URL, b as CSRF_HEADER } from './variables-CdsVAjOE.js';
import { a as attr } from './attributes-h97WAof2.js';
import { T as ToastContainer } from './ToastContainer-BmTsEGQo.js';
import { i as init } from './language.util-B5FwWhfx.js';
import { r as redirect } from './index3-DyoisQP2.js';

const browser = BROWSER;
function App($$payload, $$props) {
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!---->`;
}
const NETWORK_ERROR = "NETWORK_ERROR";
const ApiUtil = {
  interceptors: {},
  // GET request
  async get({ path, request, csrfToken, token, blob, handler }) {
    return this.customRequest({ path, request, csrfToken, token, blob, handler });
  },
  // POST request
  async post({ path, request, body, headers, csrfToken, token, blob, handler }) {
    return this.customRequest({
      path,
      data: { method: "POST", credentials: "include", body, headers },
      request,
      csrfToken,
      token,
      blob,
      handler
    });
  },
  // PUT request
  async put({ path, request, body, headers, csrfToken, token, blob, handler }) {
    return this.customRequest({
      path,
      data: { method: "PUT", credentials: "include", body, headers },
      request,
      csrfToken,
      token,
      blob,
      handler
    });
  },
  // DELETE request
  async delete({ path, request, headers, csrfToken, token, blob, handler }) {
    return this.customRequest({
      path,
      data: { method: "DELETE", headers },
      request,
      csrfToken,
      token,
      blob,
      handler
    });
  },
  // Custom request handler
  async customRequest({ path, data = {}, request, csrfToken, token, blob, handler }) {
    if (!csrfToken) {
      let session2;
      if (request) {
        const parentData = await request.parent();
        session2 = parentData.session;
      }
      csrfToken = session2 && session2.csrfToken;
    }
    const CSRFHeader = csrfToken ? { [CSRF_HEADER]: csrfToken } : {};
    if (!(data.body instanceof FormData)) {
      data.body = JSON.stringify(data.body);
      data.headers = { "Content-Type": "application/json", ...data.headers };
    }
    const options = {
      ...data,
      headers: { ...data.headers, ...CSRFHeader }
    };
    if (token) {
      options.headers["Authorization"] = `Bearer ${token}`;
    } else if ("credentials" in Request.prototype) {
      options["credentials"] = "include";
    }
    if (request && !get(initialized) || !browser || API_URL.includes(".panomc.com")) {
      const apiUrl = !API_URL.includes(".panomc.com") && true && browser && get(initialized) ? "/api" : API_URL;
      path = `${apiUrl}/${path.replace("/api/", "")}`;
    }
    const bodyHandler = (response) => blob ? response.blob() : response.text();
    const jsonParseHandler = (json) => {
      try {
        return JSON.parse(json);
      } catch (err) {
        return json;
      }
    };
    const requestCall = (rejectHandler) => {
      const fetchMethod = request && request.fetch ? request.fetch(path, options) : fetch(path, options);
      const reject = async (err) => {
        console.log(err);
        if (rejectHandler) {
          throw new Error(err);
        }
        if (!this.interceptors.errorHandler || !handler) {
          return;
        }
        this.interceptors.errorHandler(requestCall);
      };
      return fetchMethod.then(bodyHandler).then(jsonParseHandler).then(async (parsedJson) => handler ? await handler(parsedJson, reject) : parsedJson).catch(reject);
    };
    return requestCall();
  }
};
const session = writable({});
const currentStep = writable(0);
const initialized = writable(false);
function checkRoute(step, pathname) {
  const stepLocation = "/step-" + step;
  if (step === 0 && pathname !== "/") {
    return "/";
  } else if (step !== 0 && pathname !== stepLocation) {
    return stepLocation;
  } else {
    return null;
  }
}
async function checkCurrentStep() {
  return ApiUtil.get({ path: "/api/setup/step" }).then((body) => {
    if (body.error) {
      return { ...body, step: 0 };
    }
    return body;
  }).catch(() => {
    return { error: NETWORK_ERROR, step: 0 };
  });
}
const steps = [
  {
    name: "steps.website.title",
    icon: "fa-solid fa-globe"
  },
  {
    name: "steps.database.title",
    icon: "fa-solid fa-database"
  },
  {
    name: "steps.email.title",
    icon: "fa-solid fa-envelope"
  },
  {
    name: "steps.account.title",
    icon: "fa-solid fa-user"
  }
];
function Navbar($$payload, $$props) {
  push();
  var $$store_subs;
  const each_array = ensure_array_like(steps);
  $$payload.out += `<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent"><ul class="navbar-nav text-lg-center mt-lg-0 mt-2"><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let step = each_array[index];
    $$payload.out += `<li class="nav-item"><a${attr("class", `nav-link ${stringify([
      store_get($$store_subs ??= {}, "$currentStep", currentStep) === index + 1 ? "active" : "",
      store_get($$store_subs ??= {}, "$currentStep", currentStep) > index + 1 ? "link-success" : ""
    ].filter(Boolean).join(" "))}`)}${attr("href", store_get($$store_subs ??= {}, "$currentStep", currentStep) <= index + 1 ? null : "javascript:void(0);")}>`;
    if (store_get($$store_subs ??= {}, "$currentStep", currentStep) > index + 1) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<i class="fa-solid fa-check-circle me-lg-1"></i>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<i${attr("class", `${stringify(step.icon)} me-lg-1`)}></i>`;
    }
    $$payload.out += `<!--]--> ${escape_html(index + 1)}. ${escape_html(store_get($$store_subs ??= {}, "$_", $format)(step.name))}</a></li>`;
  }
  $$payload.out += `<!--]--></ul></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
async function loadServer(input) {
  const {
    url: { pathname },
    locals: { acceptedLanguage, CSRFToken }
  } = input;
  const apiUrlEnv = process.env.API_URL;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  const stepInfo = await checkCurrentStep();
  const { step } = stepInfo;
  const route = checkRoute(step, pathname);
  if (route) {
    throw redirect(302, route);
  }
  return {
    stepInfo,
    acceptedLanguage,
    CSRFToken,
    apiUrlEnv
  };
}
async function load(event) {
  const {
    data,
    data: {
      stepInfo: { step },
      acceptedLanguage,
      CSRFToken,
      apiUrlEnv
    }
  } = event;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
  }
  session.set({ CSRFToken });
  currentStep.set(step);
  await init(acceptedLanguage, event);
  return data;
}
function MainLayout($$payload, $$props) {
  push();
  var $$store_subs;
  let stepInfo = $$props["stepInfo"];
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("title"))}${escape_html(store_get($$store_subs ??= {}, "$currentStep", currentStep) !== 0 ? ` ${store_get($$store_subs ??= {}, "$currentStep", currentStep)}/4` : "")}</title>`;
  });
  App($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<div class="bg-light min-vh-100 bg-light overflow-scroll"><div class="navbar bg-primary navbar-dark navbar-expand-lg"><div class="container"><a href="https://panomc.com" target="_blank" class="navbar-brand"><img alt="Pano" src="/assets/img/logo.svg" class="d-inline-block align-text-top me-2" width="18"> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("title"))}</a> <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fa-solid fa-bars"></i></button> `;
      Navbar($$payload2);
      $$payload2.out += `<!----></div></div> <div class="pt-3"><div class="container">`;
      ErrorAlert($$payload2, { error: stepInfo.error });
      $$payload2.out += `<!----> <div class="card"><div class="card-body"><!---->`;
      slot($$payload2, $$props, "default", {});
      $$payload2.out += `<!----></div></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  ToastContainer($$payload);
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { stepInfo });
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

var _layout_server = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: loadServer
});

const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DKnfTxJv.js')).default;
const universal_id = "src/routes/+layout.js";
const server_id = "src/routes/+layout.server.js";
const imports = ["_app/immutable/nodes/0.BH6ZTXWL.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/CFqJ9rIX.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/RYNJSc8L.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/P2tXwQnl.js","_app/immutable/chunks/DQ6Ef6e0.js","_app/immutable/chunks/jlollrcg.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/DO8W7KWV.js","_app/immutable/chunks/uBxQ3371.js"];
const stylesheets = ["_app/immutable/assets/0.snwUz3Ei.css"];
const fonts = [];

var _0 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  server: _layout_server,
  server_id: server_id,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { MainLayout as M, _0 as _ };
//# sourceMappingURL=0-RK0wzT42.js.map
