import { ad as fallback, a9 as store_get, aa as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ac as stringify } from './index2-DUtmMMEv.js';
import { $ as $format } from './runtime-C9EZ2afN.js';
import { a as attr } from './attributes-h97WAof2.js';
import { e as escape_html } from './client-BQPmnYFh.js';
import { E as ErrorAlert } from './ErrorAlert-D7MDNunu.js';

async function load({ parent }) {
  const { stepInfo: { database } } = await parent();
  return { stepInfo: { database } };
}
function Step2($$payload, $$props) {
  push();
  var $$store_subs;
  let disabled;
  let loading = false;
  let error = null;
  let database = fallback(
    $$props["database"],
    () => ({
      host: "",
      dbName: "",
      username: "",
      password: "",
      prefix: ""
    }),
    true
  );
  disabled = database.host === "" || database.dbName === "" || database.username === "";
  $$payload.out += `<div class="animate__animated animate__fadeIn"><div class="animate__animated animate__slideInUp d-block"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.title"))}</h4> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.description"))}
       </p></div> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> <form><div class="mb-3"><div class="form-check"><input class="form-check-input" type="radio" name="dbMysqlMariaDB" id="dbMysqlMariaDB" checked> <label class="form-check-label" for="dbMysqlMariaDB">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.databases.mysql-or-mariadb"))}</label></div></div> <div class="tab-content"><div aria-labelledby="mysql-tab" class="tab-pane fade show active" id="mysql" role="tabpanel"><div class="row"><div class="col-6"><div class="mb-3"><label for="databaseAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.address"))}</label> <input class="form-control" id="databaseAddress" placeholder="localhost:3306"${attr("value", database.host)} type="text"></div></div> <div class="col-6"><div class="mb-3"><label for="databaseName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.name"))}</label> <input class="form-control" id="databaseName" placeholder="pano"${attr("value", database.dbName)} type="text"></div></div> <div class="w-100"></div> <div class="col-6"><div class="mb-3"><label for="databaseUserName">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.username"))}</label> <input class="form-control" id="databaseUserName" placeholder="root"${attr("value", database.username)} type="text"></div></div> <div class="col-6"><div class="mb-3"><label for="databaseUserPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.password"))}</label> <input class="form-control" id="databaseUserPassword" placeholder="****************"${attr("value", database.password)} type="password"></div></div> <div class="col-12"><div class="mb-3"><label for="databaseTablePrefix">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.database.inputs.prefix"))}</label> <input class="form-control" id="databaseTablePrefix" placeholder="pano_"${attr("value", database.prefix)} type="text"></div></div></div></div></div> <div class="row"><div class="col-6"><a href="javascript:void(0);"${attr("class", `btn btn-link w-100 ${stringify([""].filter(Boolean).join(" "))}`)} role="button"${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</a></div> <div class="col-6"><div class="animate__animated animate__zoomIn"><button type="submit"${attr("class", `btn btn-primary w-100 ${stringify([disabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", disabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.next"))} `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></button></div></div></div></form></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { database });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-hGEkKK13.js')).default;
const universal_id = "src/routes/step-2/+page.js";
const imports = ["_app/immutable/nodes/5.B97qGN41.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/uBxQ3371.js","_app/immutable/chunks/DQ6Ef6e0.js","_app/immutable/chunks/jlollrcg.js","_app/immutable/chunks/B0Z4_C0J.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/DO8W7KWV.js"];
const stylesheets = [];
const fonts = [];

var _5 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Step2 as S, _5 as _ };
//# sourceMappingURL=5-B5pLGDFt.js.map
