import { ae as spread_props, a6 as bind_props, t as pop, p as push } from './index2-DUtmMMEv.js';
import { S as Step1 } from './4-CqhxkvAp.js';
import './attributes-h97WAof2.js';
import './client-BQPmnYFh.js';
import './runtime-C9EZ2afN.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  Step1($$payload, spread_props([data.stepInfo]));
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-K-XFBA-v.js.map
