import { a7 as slot, a6 as bind_props, t as pop, p as push } from './index2-DUtmMMEv.js';
import { M as MainLayout } from './0-RK0wzT42.js';
import './runtime-C9EZ2afN.js';
import './ErrorAlert-D7MDNunu.js';
import './client-BQPmnYFh.js';
import './variables-CdsVAjOE.js';
import './attributes-h97WAof2.js';
import './ToastContainer-BmTsEGQo.js';
import './language.util-B5FwWhfx.js';
import './index3-DyoisQP2.js';

function _layout($$payload, $$props) {
  push();
  let data = $$props["data"];
  MainLayout($$payload, {
    stepInfo: data.stepInfo,
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {});
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { data });
  pop();
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-DKnfTxJv.js.map
