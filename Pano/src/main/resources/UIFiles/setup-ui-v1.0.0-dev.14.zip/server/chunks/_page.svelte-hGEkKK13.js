import { ae as spread_props, a6 as bind_props, t as pop, p as push } from './index2-DUtmMMEv.js';
import { S as Step2 } from './5-B5pLGDFt.js';
import './runtime-C9EZ2afN.js';
import './attributes-h97WAof2.js';
import './client-BQPmnYFh.js';
import './ErrorAlert-D7MDNunu.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  Step2($$payload, spread_props([data.stepInfo]));
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-hGEkKK13.js.map
