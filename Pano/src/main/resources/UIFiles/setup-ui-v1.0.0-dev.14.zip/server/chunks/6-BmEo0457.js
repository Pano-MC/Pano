import { ad as fallback, a9 as store_get, ab as ensure_array_like, aa as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ac as stringify } from './index2-DUtmMMEv.js';
import { $ as $format } from './runtime-C9EZ2afN.js';
import { a as attr } from './attributes-h97WAof2.js';
import { e as escape_html } from './client-BQPmnYFh.js';
import { E as ErrorAlert } from './ErrorAlert-D7MDNunu.js';

function ConfirmSkipSMTPModal($$payload, $$props) {
  push();
  var $$store_subs;
  $$payload.out += `<div aria-hidden="true" class="modal fade" role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-skip-smtp.title"))} <br> <br> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-skip-smtp.description"))}</div> <div class="modal-footer flex-nowrap"><button${attr("class", `btn btn-link col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.cancel"))}</button> <button${attr("class", `btn btn-danger col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.yes"))}</button></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
const defaultMailConfiguration = Object.freeze({
  ssl: true,
  starttls: "DISABLED",
  port: 465,
  authMethods: ""
});
const services = Object.freeze({
  GMAIL: {
    name: "GMail",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.gmail.com",
      port: 587,
      ssl: false,
      starttls: "REQUIRED",
      authMethods: "PLAIN"
    }
  },
  YAHOO: {
    name: "Yahoo",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.mail.yahoo.com"
    }
  },
  YANDEX: {
    name: "Yandex",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.yandex.com",
      port: 465,
      ssl: true,
      starttls: "DISABLED",
      authMethods: "PLAIN"
    }
  },
  MAIL_RU: {
    name: "Mail.ru",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp.mail.ru"
    }
  },
  OUTLOOK: {
    name: "Hotmail / Outlook",
    config: {
      ...defaultMailConfiguration,
      hostname: "smtp-mail.outlook.com",
      port: 587
    }
  },
  OTHER: {
    name: "buttons.other",
    config: { ...defaultMailConfiguration }
  }
});
async function load({ parent }) {
  const { stepInfo } = await parent();
  const { email } = stepInfo;
  const { sender, hostname, username, password, port } = email;
  let chosenService = null;
  if (sender && hostname && username && password && port) {
    Object.keys(services).forEach((service) => {
      const serviceOptions = services[service];
      if (serviceOptions.config.hostname === hostname) {
        chosenService = service;
      }
    });
    if (!chosenService) {
      chosenService = "OTHER";
    }
  }
  const mailConfiguration = { [chosenService]: email };
  return { stepInfo: { mailConfiguration, chosenService } };
}
function Step3($$payload, $$props) {
  push();
  var $$store_subs;
  let disabled;
  let loading = false;
  let error = null;
  let chosenService = $$props["chosenService"];
  let mailConfiguration = fallback($$props["mailConfiguration"], () => ({}), true);
  disabled = !chosenService || chosenService && (!mailConfiguration[chosenService].port || !mailConfiguration[chosenService].sender || !mailConfiguration[chosenService].hostname || !mailConfiguration[chosenService].username || !mailConfiguration[chosenService].password);
  $$payload.out += `<div class="animate__animated animate__fadeIn"><div class="animate__animated animate__slideInUp"><h4>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.title"))}</h4> <p class="text-muted">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.description"))} <br> <a href="#"><i class="fa-solid fa-up-right-from-square me-2"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.help-link-text"))}</a></p></div> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> <form>`;
  if (!chosenService) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(Object.keys(services));
    $$payload.out += `<div class="list-group mb-3"><!--[-->`;
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let service = each_array[index];
      $$payload.out += `<a href="javascript:void(0)" class="list-group-item list-group-item-action">${escape_html(store_get($$store_subs ??= {}, "$_", $format)(services[service].name) || services[service].name)}</a>`;
    }
    $$payload.out += `<!--]--></div>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<div><button class="btn btn-link mb-3 ps-0"><i class="fa-solid fa-arrow-left me-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.return-back-to-service-list-text"))}</button> <h5>${escape_html(store_get($$store_subs ??= {}, "$_", $format)(services[chosenService].name))}</h5> <div class="row"><div class="col-6"><label for="mailUsername">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.username"))}</label> <input class="form-control" id="mailUsername" type="text" placeholder="no-reply"${attr("value", mailConfiguration[chosenService].username)}></div> <div class="col-6"><label for="mailUserPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.password"))}</label> <input class="form-control" id="mailUserPassword" placeholder="****************" type="password"${attr("value", mailConfiguration[chosenService].password)}></div></div> <details><summary class="h6 text-primary my-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.details-button"))}</summary> <div class="row"><div class="col-6 mb-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="ssl" id="ssl"${attr("aria-checked", mailConfiguration[chosenService].ssl)}${attr("checked", mailConfiguration[chosenService].ssl, true)}> <label class="form-check-label" for="ssl">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.ssl"))}</label></div></div> <div class="col-6 mb-3"><label for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.tls-setting"))}</label> <select class="form-select" id="port"><option value="REQUIRED">REQUIRED</option><option value="OPTIONAL">OPTIONAL</option><option value="DISABLED">DISABLED</option></select></div></div> <div class="row"><div class="col-6"><div class="mb-3"><label for="sendingAddress">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.sending-address"))}</label> <input class="form-control" id="sendingAddress" type="text" placeholder="no-reply@forexample.com"${attr("value", mailConfiguration[chosenService].sender)}></div></div> <div class="col-6"><div class="mb-3"><label for="hostname">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.hostname"))}</label> <input class="form-control" id="hostname" type="text" placeholder="smtp.forexample.com"${attr("value", mailConfiguration[chosenService].hostname)}></div></div> <div class="col-6"><div class="mb-3"><label for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.port"))}</label> <input class="form-control" id="port" placeholder="465" type="number"${attr("value", mailConfiguration[chosenService].port)}></div></div> <div class="col-6"><div class="mb-3"><label for="port">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("steps.email.inputs.auth-method"))}</label> <select class="form-select"><option value="PLAIN">PLAIN</option><option value=""></option></select></div></div></div></details></div>`;
  }
  $$payload.out += `<!--]--> <div class="row"><div class="col-4"><a href="javascript:void(0);"${attr("class", `btn btn-link w-100 ${stringify([""].filter(Boolean).join(" "))}`)} role="button"${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.back"))}</a></div> <div class="col-4"><div class="animate__animated animate__zoomIn"><button type="submit"${attr("class", `btn btn-primary w-100 ${stringify([disabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", disabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.next"))} `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></button></div></div> <div class="col-4"><div class="animate__animated animate__zoomIn"><button type="button" class="btn btn-primary w-100"${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("buttons.skip"))}</button></div></div></div></form></div> `;
  ConfirmSkipSMTPModal($$payload);
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { chosenService, mailConfiguration });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-C5wjnt4s.js')).default;
const universal_id = "src/routes/step-3/+page.js";
const imports = ["_app/immutable/nodes/6.BwUgAH84.js","_app/immutable/chunks/Bg9kRutz.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/noqyDyOK.js","_app/immutable/chunks/DignW2MP.js","_app/immutable/chunks/uBxQ3371.js","_app/immutable/chunks/C8AaKYL3.js","_app/immutable/chunks/DQ6Ef6e0.js","_app/immutable/chunks/jlollrcg.js","_app/immutable/chunks/DO8W7KWV.js","_app/immutable/chunks/CwSCbk6-.js","_app/immutable/chunks/B0Z4_C0J.js","_app/immutable/chunks/BOOAI_wx.js","_app/immutable/chunks/DJiSYrUa.js"];
const stylesheets = [];
const fonts = [];

var _6 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Step3 as S, _6 as _ };
//# sourceMappingURL=6-BmEo0457.js.map
