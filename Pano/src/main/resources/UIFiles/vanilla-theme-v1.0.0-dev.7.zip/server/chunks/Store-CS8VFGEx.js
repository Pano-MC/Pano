import { a1 as writable } from './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import { r as redirect } from './index2-DzcLzHBX.js';

const notificationsCount = writable(0);
const quickNotifications = writable([]);
function requireLogin(session) {
  if (!session.user) {
    throw redirect(302, "/");
  }
}
function requireNotLogin(session) {
  if (session.user) {
    throw redirect(302, "/");
  }
}

export { requireNotLogin as a, notificationsCount as n, quickNotifications as q, requireLogin as r };
//# sourceMappingURL=Store-CS8VFGEx.js.map
