import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { S as Support } from './19-RwtwhAc5.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Sidebar-BJnCaXJE.js';
import './attributes-JZZbhxX3.js';
import './OnlineAdmins-BRQUy31Y.js';
import './client-CjlfgChI.js';
import './api.util-CuUZCKFT.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Support($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CiXIDPIH.js.map
