import { a6 as bind_props, t as pop, a8 as store_get, a9 as unsubscribe_stores, a1 as writable, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { e as error } from './index2-DzcLzHBX.js';
import { o as onDestroy } from './index-server-ClX78Gki.js';
import { S as Sidebar } from './Sidebar-BJnCaXJE.js';
import { P as PlayerHead, a as PlayerPermissionBadge } from './PlayerHead-76jvL1tB.js';
import { A as ApiUtil } from './api.util-CuUZCKFT.js';
import { g as getPlayerProfile } from './profile2-DoGqhlRR.js';

const data = writable({
  username: "",
  lastActivityTime: 0,
  inGame: false,
  permissionGroupName: ""
});
const load$1 = async (event) => {
  data.set({
    ...await ApiUtil.get({
      path: `/api/sidebar/profile/${event.params.player}`,
      request: event
    }),
    username: event.params.player
  });
};
String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};
function PlayerProfileSidebar($$payload, $$props) {
  push();
  var $$store_subs;
  let checkTime = 0;
  let interval;
  let side = $$props["side"];
  onDestroy(() => {
    clearInterval(interval);
  });
  Sidebar($$payload, {
    side,
    children: ($$payload2) => {
      $$payload2.out += `<div class="mb-3"><div class="card"><div class="card-body">`;
      PlayerHead($$payload2, {
        username: store_get($$store_subs ??= {}, "$data", data).username,
        inGame: store_get($$store_subs ??= {}, "$data", data).inGame,
        lastActivityTime: store_get($$store_subs ??= {}, "$data", data).lastActivityTime,
        checkTime
      });
      $$payload2.out += `<!----> <div class="text-center"><h2 class="my-3">${escape_html(store_get($$store_subs ??= {}, "$data", data).username)}</h2> `;
      PlayerPermissionBadge($$payload2, {
        permissionGroupName: store_get($$store_subs ??= {}, "$data", data).permissionGroupName
      });
      $$payload2.out += `<!----></div></div></div></div>`;
    },
    $$slots: { default: true }
  });
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { side });
  pop();
}
async function load(event) {
  const { parent } = event;
  await parent();
  let data2 = { registerDate: 0 };
  await load$1(event);
  await getPlayerProfile({ username: event.params.player, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data2 = body;
  });
  return {
    ...data2,
    sidebar: PlayerProfileSidebar,
    sidebarProps: { side: "left" }
  };
}
function PlayerProfile($$payload, $$props) {
  push();
  var $$store_subs;
  let data2 = $$props["data"];
  $$payload.out += `<div class="card"><div class="card-body"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.title"))}</h4> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.player-profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data2.registerDate });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data: data2 });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bp1vl4Um.js')).default;
const universal_id = "src/routes/player/[player]/+page.js";
const imports = ["_app/immutable/nodes/13.D802m_uc.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/XOTkkbjc.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/Do-bE442.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DGl33Lg4.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/CdPHUYSi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/DlmtR6FS.js","_app/immutable/chunks/C_PXdWx8.js"];
const stylesheets = [];
const fonts = [];

var _13 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PlayerProfile as P, _13 as _ };
//# sourceMappingURL=13-DS15Jlqk.js.map
