import { a7 as slot, t as pop, p as push } from './index3-CeMfA1rb.js';
import { r as requireLogin } from './Store-CS8VFGEx.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CxfLbKQT.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.DUENTeEd.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/A1ycbPAZ.js","_app/immutable/chunks/CU-6D5d6.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/XOTkkbjc.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-CPc2ZiXy.js.map
