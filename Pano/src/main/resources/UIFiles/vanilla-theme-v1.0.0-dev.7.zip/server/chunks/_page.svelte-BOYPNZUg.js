import { a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { P as PreviewPost } from './14-DRkNNiQO.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './posts2-fW31uJh6.js';
import './client-CjlfgChI.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './attributes-JZZbhxX3.js';
import './html-FW6Ia4bL.js';
import './api.util-CuUZCKFT.js';

function _page($$payload, $$props) {
  push();
  let data = $$props["data"];
  PreviewPost($$payload, { post: data.post });
  bind_props($$props, { data });
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BOYPNZUg.js.map
