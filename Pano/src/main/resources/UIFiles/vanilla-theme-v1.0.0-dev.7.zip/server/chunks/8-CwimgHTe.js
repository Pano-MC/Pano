import { l as load } from './CategoryPosts-Crt_gHV_.js';
import './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-B9Bbjo11.js';
import './posts2-fW31uJh6.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './html-FW6Ia4bL.js';
import './api.util-CuUZCKFT.js';
import './NoContent-CRKA6SSq.js';
import './index2-DzcLzHBX.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DlYnIWLU.js')).default;
const universal_id = "src/routes/blog/category/[url]/+page.js";
const imports = ["_app/immutable/nodes/8.DYeGikJk.js","_app/immutable/chunks/CBvN_8MH.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/DIaY-ief.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/DEtv9G4I.js","_app/immutable/chunks/CdPHUYSi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/C_PXdWx8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/XOTkkbjc.js","_app/immutable/chunks/B6LQiLNF.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DOhUzxnr.js","_app/immutable/chunks/YgMChgau.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=8-CwimgHTe.js.map
