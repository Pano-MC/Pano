import { a8 as store_get, a9 as unsubscribe_stores, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { S as SuccessAlert } from './SuccessAlert-xdL2cry4.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as requireNotLogin } from './Store-CS8VFGEx.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireNotLogin(session);
}
function ResetPassword($$payload, $$props) {
  push();
  var $$store_subs;
  let error;
  let message;
  let usernameOrEmail = "";
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.title"))}</h3> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message });
  $$payload.out += `<!----> <form><p>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.description"))}</p> <div class="mb-3"><div class="form-group"><input type="text"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.inputs.email-username.placeholder"))} id="email" class="form-control"${attr("value", usernameOrEmail)}></div></div> <button type="submit"${attr("class", `btn btn-primary w-100 ${stringify([""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.reset-password.reset-password-button"))}</button></form></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 18;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-B4o7nkQ0.js')).default;
const universal_id = "src/routes/reset-password/+page.js";
const imports = ["_app/immutable/nodes/18.C47NJ23R.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/V7Lq0j5Y.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/A1ycbPAZ.js","_app/immutable/chunks/CU-6D5d6.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/XOTkkbjc.js","_app/immutable/chunks/DFPvpobi.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/BumJ9SR4.js","_app/immutable/chunks/D-8kYPrx.js"];
const stylesheets = [];
const fonts = [];

var _18 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ResetPassword as R, _18 as _ };
//# sourceMappingURL=18-B81mQCdP.js.map
