import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { A as Activate } from './6-C10fIBUv.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import './ErrorAlert-DidMNNkl.js';
import './SuccessAlert-xdL2cry4.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Activate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DGRL8DEJ.js.map
