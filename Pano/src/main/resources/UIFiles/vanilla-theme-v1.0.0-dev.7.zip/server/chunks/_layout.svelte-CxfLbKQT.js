import { a7 as slot } from './index3-CeMfA1rb.js';
import { P as ProfileLayout } from './2-CPc2ZiXy.js';
import './Store-CS8VFGEx.js';
import './client-CjlfgChI.js';
import './index2-DzcLzHBX.js';

function _layout($$payload, $$props) {
  ProfileLayout($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-CxfLbKQT.js.map
