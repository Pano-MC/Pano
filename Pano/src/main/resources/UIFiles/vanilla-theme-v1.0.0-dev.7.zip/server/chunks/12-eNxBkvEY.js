import { a1 as writable, ae as get, ac as ensure_array_like, a8 as store_get, ab as stringify, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { o as onDestroy } from './index-server-ClX78Gki.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { l as locales, c as currentLanguage } from './language.util-BT90rPTb.js';
import './client-CjlfgChI.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { N as NoContent } from './NoContent-CRKA6SSq.js';
import { A as ApiUtil } from './api.util-CuUZCKFT.js';
import { r as requireLogin } from './Store-CS8VFGEx.js';
import { f as formatDistanceToNow } from './formatDistanceToNow-B3jPtEFp.js';

const dialogID = "confirmDeleteAllNotifications";
function ConfirmRemoveAllNotificationsModal($$payload, $$props) {
  push();
  var $$store_subs;
  let loading;
  $$payload.out += `<div aria-hidden="true" class="modal fade"${attr("id", dialogID)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-all-notifications.title"))}</div> <div class="modal-footer flex-nowrap"><button${attr("class", `btn btn-link col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-all-notifications.cancel-button"))}</button> <button${attr("class", `btn btn-danger col-6 m-0 ${stringify([""].filter(Boolean).join(" "))}`)} type="button"${attr("aria-disabled", loading)}${attr("disabled", loading, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("components.modals.confirm-remove-all-notifications.yes-button"))}</button></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
const notifications = writable([]);
const count = writable(0);
Array.prototype.insert = function(index, item) {
  this.splice(index, 0, item);
  return this;
};
Array.prototype.remove = function(index) {
  this.splice(index, 1);
  return this;
};
function setNotifications(newNotifications) {
  if (get(notifications).length === 0 || newNotifications.length === 0) notifications.set(newNotifications);
  else {
    const listOfFilterIsNotificationExists = [];
    newNotifications.forEach((item, index) => {
      listOfFilterIsNotificationExists[index] = get(notifications).filter((filterItem) => filterItem.id === item.id);
    });
    newNotifications.forEach((item, index) => {
      if (listOfFilterIsNotificationExists[index].length === 0) {
        notifications.set(get(notifications).insert(index, item));
      }
    });
  }
}
async function loadData({ request }) {
  return new Promise((resolve, reject) => {
    ApiUtil.get({ path: "/api/notifications", request }).then((body) => {
      if (body.result === "ok") {
        resolve(body);
      } else {
        reject(body);
      }
    });
  });
}
async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  let data = {};
  await loadData({ request: event }).then((body) => {
    setNotifications(body.notifications);
    count.set(parseInt(body.notificationCount));
  });
  return data;
}
function Notifications($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let page = 0;
  let checkTime = 0;
  let interval;
  function stopNotificationsCountdown() {
    clearInterval(interval);
  }
  function getTime(check, time, locale) {
    return formatDistanceToNow(time, { addSuffix: true, locale });
  }
  onDestroy(() => {
    stopNotificationsCountdown();
  });
  const each_array = ensure_array_like(store_get($$store_subs ??= {}, "$notifications", notifications));
  $$payload.out += `<div class="container"><div class="row justify-content-end mb-3 animate__animated animate__slideInUp">`;
  if (store_get($$store_subs ??= {}, "$notifications", notifications).length !== 0) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="col-auto"><button type="button" class="btn btn-danger">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.delete-all-button"))}</button></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div> <div class="card"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("navbar.notifications.title"))}</h3> <!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let notification = each_array[index];
    $$payload.out += `<div class="list-group list-group-flush"><a href="javascript:void(0);"${attr("class", `list-group-item list-group-item-action ${stringify([
      notification.status === "NOT_READ" ? "notification-unread" : ""
    ].filter(Boolean).join(" "))}`)}><span class="text-wrap">${escape_html(notification.type)}</span> <br> <small class="text-muted">${escape_html(getTime(checkTime, parseInt(notification.date), locales[store_get($$store_subs ??= {}, "$currentLanguage", currentLanguage)["date-fns-code"]]))}</small></a> <button class="btn-close btn-sm mx-2"></button></div>`;
  }
  $$payload.out += `<!--]--> `;
  if (store_get($$store_subs ??= {}, "$notifications", notifications).length === 0) {
    $$payload.out += "<!--[-->";
    NoContent($$payload, {});
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  if (store_get($$store_subs ??= {}, "$notifications", notifications).length < store_get($$store_subs ??= {}, "$count", count) && store_get($$store_subs ??= {}, "$count", count) > 10 + 10 * page) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="mt-3"><button${attr("class", `btn btn-link bg-light d-block m-auto ${stringify([""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.notifications.show-more", {
      values: {
        count: store_get($$store_subs ??= {}, "$count", count) - store_get($$store_subs ??= {}, "$notifications", notifications).length
      }
    }))}</button></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></div></div> `;
  ConfirmRemoveAllNotificationsModal($$payload);
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DAEVELXO.js')).default;
const universal_id = "src/routes/notifications/+page.js";
const imports = ["_app/immutable/nodes/12.CJXOTtvS.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/CdPHUYSi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/A1ycbPAZ.js","_app/immutable/chunks/CU-6D5d6.js","_app/immutable/chunks/XOTkkbjc.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/DuczrZ_N.js","_app/immutable/chunks/YgMChgau.js","_app/immutable/chunks/COJ40m7V.js"];
const stylesheets = [];
const fonts = [];

var _12 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Notifications as N, _12 as _ };
//# sourceMappingURL=12-eNxBkvEY.js.map
