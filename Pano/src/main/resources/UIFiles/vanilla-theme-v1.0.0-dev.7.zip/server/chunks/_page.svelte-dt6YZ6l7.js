import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { T as Tickets_1 } from './Tickets-DwoihBTL.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './Tickets2-Cv4TuCBM.js';
import './TicketStatus-BMYXH4rp.js';
import './api.util-CuUZCKFT.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './NoContent-CRKA6SSq.js';
import './ProfileSidebar-BWKbIpLd.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Tickets_1($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-dt6YZ6l7.js.map
