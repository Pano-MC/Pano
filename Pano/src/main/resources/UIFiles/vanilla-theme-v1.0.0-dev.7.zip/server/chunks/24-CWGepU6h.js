import { l as load } from './Tickets-DwoihBTL.js';
import './index3-CeMfA1rb.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './Tickets2-Cv4TuCBM.js';
import './TicketStatus-BMYXH4rp.js';
import './api.util-CuUZCKFT.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './NoContent-CRKA6SSq.js';
import './ProfileSidebar-BWKbIpLd.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 24;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-dt6YZ6l7.js')).default;
const universal_id = "src/routes/tickets/all/[page]/+page.js";
const imports = ["_app/immutable/nodes/24.Cs08YCga.js","_app/immutable/chunks/CcfIpI4r.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/Ctb1SxL5.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/5-OYZ9KP.js","_app/immutable/chunks/CdPHUYSi.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/pRcyVsfG.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/A1ycbPAZ.js","_app/immutable/chunks/CU-6D5d6.js","_app/immutable/chunks/XOTkkbjc.js","_app/immutable/chunks/DGl33Lg4.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/Do-bE442.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Mq3_-Rt6.js","_app/immutable/chunks/B6LQiLNF.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/DDxTVlOt.js","_app/immutable/chunks/C_PXdWx8.js","_app/immutable/chunks/YgMChgau.js","_app/immutable/chunks/Cw4alevl.js","_app/immutable/chunks/DFPvpobi.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=24-CWGepU6h.js.map
