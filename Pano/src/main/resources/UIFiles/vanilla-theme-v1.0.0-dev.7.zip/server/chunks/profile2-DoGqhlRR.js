import { A as ApiUtil } from './api.util-CuUZCKFT.js';

const getProfile = async ({ request }) => {
  return ApiUtil.get({
    path: `/api/profile`,
    request
  });
};
const getPlayerProfile = async ({ request, username }) => {
  return ApiUtil.get({
    path: `/api/profile/${username}`,
    request
  });
};

export { getProfile as a, getPlayerProfile as g };
//# sourceMappingURL=profile2-DoGqhlRR.js.map
