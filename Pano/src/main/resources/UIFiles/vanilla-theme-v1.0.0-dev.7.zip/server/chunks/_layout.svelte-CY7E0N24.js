import { a6 as bind_props, a7 as slot } from './index3-CeMfA1rb.js';
import { M as MainLayout } from './0-CYzALHPH.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './client-CjlfgChI.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-JZZbhxX3.js';
import './api.util-CuUZCKFT.js';
import './Store-CS8VFGEx.js';
import './index2-DzcLzHBX.js';
import './NoContent-CRKA6SSq.js';
import './language.util-BT90rPTb.js';
import './html-FW6Ia4bL.js';
import './ErrorAlert-DidMNNkl.js';
import './SuccessAlert-xdL2cry4.js';
import 'fs';
import './paths-CYDIOyak.js';
import './formatDistanceToNow-B3jPtEFp.js';

function _layout($$payload, $$props) {
  let data = $$props["data"];
  MainLayout($$payload, {
    data,
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-CY7E0N24.js.map
