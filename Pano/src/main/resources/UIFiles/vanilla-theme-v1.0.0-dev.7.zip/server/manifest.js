const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/green.svg","assets/img/minecraft-logo.png","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".txt":"text/plain"},
	_: {
		client: {"start":"_app/immutable/entry/start.BuKYecuy.js","app":"_app/immutable/entry/app.DCx98Jcx.js","imports":["_app/immutable/entry/start.BuKYecuy.js","_app/immutable/chunks/CTCo4EUB.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/entry/app.DCx98Jcx.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/DVZbAeNi.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/y1LDglf1.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./chunks/0-CYzALHPH.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-Dj1COSc5.js')),
			__memo(() => import('./chunks/2-CPc2ZiXy.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/3-Blowotcm.js')),
			__memo(() => import('./chunks/4-TR07PCw7.js')),
			__memo(() => import('./chunks/5-B9WZF0vM.js')),
			__memo(() => import('./chunks/6-C10fIBUv.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-B4eRsuOv.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/8-CwimgHTe.js')),
			__memo(() => import('./chunks/9-CAndNtt6.js')),
			__memo(() => import('./chunks/10-D6Bnv53E.js')),
			__memo(() => import('./chunks/11-BXo_BCq8.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/12-eNxBkvEY.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/13-DS15Jlqk.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/14-DRkNNiQO.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-C7sZIfWs.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/16-TxqeLaBP.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/17-COMFiqn7.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-B81mQCdP.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/19-RwtwhAc5.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/20-CcpLVN0l.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/21-DgI6_dft.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/22-DNK5XAFt.js')),
			__memo(() => import('./chunks/23-DPfEvtCp.js')),
			__memo(() => import('./chunks/24-CWGepU6h.js')),
			__memo(() => import('./chunks/25-BsHi3GXO.js')),
			__memo(() => import('./chunks/26-BxABnbRr.js')),
			__memo(() => import('./chunks/27-DKG9Jvsv.js')),
			__memo(() => import('./chunks/28-DmmLaB-D.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/activate-new-email",
				pattern: /^\/activate-new-email\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/activate",
				pattern: /^\/activate\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]",
				pattern: /^\/blog\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]/[page]",
				pattern: /^\/blog\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/blog/page/[page]",
				pattern: /^\/blog\/page\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/blog/post/[url]",
				pattern: /^\/blog\/post\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/player/[player]",
				pattern: /^\/player\/([^/]+?)\/?$/,
				params: [{"name":"player","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Duh1hDwD.js'))
			},
			{
				id: "/preview/post/[id]",
				pattern: /^\/preview\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/profile/settings",
				pattern: /^\/profile\/settings\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/renew-password",
				pattern: /^\/renew-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/reset-password",
				pattern: /^\/reset-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/support",
				pattern: /^\/support\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/tickets/all",
				pattern: /^\/tickets\/all\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/tickets/all/[page]",
				pattern: /^\/tickets\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]",
				pattern: /^\/tickets\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]/[page]",
				pattern: /^\/tickets\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/tickets/closed",
				pattern: /^\/tickets\/closed\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/tickets/closed/[page]",
				pattern: /^\/tickets\/closed\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/ticket/create",
				pattern: /^\/ticket\/create\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/ticket/[id]",
				pattern: /^\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 20 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
