import{a as t}from"../chunks/CTCo4EUB.js";export{t as start};
