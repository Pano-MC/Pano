import{b as a}from"../chunks/entry.sKhlU6D7.js";export{a as start};
