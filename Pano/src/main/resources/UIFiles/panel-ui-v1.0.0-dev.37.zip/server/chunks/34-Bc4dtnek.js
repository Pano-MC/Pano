import { c as create_ssr_component, a as subscribe, f as getContext, e as escape, d as add_attribute, h as each } from './ssr-ffuobYCI.js';
import './client-CnCRRyPd.js';
import { d as buildQueryParams, b as ApiUtil } from './api.util-3BDArkra.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './ToastContainer-D6cKqDaa.js';

async function load(event) {
  const { parent } = event;
  await parent();
  const queryParams = buildQueryParams({ type: "WEBSITE" });
  const body = await ApiUtil.get({
    path: "/api/panel/settings" + queryParams,
    request: event
  });
  body.oldSettings = { ...body };
  body.oldSettings.keywords = [...body.keywords];
  return body;
}
const SiteSettings = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let isSaveButtonDisabled;
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { data } = $$props;
  const pageTitle = getContext("pageTitle");
  getContext("website");
  pageTitle.set("pages.settings.site-settings.title");
  let faviconFiles = [];
  let websiteLogoFiles = [];
  let keyword;
  let favicon = "/api/favicon";
  let websiteLogo = "/api/websiteLogo";
  Array.prototype.equals = function(array) {
    if (!array) return false;
    if (this.length != array.length) return false;
    for (let i = 0, l = this.length; i < l; i++) {
      if (this[i] instanceof Array && array[i] instanceof Array) {
        if (!this[i].equals(array[i])) return false;
      } else if (this[i] != array[i]) {
        return false;
      }
    }
    return true;
  };
  Object.defineProperty(Array.prototype, "equals", { enumerable: false });
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  isSaveButtonDisabled = data.oldSettings.websiteName === data.websiteName && data.oldSettings.websiteDescription === data.websiteDescription && data.oldSettings.supportEmail === data.supportEmail && data.oldSettings.serverIpAddress === data.serverIpAddress && data.oldSettings.serverGameVersion === data.serverGameVersion && JSON.stringify(data.oldSettings.keywords) === JSON.stringify(data.keywords) && faviconFiles.length === 0 && websiteLogoFiles.length === 0;
  $$unsubscribe__();
  return ` <div class="card"><div class="card-body animate__animated animate__fadeIn"><h5 class="card-title">${escape($_("pages.settings.site-settings.preferences"))}</h5> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteTitle">${escape($_("pages.settings.site-settings.inputs.website-name.label"))}</label> <div class="col-md-6"><input aria-describedby="siteTitle" class="form-control"${add_attribute("placeholder", $_("pages.settings.site-settings.inputs.website-name.placeholder"), 0)} id="siteTitle" type="text"${add_attribute("value", data.websiteName, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteDesc">${escape($_("pages.settings.site-settings.inputs.website-description.label"))}</label> <div class="col-md-6"><textarea aria-describedby="siteDesc" class="form-control" id="siteDesc" rows="2">${escape(data.websiteDescription || "")}</textarea></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="ipAddress">${escape($_("pages.settings.site-settings.inputs.game-server-ip-address.label"))}</label> <div class="col-md-6"><input id="ipAddress" class="form-control" placeholder="play.server.com" type="text" name="ipAddress"${add_attribute("value", data.serverIpAddress, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="serverGameVersion">${escape($_("pages.settings.site-settings.inputs.game-server-version.label"))}</label> <div class="col-md-6"><input id="serverGameVersion" class="form-control" placeholder="1.8.x" type="text" name="serverGameVersion"${add_attribute("value", data.serverGameVersion, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="supportEmailAddress">${escape($_("pages.settings.site-settings.inputs.support-email-address.label"))}</label> <div class="col-md-6"><input id="supportEmailAddress" class="form-control" placeholder="${"support@" + escape(data.websiteName, true) + ".com"}" type="email" name="supportEmailAddress"${add_attribute("value", data.supportEmail, 0)}></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteKeywords">${escape($_("pages.settings.site-settings.inputs.keywords.label"))}</label> <div class="col-md-6"><form><input id="siteKeywords" class="${["form-control mb-3", ""].join(" ").trim()}"${add_attribute("placeholder", $_("pages.settings.site-settings.inputs.keywords.placeholder"), 0)} type="text" name="keyword"${add_attribute("value", keyword, 0)}></form> ${each(data.keywords, (keyword2, index) => {
    return `<a href="javascript:void(0);"><span class="badge rounded-pill bg-light link-primary">${escape(keyword2)}</span> </a>`;
  })}</div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteFavicon">${escape($_("pages.settings.site-settings.inputs.favicon.label"))}</label> <div class="col-md-6 vstack gap-2"><img${add_attribute("alt", $_("pages.settings.site-settings.inputs.favicon.select"), 0)} width="48" height="48"${add_attribute("src", favicon, 0)}> <input class="form-control-file" id="siteFavicon" type="file" value=""> <small class="text-muted">${escape($_("pages.settings.site-settings.inputs.favicon.helper"))}</small></div></div> <div class="row mb-3"><label class="col-md-6 col-form-label" for="siteLogo">${escape($_("pages.settings.site-settings.inputs.website-logo.label"))}</label> <div class="col-md-6 vstack gap-2"><img${add_attribute("alt", $_("pages.settings.site-settings.inputs.website-logo.server-icon"), 0)} class="img-fluid w-50 h-50"${add_attribute("src", websiteLogo, 0)}> <input class="form-control-file" id="siteLogo" type="file" value=""> <small class="text-muted">${escape($_("pages.settings.site-settings.inputs.website-logo.helper"))}</small></div></div> <button class="${[
    "btn btn-secondary",
    isSaveButtonDisabled ? "disabled" : ""
  ].join(" ").trim()}"${add_attribute("aria-disabled", isSaveButtonDisabled, 0)}>${escape($_("pages.settings.site-settings.save-button"))}</button></div> </div>`;
});

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 34;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bt_997Mb.js')).default;
const universal_id = "src/routes/settings/+page.js";
const imports = ["_app/immutable/nodes/34.Ct5iIjnt.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/each.7qmey8kb.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/tooltip.util.BQd-ItH5.js","_app/immutable/chunks/stores.bjwkuNUk.js","_app/immutable/chunks/entry.sKhlU6D7.js","_app/immutable/chunks/paths.C0Js9hTM.js","_app/immutable/chunks/api.util.Q4LyTz38.js","_app/immutable/chunks/runtime.35C4piRj.js","_app/immutable/chunks/Store.BJoKFTkz.js","_app/immutable/chunks/ToastContainer.C8EEizNN.js"];
const stylesheets = [];
const fonts = [];

var _34 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { SiteSettings as S, _34 as _ };
//# sourceMappingURL=34-Bc4dtnek.js.map
