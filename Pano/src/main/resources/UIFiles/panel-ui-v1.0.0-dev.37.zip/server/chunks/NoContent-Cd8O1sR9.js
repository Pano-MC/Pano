import { c as create_ssr_component, a as subscribe, d as add_attribute, e as escape } from './ssr-ffuobYCI.js';
import { $ as $format } from './runtime-DMBi37QM.js';

const NoContent = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $_, $$unsubscribe__;
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  let { dark = false } = $$props;
  let { icon = "fa-solid fa-ghost fa-3x" } = $$props;
  let { text = $_("components.no-content.here-is-empty") } = $$props;
  if ($$props.dark === void 0 && $$bindings.dark && dark !== void 0) $$bindings.dark(dark);
  if ($$props.icon === void 0 && $$bindings.icon && icon !== void 0) $$bindings.icon(icon);
  if ($$props.text === void 0 && $$bindings.text && text !== void 0) $$bindings.text(text);
  $$unsubscribe__();
  return `${dark ? `<div class="card border-0 opacity-50 bg-transparent animate__animated animate__zoomIn" data-bs-theme="dark"><div class="card-body vstack gap-3 text-center"><span${add_attribute("class", icon, 0)}></span> <p>${escape(text)}</p></div></div>` : `<div class="card border-0 opacity-50 bg-transparent animate__animated animate__zoomIn"><div class="card-body vstack gap-3 text-center"><span${add_attribute("class", icon, 0)}></span> <p>${escape(text)}</p></div></div>`} ${slots.default ? slots.default({}) : ``}`;
});

export { NoContent as N };
//# sourceMappingURL=NoContent-Cd8O1sR9.js.map
