const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CfyWTmuf.js')).default;
const imports = ["_app/immutable/nodes/8.BfqqGAIZ.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/runtime.35C4piRj.js","_app/immutable/chunks/entry.sKhlU6D7.js","_app/immutable/chunks/paths.C0Js9hTM.js","_app/immutable/chunks/stores.bjwkuNUk.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-BlIQO54n.js.map
