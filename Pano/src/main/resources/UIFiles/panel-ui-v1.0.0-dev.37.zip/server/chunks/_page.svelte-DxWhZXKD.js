import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { T as Tickets } from './39-BrlihUfN.js';
import './index-DzcLzHBX.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './paths-C6LjEmZF.js';
import './Pagination--ODwq86l.js';
import './ToastContainer-D6cKqDaa.js';
import './Date-CO7kc4Oc.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './language.util-2VlJt8zV.js';
import './format-DZNhO2Yc.js';
import './TicketStatusBadge-BiE81nbk.js';
import './NoContent-Cd8O1sR9.js';
import './PageActions-EhVg4ruf.js';
import './CardHeader-npnb-NGS.js';
import './CardFilters-CshGiVuB.js';
import './CardMenuItem-BPNNofjf.js';
import './stores-BDx4Az-R.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Tickets, "Tickets").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-DxWhZXKD.js.map
