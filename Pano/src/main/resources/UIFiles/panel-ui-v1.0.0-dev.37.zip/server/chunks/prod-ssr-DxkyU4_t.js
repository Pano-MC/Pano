const BROWSER = false;
const DEV = false;

export { BROWSER as B, DEV as D };
//# sourceMappingURL=prod-ssr-DxkyU4_t.js.map
