import { C as COOKIE_PREFIX, J as JWT_COOKIE_NAME, a as CSRF_TOKEN_COOKIE_NAME, A as API_URL, b as ApiUtil, n as networkErrorBody, u as updateApiUrl } from './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';

async function fetchBasicData(token, csrfToken) {
  return ApiUtil.get({ path: "/api/panel/basicData", token, csrfToken }).catch(
    () => networkErrorBody
  );
}
async function handle({ event, event: { cookies }, resolve }) {
  const locals = {};
  const apiUrlEnv = process.env.API_URL;
  if (apiUrlEnv) {
    updateApiUrl(apiUrlEnv);
    locals.apiUrlEnv = apiUrlEnv;
  }
  const jwt = cookies.get([COOKIE_PREFIX + JWT_COOKIE_NAME]);
  const csrfToken = cookies.get([COOKIE_PREFIX + CSRF_TOKEN_COOKIE_NAME]);
  locals.basicData = await fetchBasicData(jwt, csrfToken);
  locals.jwt = jwt;
  locals.csrfToken = csrfToken;
  event.locals = locals;
  return resolve(event);
}
async function handleFetch({ event, request, fetch }) {
  if (request.url.startsWith(API_URL)) {
    request.headers.set("cookie", event.request.headers.get("cookie"));
    request.headers.set("Origin", API_URL);
  }
  return fetch(request);
}

export { handle, handleFetch };
//# sourceMappingURL=hooks.server-nj4lDMqW.js.map
