import { c as create_ssr_component, v as validate_component, a as subscribe, d as add_attribute, e as escape } from './ssr-ffuobYCI.js';
import { h as hasPermission, P as Permissions } from './auth.util-BRaxc5Jt.js';
import { r as redirect } from './index-DzcLzHBX.js';
import { w as writable } from './index2-Dyghn50Q.js';
import { $ as $format } from './runtime-DMBi37QM.js';
import './client-CnCRRyPd.js';
import './ToastContainer-D6cKqDaa.js';

const dialogID = "confirmDeletePost";
const post = writable({});
const ConfirmDeletePostModal = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $post, $$unsubscribe_post;
  let $_, $$unsubscribe__;
  $$unsubscribe_post = subscribe(post, (value) => $post = value);
  $$unsubscribe__ = subscribe($format, (value) => $_ = value);
  $$unsubscribe_post();
  $$unsubscribe__();
  return ` <div aria-hidden="true" class="modal fade"${add_attribute("id", dialogID, 0)} role="dialog" tabindex="-1"><div class="modal-dialog modal-dialog-centered" role="dialog"><div class="modal-content"><div class="modal-body text-center"><div class="pb-3" data-svelte-h="svelte-1gbw96z"><i class="fas fa-question-circle fa-3x d-block m-auto text-gray"></i></div> ${escape($post.status === 0 ? $_("components.modals.confirm-delete-post.title-permanent") : $_("components.modals.confirm-delete-post.title-trash"))}</div> <div class="modal-footer flex-nowrap"><button class="${["btn btn-link col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-post.cancel"))}</button> <button class="${["btn btn-danger col-6 m-0", ""].join(" ").trim()}" type="button">${escape($_("components.modals.confirm-delete-post.yes"))}</button></div></div></div> </div>`;
});
async function load({ parent }) {
  const parentData = await parent();
  const { user } = parentData;
  if (!hasPermission(Permissions.MANAGE_POSTS, user)) {
    throw redirect(302, "/");
  }
  return parentData;
}
const PostsLayout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``} ${validate_component(ConfirmDeletePostModal, "ConfirmDeletePostModal").$$render($$result, {}, {}, {})}`;
});

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-B_qkZ9VZ.js')).default;
const universal_id = "src/routes/posts/+layout.js";
const imports = ["_app/immutable/nodes/6.0-HvJ7nW.js","_app/immutable/chunks/scheduler.oms-ZPPC.js","_app/immutable/chunks/index.Bz-hK21W.js","_app/immutable/chunks/auth.util.C1A5ePmg.js","_app/immutable/chunks/stores.bjwkuNUk.js","_app/immutable/chunks/entry.sKhlU6D7.js","_app/immutable/chunks/paths.C0Js9hTM.js","_app/immutable/chunks/index.BPCY7PwU.js","_app/immutable/chunks/ConfirmDeletePostModal.EmOdTZ7Z.js","_app/immutable/chunks/runtime.35C4piRj.js","_app/immutable/chunks/api.util.Q4LyTz38.js","_app/immutable/chunks/ToastContainer.C8EEizNN.js","_app/immutable/chunks/each.7qmey8kb.js"];
const stylesheets = [];
const fonts = [];

var _6 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { PostsLayout as P, _6 as _ };
//# sourceMappingURL=6-l-QbwULn.js.map
