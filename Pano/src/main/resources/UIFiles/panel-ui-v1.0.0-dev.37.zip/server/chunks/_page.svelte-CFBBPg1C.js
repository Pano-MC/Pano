import { c as create_ssr_component, v as validate_component } from './ssr-ffuobYCI.js';
import { N as Notifications } from './19-t0TGixVW.js';
import './api.util-3BDArkra.js';
import './client-CnCRRyPd.js';
import './exports-CTha0ECg.js';
import './prod-ssr-DxkyU4_t.js';
import './index2-Dyghn50Q.js';
import './runtime-DMBi37QM.js';
import './_commonjsHelpers-B85MJLTf.js';
import './locale-gCQSfw7h.js';
import './getTimezoneOffsetInMilliseconds-TwH_HNks.js';
import './ToastContainer-D6cKqDaa.js';
import './NoContent-Cd8O1sR9.js';
import './language.util-2VlJt8zV.js';
import './paths-C6LjEmZF.js';
import './formatDistanceToNow-wbEYwSfo.js';
import './differenceInSeconds-C8IiJITI.js';

const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0) $$bindings.data(data);
  return `${validate_component(Notifications, "Notifications").$$render($$result, { data }, {}, {})}`;
});

export { Page as default };
//# sourceMappingURL=_page.svelte-CFBBPg1C.js.map
