import { ac as ensure_array_like, a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as Post } from './posts2-C1d6hn9T.js';
import { N as NoContent } from './NoContent-CRKA6SSq.js';

function Posts($$payload, $$props) {
  let posts = $$props["posts"];
  const each_array = ensure_array_like(posts);
  if (each_array.length !== 0) {
    $$payload.out += "<!--[-->";
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let post = each_array[index];
      Post($$payload, { post });
    }
  } else {
    $$payload.out += "<!--[!-->";
    NoContent($$payload, {});
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { posts });
}

export { Posts as P };
//# sourceMappingURL=Posts-DGZFTSro.js.map
