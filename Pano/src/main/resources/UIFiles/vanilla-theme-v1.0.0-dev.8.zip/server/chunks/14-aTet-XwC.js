import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { c as getPostPreview, P as Post } from './posts2-C1d6hn9T.js';

async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  const { session } = parentData;
  const { user } = session;
  if (!user && !user.panelAccess) {
    return { status: 302, redirect: "/" };
  }
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0
    },
    previousPost: "-",
    nextPost: "-"
  };
  await getPostPreview({ id: event.params.id, request: event }).then((body) => {
    if (body.error) {
      data = {};
      return;
    }
    data.post = body;
  });
  return data;
}
function PreviewPost($$payload, $$props) {
  push();
  var $$store_subs;
  let post = $$props["post"];
  $$payload.out += `<h5 class="card-title mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.preview-post.title", { values: { postTitle: post.title } }))}</h5> `;
  Post($$payload, { post, detail: true });
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { post });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 14;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DSFY8v0I.js')).default;
const universal_id = "src/routes/preview/post/[id]/+page.js";
const imports = ["_app/immutable/nodes/14.DgpMnvmF.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/CEG-3bS1.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/DEtv9G4I.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/00FYblu2.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js"];
const stylesheets = [];
const fonts = [];

var _14 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PreviewPost as P, _14 as _ };
//# sourceMappingURL=14-aTet-XwC.js.map
