import { b as ApiUtil } from './api.util-YaRv99PD.js';

const getProfile = async ({ request }) => {
  return ApiUtil.get({
    path: `/api/profile`,
    request
  });
};
const getPlayerProfile = async ({ request, username }) => {
  return ApiUtil.get({
    path: `/api/profile/${username}`,
    request
  });
};

export { getProfile as a, getPlayerProfile as g };
//# sourceMappingURL=profile2-ChodZcvH.js.map
