import { l as load$1, P as PageTypes } from './Tickets-Cf6x6aCW.js';
import './index3-CeMfA1rb.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './Tickets2-DL8JKVVS.js';
import './TicketStatus-Cs9g25Fm.js';
import './api.util-YaRv99PD.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './NoContent-CRKA6SSq.js';
import './ProfileSidebar-D-9QnKp0.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';

async function load(event) {
  return load$1(event, PageTypes.CLOSED);
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 27;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-we53FLWt.js')).default;
const universal_id = "src/routes/tickets/closed/+page.js";
const imports = ["_app/immutable/nodes/27.z7gXzleJ.js","_app/immutable/chunks/B_ycwzvf.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/CQ5bIvsk.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/DbEpdhy6.js","_app/immutable/chunks/_PwMmAdW.js","_app/immutable/chunks/Hdnrr110.js","_app/immutable/chunks/ySN7UkH6.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/B92H8Lk8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/B62o9LzN.js","_app/immutable/chunks/JxE2S7qh.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/BbLlK2h8.js","_app/immutable/chunks/00FYblu2.js","_app/immutable/chunks/unE5M27U.js","_app/immutable/chunks/tUS0VtpF.js","_app/immutable/chunks/7MYaWG_y.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=27-zCrq-sra.js.map
