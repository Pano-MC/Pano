import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { T as TicketCreate } from './21-Bpo-kOxK.js';
import './client-CjlfgChI.js';
import './TicketStatus-Cs9g25Fm.js';
import './api.util-YaRv99PD.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ErrorAlert-DidMNNkl.js';
import './attributes-JZZbhxX3.js';
import './TicketCreateAndDetailSidebar-DoqE_aOB.js';
import './Sidebar-BJnCaXJE.js';
import './OnlineAdmins-BRQUy31Y.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  TicketCreate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CTxEypcj.js.map
