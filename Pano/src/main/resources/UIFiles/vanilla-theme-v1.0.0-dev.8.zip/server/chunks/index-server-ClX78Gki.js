import { ag as current_component } from './index3-CeMfA1rb.js';

function onDestroy(fn) {
  var context = (
    /** @type {Component} */
    current_component
  );
  (context.d ??= []).push(fn);
}

export { onDestroy as o };
//# sourceMappingURL=index-server-ClX78Gki.js.map
