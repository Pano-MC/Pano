import { a8 as store_get, a9 as unsubscribe_stores, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import './client-CjlfgChI.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-D-9QnKp0.js';

async function load(event) {
  const { parent } = event;
  await parent();
  await load$1(event);
  return { sidebar: ProfileSidebar };
}
function Settings($$payload, $$props) {
  push();
  var $$store_subs;
  let resetPasswordError;
  $$payload.out += `<div class="card"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.title"))}</h5> <div class="row mb-3"><label class="col-md-4 col-form-label" for="resetPassword">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.title"))}</label> <div class="col col-form-label"><a href="javascript:void(0);" aria-describedby="resetPassword validationResetPassword"${attr("class", [
    "",
    ""
  ].filter(Boolean).join(" "))}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-password.description"))}</a> <div id="validationResetPassword" class="invalid-feedback">${escape_html(resetPasswordError)}</div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></div> <div class="row mb-3"><label class="col-md-4 col-form-label" for="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.title"))}</label> <div class="col col-form-label"><form><div class="row">`;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="col-12">`;
    {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<a href="javascript:void(0);" aria-describedby="userEmail">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.settings.inputs.change-email.description"))}</a>`;
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></form></div></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-ClLXo3tS.js')).default;
const universal_id = "src/routes/profile/settings/+page.js";
const imports = ["_app/immutable/nodes/16.CHIKR8Tt.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/V7Lq0j5Y.js","_app/immutable/chunks/CWmzcjye.js","_app/immutable/chunks/CQ5bIvsk.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/DbEpdhy6.js","_app/immutable/chunks/_PwMmAdW.js","_app/immutable/chunks/Hdnrr110.js","_app/immutable/chunks/ySN7UkH6.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/B92H8Lk8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Ci1FVhrv.js"];
const stylesheets = [];
const fonts = [];

var _16 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Settings as S, _16 as _ };
//# sourceMappingURL=16-CDEQL83m.js.map
