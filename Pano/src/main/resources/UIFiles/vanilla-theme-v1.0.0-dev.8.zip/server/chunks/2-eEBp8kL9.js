import { a7 as slot, t as pop, p as push } from './index3-CeMfA1rb.js';
import { r as requireLogin } from './Store-CS8VFGEx.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CtOrvHdG.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.BGp31HOP.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/DbEpdhy6.js","_app/immutable/chunks/_PwMmAdW.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/Hdnrr110.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-eEBp8kL9.js.map
