import { ac as ensure_array_like, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push, ab as stringify } from './index3-CeMfA1rb.js';
import './client-CjlfgChI.js';
import { b as getTicketCategories } from './TicketStatus-Cs9g25Fm.js';
import { E as ErrorAlert } from './ErrorAlert-DidMNNkl.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar-DoqE_aOB.js';
import { e as error } from './index2-DzcLzHBX.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { categories: [], categoryPage: 0 };
  await load$1(event);
  await getTicketCategories({ page: data.categoryPage, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return {
    ...data,
    sidebar: TicketCreateAndDetailSidebar
  };
}
function TicketCreate($$payload, $$props) {
  push();
  var $$store_subs;
  let isButtonDisabled;
  let data = $$props["data"];
  let error2;
  let title = "";
  let message = "";
  isButtonDisabled = title === "";
  const each_array = ensure_array_like(data.categories);
  $$payload.out += `<div class="card"><div class="card-body"><div class="row justify-content-between mb-3"><div class="col-auto"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.title"))}</h4></div></div> `;
  ErrorAlert($$payload, { error: error2 });
  $$payload.out += `<!----> <div class="mb-3"><input type="text" class="form-control form-control-lg mb-3"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.title"))}${attr("value", title)}> <select class="form-select" id="datalistOptions"><option${attr("value", -1)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.no-category"))}</option><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let category = each_array[index];
    $$payload.out += `<option${attr("value", category.id)}>${escape_html(category.title)}</option>`;
  }
  $$payload.out += `<!--]--></select></div> <div class="mb-3"><textarea class="form-control" rows="6">`;
  const $$body = escape_html(message);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea></div> <button${attr("class", `btn btn-primary w-100 ${stringify([isButtonDisabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", isButtonDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.create-button"))}</button></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 21;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CTxEypcj.js')).default;
const universal_id = "src/routes/ticket/create/+page.js";
const imports = ["_app/immutable/nodes/21.B24FXvF9.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/V7Lq0j5Y.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/Caj48RLz.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/B92H8Lk8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/DI6hq6b5.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/tUS0VtpF.js","_app/immutable/chunks/7MYaWG_y.js","_app/immutable/chunks/B62o9LzN.js","_app/immutable/chunks/Hdnrr110.js"];
const stylesheets = [];
const fonts = [];

var _21 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { TicketCreate as T, _21 as _ };
//# sourceMappingURL=21-Bpo-kOxK.js.map
