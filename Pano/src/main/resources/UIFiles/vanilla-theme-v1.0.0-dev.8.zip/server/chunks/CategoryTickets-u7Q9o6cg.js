import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { $ as $format } from './runtime-BlMCrmsd.js';
import './client-CjlfgChI.js';
import { P as Pagination } from './Pagination-DT_5Txbj.js';
import { T as Tickets } from './Tickets2-DL8JKVVS.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-D-9QnKp0.js';
import { c as getCategoryTickets } from './TicketStatus-Cs9g25Fm.js';
import { e as error } from './index2-DzcLzHBX.js';
import { h as html } from './html-FW6Ia4bL.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    tickets: [],
    ticketCount: 0,
    page: 1,
    totalPage: 1,
    url: event.params.url,
    category: {
      id: -1,
      title: "-",
      description: "",
      url: "-"
    }
  };
  await load$1(event);
  await getCategoryTickets({
    page: event.params.page || 1,
    url: event.params.url,
    request: event
  }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS" || body.error === "PAGE_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function CategoryTickets($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card"><div class="card-body"><div class="row justify-content-between pb-3 align-items-center"><div class="col-auto"><h4 class="card-title mb-md-0">${html(store_get($$store_subs ??= {}, "$_", $format)("pages.category-tickets.title", {
    values: {
      categoryName: `<strong
            >"${data.category.title === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.category-tickets.no-category") : data.category.title}"</strong>`
    }
  }))}</h4></div></div> `;
  Tickets($$payload, { tickets: data.tickets });
  $$payload.out += `<!----></div></div> <br> `;
  if (data.ticketCount > 0) {
    $$payload.out += "<!--[-->";
    Pagination($$payload, {
      page: data.page,
      totalPage: data.totalPage,
      loading: false
    });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

export { CategoryTickets as C, load as l };
//# sourceMappingURL=CategoryTickets-u7Q9o6cg.js.map
