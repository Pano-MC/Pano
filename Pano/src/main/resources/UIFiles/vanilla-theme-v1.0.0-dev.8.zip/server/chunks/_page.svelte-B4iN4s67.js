import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { C as CategoryTickets } from './CategoryTickets-u7Q9o6cg.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './Pagination-DT_5Txbj.js';
import './attributes-JZZbhxX3.js';
import './Tickets2-DL8JKVVS.js';
import './TicketStatus-Cs9g25Fm.js';
import './api.util-YaRv99PD.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './NoContent-CRKA6SSq.js';
import './ProfileSidebar-D-9QnKp0.js';
import './index-server-ClX78Gki.js';
import './stores-BPGm-Oli.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-76jvL1tB.js';
import './Sidebar-BJnCaXJE.js';
import './html-FW6Ia4bL.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  CategoryTickets($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-B4iN4s67.js.map
