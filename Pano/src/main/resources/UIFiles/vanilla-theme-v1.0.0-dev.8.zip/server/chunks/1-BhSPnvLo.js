const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-DVSVVHqG.js')).default;
const imports = ["_app/immutable/nodes/1.EaQptSk-.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/D-8kYPrx.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-BhSPnvLo.js.map
