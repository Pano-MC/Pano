import { ac as ensure_array_like, ab as stringify, a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { a as attr } from './attributes-JZZbhxX3.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import './client-CjlfgChI.js';
import { g as getTicketDetail, T as TicketStatuses, a as TicketStatus } from './TicketStatus-Cs9g25Fm.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar-DoqE_aOB.js';
import { e as error } from './index2-DzcLzHBX.js';
import { h as html } from './html-FW6Ia4bL.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    ticket: {
      id: -1,
      username: "",
      title: "",
      category: "-",
      messages: [],
      status: 1,
      date: 0,
      messageCount: 0
    }
  };
  await getTicketDetail({ id: event.params.id, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  await load$1(event, data.ticket);
  return {
    ...data,
    sidebar: TicketCreateAndDetailSidebar
  };
}
function TicketDetail($$payload, $$props) {
  push();
  var $$store_subs;
  let isSendButtonDisabled;
  let data = $$props["data"];
  let message = "";
  let sentMessageCount = 0;
  isSendButtonDisabled = message === "";
  const each_array = ensure_array_like(data.ticket.messages);
  $$payload.out += `<article class="container"><div class="card"><div${attr("class", `card-header bg-opacity-25 py-3 rounded-top ${stringify([
    data.ticket.status === TicketStatuses.NEW ? "bg-secondary" : "",
    data.ticket.status === TicketStatuses.REPLIED ? "bg-warning" : "",
    data.ticket.status === TicketStatuses.CLOSED ? "bg-danger" : ""
  ].filter(Boolean).join(" "))}`)}><div class="row"><div class="col"><h5 class="card-title">${escape_html(data.ticket.title)}</h5> <small class="mb-0">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.detail.ticket", { values: { ticketId: data.ticket.id } }))}, `;
  Date_1($$payload, { time: data.ticket.date, relativeFormat: true });
  $$payload.out += `<!----> , ${html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.detail.opened-in-category", {
    values: {
      category: `<a
              href="/tickets/category/${data.ticket.category.url}"
              title="${store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.filter")}"
              >${data.ticket.category === "-" ? store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.no-category") : data.ticket.category.title}
            </a>`
    }
  }))}</small></div> <div class="col-auto">`;
  TicketStatus($$payload, { status: data.ticket.status });
  $$payload.out += `<!----></div></div></div> <div class="card-body" id="messageSection">`;
  if (data.ticket.messages.length < data.ticket.messageCount && data.ticket.messageCount > 5) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<button${attr("class", `btn btn-link bg-light d-block m-auto ${stringify([""].filter(Boolean).join(" "))}`)}><i class="fas fa-arrow-up mr-1"></i> ${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.previous-messages", {
      values: {
        count: data.ticket.messageCount - (data.ticket.messages.length - sentMessageCount)
      }
    }))}</button>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let message2 = each_array[index];
    if (message2.panel) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<div class="row py-2 flex-nowrap justify-content-start"><div class="col-auto"><a${attr("href", `/player/${stringify(message2.username)}`)}><img${attr("src", `https://minotar.net/avatar/${stringify(message2.username)}/48`)}${attr("alt", message2.username)} class="rounded d-block mr-auto animate__animated animate__zoomIn" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"></a></div> <div class="col-auto"><div class="card text-bg-light"><div class="card-header small">`;
      Date_1($$payload, { time: message2.date });
      $$payload.out += `<!----></div> <div class="card-body answer">${html(message2.message)}</div></div></div></div>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<div class="row py-2 flex-nowrap justify-content-end"><div class="col-auto"><a${attr("href", `/player/${stringify(message2.username)}`)}><img${attr("src", `https://minotar.net/avatar/${stringify(message2.username)}/48`)}${attr("alt", message2.username)} class="rounded animate__animated animate__zoomIn" width="48" height="48" onload="this.__e=event" onerror="this.__e=event"></a></div> <div class="col-auto"><div class="card text-bg-secondary"><div class="card-header small">`;
      Date_1($$payload, { time: message2.date });
      $$payload.out += `<!----></div> <div class="card-body">${escape_html(message2.message)}</div></div></div></div>`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--> <div${attr("class", `row align-items-end mt-3 ${stringify([
    data.ticket.status === TicketStatuses.CLOSED ? "d-none" : ""
  ].filter(Boolean).join(" "))}`)}><div class="col"><textarea${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.inputs.message.placeholder"))} class="form-control">`;
  const $$body = escape_html(message);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea></div> <div class="col-auto"><button${attr("class", `btn btn-secondary ${stringify([
    isSendButtonDisabled ? "disabled" : ""
  ].filter(Boolean).join(" "))}`)}${attr(":disabled", isSendButtonDisabled)}><i class="fas fa-paper-plane"></i> <span class="d-xl-inline d-none ms-2">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.ticket-detail.send-button"))}</span></button></div></div></div></div></article>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 20;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bc9mICds.js')).default;
const universal_id = "src/routes/ticket/[id]/+page.js";
const imports = ["_app/immutable/nodes/20.CD3TctEM.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BjUwF-Cn.js","_app/immutable/chunks/DEtv9G4I.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/V7Lq0j5Y.js","_app/immutable/chunks/y1LDglf1.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/Caj48RLz.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/B92H8Lk8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/DI6hq6b5.js","_app/immutable/chunks/tUS0VtpF.js","_app/immutable/chunks/7MYaWG_y.js","_app/immutable/chunks/B62o9LzN.js","_app/immutable/chunks/Hdnrr110.js","_app/immutable/chunks/00FYblu2.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js"];
const stylesheets = ["_app/immutable/assets/20.mj9Ow22B.css"];
const fonts = [];

var _20 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { TicketDetail as T, _20 as _ };
//# sourceMappingURL=20-D3Lk9pg_.js.map
