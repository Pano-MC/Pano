import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as PostDetail } from './11-DnPPKWSD.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-CjlfgChI.js';
import './posts2-C1d6hn9T.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './attributes-JZZbhxX3.js';
import './html-FW6Ia4bL.js';
import './api.util-YaRv99PD.js';
import './index2-DzcLzHBX.js';
import './HomeSidebar-BF2XOI7Y.js';
import './Sidebar-BJnCaXJE.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PostDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cd6NmZE2.js.map
