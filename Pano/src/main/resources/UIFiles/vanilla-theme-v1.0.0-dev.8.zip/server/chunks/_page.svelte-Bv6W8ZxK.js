import { a6 as bind_props } from './index3-CeMfA1rb.js';
import { P as PlayerProfile } from './13-Bc4zUH_f.js';
import './runtime-BlMCrmsd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-QR3vE5Mi.js';
import './language.util-BT90rPTb.js';
import './client-CjlfgChI.js';
import './index2-DzcLzHBX.js';
import './index-server-ClX78Gki.js';
import './Sidebar-BJnCaXJE.js';
import './attributes-JZZbhxX3.js';
import './PlayerHead-76jvL1tB.js';
import './api.util-YaRv99PD.js';
import './profile2-ChodZcvH.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PlayerProfile($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Bv6W8ZxK.js.map
