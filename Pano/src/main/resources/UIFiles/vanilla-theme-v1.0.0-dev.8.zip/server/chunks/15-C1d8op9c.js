import { a8 as store_get, a9 as unsubscribe_stores, a6 as bind_props, t as pop, p as push } from './index3-CeMfA1rb.js';
import { e as escape_html, $ as $format } from './runtime-BlMCrmsd.js';
import { D as Date_1 } from './Date-QR3vE5Mi.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-D-9QnKp0.js';
import { a as getProfile } from './profile2-ChodZcvH.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CkFR-G-C.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.CbKKysQj.js","_app/immutable/chunks/BF2zeUph.js","_app/immutable/chunks/Ce9fhSyy.js","_app/immutable/chunks/CmjeyhTE.js","_app/immutable/chunks/DabAUK1Z.js","_app/immutable/chunks/BmT4y92q.js","_app/immutable/chunks/DcaFTmiY.js","_app/immutable/chunks/CQ5bIvsk.js","_app/immutable/chunks/CyP_Tm83.js","_app/immutable/chunks/CPm7C82B.js","_app/immutable/chunks/Cw0qYQEj.js","_app/immutable/chunks/KasrVRWH.js","_app/immutable/chunks/D-8kYPrx.js","_app/immutable/chunks/DbEpdhy6.js","_app/immutable/chunks/_PwMmAdW.js","_app/immutable/chunks/Hdnrr110.js","_app/immutable/chunks/ySN7UkH6.js","_app/immutable/chunks/BvAxShZe.js","_app/immutable/chunks/BotrU1Ng.js","_app/immutable/chunks/D6dxNeWq.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/C-EJOgsR.js","_app/immutable/chunks/B92H8Lk8.js","_app/immutable/chunks/COJ40m7V.js","_app/immutable/chunks/Ci1FVhrv.js","_app/immutable/chunks/00FYblu2.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-C1d8op9c.js.map
