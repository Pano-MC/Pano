import{a as t}from"../chunks/DabAUK1Z.js";export{t as start};
