import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { T as TicketDetail } from './20-B4_l-4Za.js';
import './attributes-D1BeYJpW.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './client-Udtyxk2s.js';
import './TicketStatus-CZtEhgsZ.js';
import './api.util-BOgD0MTi.js';
import './TicketCreateAndDetailSidebar-DvLpd4Hc.js';
import './Sidebar-D2M2HNzk.js';
import './OnlineAdmins-D61cmj5k.js';
import './index2-DzcLzHBX.js';
import './html-FW6Ia4bL.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  TicketDetail($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BAbb8CWR.js.map
