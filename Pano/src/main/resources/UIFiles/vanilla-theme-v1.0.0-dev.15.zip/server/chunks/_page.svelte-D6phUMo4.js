import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { T as Tickets_1 } from './Tickets-CBdx9JEl.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-Udtyxk2s.js';
import './Pagination-C1SaWYaW.js';
import './attributes-D1BeYJpW.js';
import './Tickets2-Bj9Tbchq.js';
import './TicketStatus-CZtEhgsZ.js';
import './api.util-BOgD0MTi.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './NoContent-y_d6Pngq.js';
import './ProfileSidebar-BeQAKqS7.js';
import './index-server-DfkY9wgZ.js';
import './stores-D5elBKmu.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-Z7Dscliz.js';
import './Sidebar-D2M2HNzk.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Tickets_1($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-D6phUMo4.js.map
