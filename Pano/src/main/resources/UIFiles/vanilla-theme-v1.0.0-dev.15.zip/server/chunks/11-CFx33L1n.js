import { a8 as stringify, a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import './client-Udtyxk2s.js';
import { b as getPostDetail, P as Post } from './posts2-aMR0jB6E.js';
import { e as error } from './index2-DzcLzHBX.js';
import { l as load$1, H as HomeSidebar } from './HomeSidebar-CCecLdVJ.js';
import { a as attr } from './attributes-D1BeYJpW.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0,
      url: ""
    },
    previousPost: "-",
    nextPost: "-"
  };
  await load$1(event);
  await getPostDetail({ url: event.params.url, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "POST_NOT_FOUND") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return { ...data, sidebar: HomeSidebar };
}
function PostDetail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  Post($$payload, { post: data.post, detail: true });
  $$payload.out += `<!----> <div class="row justify-content-between"><div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.previousPost === "-" ? "" : data.previousPost.url)}`)}${attr("class", `btn btn-link ps-0 ${stringify([data.previousPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.previous-post"))}</a></div> <div class="col-auto"><a${attr("href", `/blog/post/${stringify(data.nextPost === "-" ? "" : data.nextPost.url)}`)}${attr("class", `btn btn-link pe-0 ${stringify([data.nextPost === "-" ? "disabled" : ""].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.post-detail.next-post"))}</a></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D8Dx0Iot.js')).default;
const universal_id = "src/routes/blog/post/[url]/+page.js";
const imports = ["_app/immutable/nodes/11.2H7J6YH_.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/C5Wo41fD.js","_app/immutable/chunks/Bbk6Aw_x.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/B3n8Jioj.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/BBI2dWEK.js","_app/immutable/chunks/GDeMav9w.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/CZY_utnm.js","_app/immutable/chunks/DvSZIbyy.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/DPiSq1cj.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/C9Eo4G-e.js","_app/immutable/chunks/nu-QtGX9.js","_app/immutable/chunks/Cm-derwA.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js"];
const stylesheets = [];
const fonts = [];

var _11 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PostDetail as P, _11 as _ };
//# sourceMappingURL=11-CFx33L1n.js.map
