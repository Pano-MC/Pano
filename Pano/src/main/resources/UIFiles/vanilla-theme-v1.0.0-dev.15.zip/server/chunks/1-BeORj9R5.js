const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-BzUWUPkH.js')).default;
const imports = ["_app/immutable/nodes/1.C4yiVdFD.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/C5Wo41fD.js","_app/immutable/chunks/Bbk6Aw_x.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/ZN-_CbYj.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-BeORj9R5.js.map
