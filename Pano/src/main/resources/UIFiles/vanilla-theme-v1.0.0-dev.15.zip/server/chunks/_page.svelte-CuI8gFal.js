import { R as ResetPassword } from './18-Bfem_Ora.js';
import './index3-gzEcGBsg.js';
import './ErrorAlert-DtsYo9BM.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './SuccessAlert-eJ6hQXAr.js';
import './attributes-D1BeYJpW.js';
import './client-Udtyxk2s.js';
import './Store-CQgMLh7S.js';
import './index2-DzcLzHBX.js';

function _page($$payload) {
  ResetPassword($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CuI8gFal.js.map
