import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { D as Date_1 } from './Date-B9_gBZcf.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-BeQAKqS7.js';
import { a as getProfile } from './profile2-TejH8w_X.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DVCnzcU0.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.Ch6IPH1d.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/C5Wo41fD.js","_app/immutable/chunks/Bbk6Aw_x.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/DVO5AHxN.js","_app/immutable/chunks/B3n8Jioj.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/DvSZIbyy.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/CPAz8hnf.js","_app/immutable/chunks/CBECzIHz.js","_app/immutable/chunks/BBI2dWEK.js","_app/immutable/chunks/Cnmp9HSU.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/DPiSq1cj.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/njrpdZaz.js","_app/immutable/chunks/Cm-derwA.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-BB-Rt7v1.js.map
