import { ac as fallback, a8 as stringify, a4 as slot, a3 as bind_props } from './index3-gzEcGBsg.js';
import { a as attr } from './attributes-D1BeYJpW.js';

function Sidebar($$payload, $$props) {
  let side = fallback($$props["side"], "right");
  $$payload.out += `<aside${attr("class", `col-lg-4 ${stringify([
    side === "right" ? "order-lg-last" : "",
    side === "right" ? "order-first" : "",
    side === "left" ? "order-lg-first" : "",
    side === "left" ? "order-last" : ""
  ].filter(Boolean).join(" "))}`)}><!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----></aside>`;
  bind_props($$props, { side });
}

export { Sidebar as S };
//# sourceMappingURL=Sidebar-D2M2HNzk.js.map
