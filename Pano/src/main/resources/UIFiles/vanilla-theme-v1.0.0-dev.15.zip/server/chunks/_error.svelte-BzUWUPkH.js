import { a5 as store_get, a6 as unsubscribe_stores, t as pop, p as push } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { p as page } from './stores-D5elBKmu.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-Udtyxk2s.js';

function Error($$payload, $$props) {
  push();
  var $$store_subs;
  $$payload.out += `<h3>${escape_html(store_get($$store_subs ??= {}, "$page", page).status)}: ${escape_html(store_get($$store_subs ??= {}, "$page", page).status === 404 ? store_get($$store_subs ??= {}, "$_", $format)("page-errors." + store_get($$store_subs ??= {}, "$page", page).status) : store_get($$store_subs ??= {}, "$page", page).error.message)}</h3>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  pop();
}
function _error($$payload) {
  Error($$payload);
}

export { _error as default };
//# sourceMappingURL=_error.svelte-BzUWUPkH.js.map
