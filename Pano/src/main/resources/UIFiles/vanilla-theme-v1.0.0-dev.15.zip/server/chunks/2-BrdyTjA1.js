import { a4 as slot, t as pop, p as push } from './index3-gzEcGBsg.js';
import { r as requireLogin } from './Store-CQgMLh7S.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-BV1vXOsK.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.BjaPXLVa.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/C5Wo41fD.js","_app/immutable/chunks/Bbk6Aw_x.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/CPAz8hnf.js","_app/immutable/chunks/CBECzIHz.js","_app/immutable/chunks/DvSZIbyy.js","_app/immutable/chunks/BBI2dWEK.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-BrdyTjA1.js.map
