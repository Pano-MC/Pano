import { S as Settings } from './16-5H4f2c3t.js';
import './index3-gzEcGBsg.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-D1BeYJpW.js';
import './client-Udtyxk2s.js';
import './ProfileSidebar-BeQAKqS7.js';
import './index-server-DfkY9wgZ.js';
import './stores-D5elBKmu.js';
import './api.util-BOgD0MTi.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-Z7Dscliz.js';
import './Sidebar-D2M2HNzk.js';

function _page($$payload) {
  Settings($$payload);
}

export { _page as default };
//# sourceMappingURL=_page.svelte-C2CKTfQ4.js.map
