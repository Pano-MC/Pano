import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { P as PlayerProfile } from './13-BbCBp3Zo.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './client-Udtyxk2s.js';
import './index2-DzcLzHBX.js';
import './index-server-DfkY9wgZ.js';
import './Sidebar-D2M2HNzk.js';
import './attributes-D1BeYJpW.js';
import './PlayerHead-Z7Dscliz.js';
import './api.util-BOgD0MTi.js';
import './profile2-TejH8w_X.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  PlayerProfile($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-C-kMOBcf.js.map
