const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/green.svg","assets/img/minecraft-logo.png","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.FlOc3ZcX.js",app:"_app/immutable/entry/app.BjLN_Rhz.js",imports:["_app/immutable/entry/start.FlOc3ZcX.js","_app/immutable/chunks/Bbk6Aw_x.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/entry/app.BjLN_Rhz.js","_app/immutable/chunks/BqZa6u5u.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/D9t3n7gZ.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-Brw1u6pH.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-BeORj9R5.js')),
			__memo(() => import('./chunks/2-BrdyTjA1.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/3-CPqJPn3u.js')),
			__memo(() => import('./chunks/4-YZC9_bER.js')),
			__memo(() => import('./chunks/5-tlP3HoSo.js')),
			__memo(() => import('./chunks/6-CDWZl141.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-DJsmfWPw.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/8-BxD8tYTn.js')),
			__memo(() => import('./chunks/9-DRShTQnt.js')),
			__memo(() => import('./chunks/10-C9Y9iEor.js')),
			__memo(() => import('./chunks/11-CFx33L1n.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/12-Dxkz_4A-.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/13-BbCBp3Zo.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/14-Cqt9aDAq.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-BB-Rt7v1.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/16-5H4f2c3t.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/17-D5FgAHVO.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-Bfem_Ora.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/19-oa8vZTZc.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/20-B4_l-4Za.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/21-BN9Hozdg.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/22--Alyg-TU.js')),
			__memo(() => import('./chunks/23-B3IAYpJv.js')),
			__memo(() => import('./chunks/24-BPqThYBt.js')),
			__memo(() => import('./chunks/25-CWy9JwrD.js')),
			__memo(() => import('./chunks/26-BA74dwky.js')),
			__memo(() => import('./chunks/27-AdZ4JVzp.js')),
			__memo(() => import('./chunks/28-TBOAsxYj.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/activate-new-email",
				pattern: /^\/activate-new-email\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/activate",
				pattern: /^\/activate\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]",
				pattern: /^\/blog\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]/[page]",
				pattern: /^\/blog\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/blog/page/[page]",
				pattern: /^\/blog\/page\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/blog/post/[url]",
				pattern: /^\/blog\/post\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/player/[player]",
				pattern: /^\/player\/([^/]+?)\/?$/,
				params: [{"name":"player","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Duh1hDwD.js'))
			},
			{
				id: "/preview/post/[id]",
				pattern: /^\/preview\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/profile/settings",
				pattern: /^\/profile\/settings\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/renew-password",
				pattern: /^\/renew-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/reset-password",
				pattern: /^\/reset-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/support",
				pattern: /^\/support\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/theme-api/languages",
				pattern: /^\/theme-api\/languages\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-J3hjOU-B.js'))
			},
			{
				id: "/theme-api/languages/[language].json",
				pattern: /^\/theme-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-h-GTtCCu.js'))
			},
			{
				id: "/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/tickets/all",
				pattern: /^\/tickets\/all\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/tickets/all/[page]",
				pattern: /^\/tickets\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]",
				pattern: /^\/tickets\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]/[page]",
				pattern: /^\/tickets\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/tickets/closed",
				pattern: /^\/tickets\/closed\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/tickets/closed/[page]",
				pattern: /^\/tickets\/closed\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/ticket/create",
				pattern: /^\/ticket\/create\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/ticket/[id]",
				pattern: /^\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 20 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
