import{a as t}from"../chunks/Do1PMRWI.js";export{t as start};
