const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["assets/.gitkeep","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-300.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-500.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-700.woff2","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.eot","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.svg","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.ttf","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff","assets/fonts/quicksand-v8-latin-ext_latin_vietnamese-regular.woff2","assets/img/green.svg","assets/img/minecraft-logo.png","assets/img/red.svg","assets/img/yellow.svg","assets/webfonts/fa-brands-400.ttf","assets/webfonts/fa-brands-400.woff2","assets/webfonts/fa-regular-400.ttf","assets/webfonts/fa-regular-400.woff2","assets/webfonts/fa-solid-900.ttf","assets/webfonts/fa-solid-900.woff2","assets/webfonts/fa-v4compatibility.ttf","assets/webfonts/fa-v4compatibility.woff2","robots.txt"]),
	mimeTypes: {".svg":"image/svg+xml",".ttf":"font/ttf",".woff":"font/woff",".woff2":"font/woff2",".png":"image/png",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.CKl_AgRE.js",app:"_app/immutable/entry/app.BM83lc8d.js",imports:["_app/immutable/entry/start.CKl_AgRE.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/entry/app.BM83lc8d.js","_app/immutable/chunks/BqZa6u5u.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/D9t3n7gZ.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-DZcvfrHi.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/1-DfnJhtJX.js')),
			__memo(() => import('./chunks/2-B8eOzECs.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/3-D90ibvD-.js')),
			__memo(() => import('./chunks/4-DLln_Q1t.js')),
			__memo(() => import('./chunks/5-AOoABDpW.js')),
			__memo(() => import('./chunks/6-Ad6v7RSr.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-CEhNbZDn.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/8-DSrjuB8m.js')),
			__memo(() => import('./chunks/9-CsoPYaf9.js')),
			__memo(() => import('./chunks/10-C_vfoMQ9.js')),
			__memo(() => import('./chunks/11-CikcWdbW.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/12-Ba-Xg8fp.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/13-CKMgtzSz.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/14-B8vJcoo5.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-m_AK8oFr.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/16-Czlpro2r.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/17-r7FY_Ukh.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-BKAUWDLh.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/19-zksAld6L.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/20-CPmXlSyT.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/21-CiR-TjkD.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/22-BPptdVCa.js')),
			__memo(() => import('./chunks/23-uLnyDvhd.js')),
			__memo(() => import('./chunks/24-_A4FE_dY.js')),
			__memo(() => import('./chunks/25-CZnkpDQl.js')),
			__memo(() => import('./chunks/26-XOgRp8TU.js')),
			__memo(() => import('./chunks/27-_3eS1NDD.js')),
			__memo(() => import('./chunks/28-CLLDJOGN.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/activate-new-email",
				pattern: /^\/activate-new-email\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/activate",
				pattern: /^\/activate\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]",
				pattern: /^\/blog\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/blog/category/[url]/[page]",
				pattern: /^\/blog\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/blog/page/[page]",
				pattern: /^\/blog\/page\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/blog/post/[url]",
				pattern: /^\/blog\/post\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/notifications",
				pattern: /^\/notifications\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/player/[player]",
				pattern: /^\/player\/([^/]+?)\/?$/,
				params: [{"name":"player","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/plugins/[pluginId]/resources/plugin-ui/client/[fileName]",
				pattern: /^\/plugins\/([^/]+?)\/resources\/plugin-ui\/client\/([^/]+?)\/?$/,
				params: [{"name":"pluginId","optional":false,"rest":false,"chained":false},{"name":"fileName","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-Duh1hDwD.js'))
			},
			{
				id: "/preview/post/[id]",
				pattern: /^\/preview\/post\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/profile",
				pattern: /^\/profile\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/profile/settings",
				pattern: /^\/profile\/settings\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/renew-password",
				pattern: /^\/renew-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/reset-password",
				pattern: /^\/reset-password\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/support",
				pattern: /^\/support\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/theme-api/languages",
				pattern: /^\/theme-api\/languages\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-J3hjOU-B.js'))
			},
			{
				id: "/theme-api/languages/[language].json",
				pattern: /^\/theme-api\/languages\/([^/]+?)\.json\/?$/,
				params: [{"name":"language","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./chunks/_server-h-GTtCCu.js'))
			},
			{
				id: "/tickets",
				pattern: /^\/tickets\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 22 },
				endpoint: null
			},
			{
				id: "/tickets/all",
				pattern: /^\/tickets\/all\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 23 },
				endpoint: null
			},
			{
				id: "/tickets/all/[page]",
				pattern: /^\/tickets\/all\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 24 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]",
				pattern: /^\/tickets\/category\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 25 },
				endpoint: null
			},
			{
				id: "/tickets/category/[url]/[page]",
				pattern: /^\/tickets\/category\/([^/]+?)\/([^/]+?)\/?$/,
				params: [{"name":"url","optional":false,"rest":false,"chained":false},{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 26 },
				endpoint: null
			},
			{
				id: "/tickets/closed",
				pattern: /^\/tickets\/closed\/?$/,
				params: [],
				page: { layouts: [0,4,], errors: [1,,], leaf: 27 },
				endpoint: null
			},
			{
				id: "/tickets/closed/[page]",
				pattern: /^\/tickets\/closed\/([^/]+?)\/?$/,
				params: [{"name":"page","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,4,], errors: [1,,], leaf: 28 },
				endpoint: null
			},
			{
				id: "/ticket/create",
				pattern: /^\/ticket\/create\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 21 },
				endpoint: null
			},
			{
				id: "/ticket/[id]",
				pattern: /^\/ticket\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,3,], errors: [1,,], leaf: 20 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
