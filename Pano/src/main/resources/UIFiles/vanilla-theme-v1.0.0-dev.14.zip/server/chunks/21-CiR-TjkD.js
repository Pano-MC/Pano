import { a9 as ensure_array_like, a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push, a8 as stringify } from './index3-gzEcGBsg.js';
import './client-Udtyxk2s.js';
import { b as getTicketCategories } from './TicketStatus-CZtEhgsZ.js';
import { E as ErrorAlert } from './ErrorAlert-DtsYo9BM.js';
import { a as attr } from './attributes-D1BeYJpW.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { l as load$1, T as TicketCreateAndDetailSidebar } from './TicketCreateAndDetailSidebar-DvLpd4Hc.js';
import { e as error } from './index2-DzcLzHBX.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { categories: [], categoryPage: 0 };
  await load$1(event);
  await getTicketCategories({ page: data.categoryPage, request: event }).then((body) => {
    if (body.error) {
      if (body.error === "NOT_EXISTS") {
        throw error(404, body.error);
      }
      throw error(500, body.error);
    }
    data = body;
  });
  return {
    ...data,
    sidebar: TicketCreateAndDetailSidebar
  };
}
function TicketCreate($$payload, $$props) {
  push();
  var $$store_subs;
  let isButtonDisabled;
  let data = $$props["data"];
  let error2;
  let title = "";
  let message = "";
  isButtonDisabled = title === "";
  const each_array = ensure_array_like(data.categories);
  $$payload.out += `<div class="card"><div class="card-body"><div class="row justify-content-between mb-3"><div class="col-auto"><h4 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.title"))}</h4></div></div> `;
  ErrorAlert($$payload, { error: error2 });
  $$payload.out += `<!----> <div class="mb-3"><input type="text" class="form-control form-control-lg mb-3"${attr("placeholder", store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.title"))}${attr("value", title)}> <select class="form-select" id="datalistOptions"><option${attr("value", -1)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.inputs.no-category"))}</option><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let category = each_array[index];
    $$payload.out += `<option${attr("value", category.id)}>${escape_html(category.title)}</option>`;
  }
  $$payload.out += `<!--]--></select></div> <div class="mb-3"><textarea class="form-control" rows="6">`;
  const $$body = escape_html(message);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea></div> <button${attr("class", `btn btn-primary w-100 ${stringify([isButtonDisabled ? "disabled" : ""].filter(Boolean).join(" "))}`)}${attr("disabled", isButtonDisabled, true)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.create-ticket.create-button"))}</button></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 21;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cr8hZLdd.js')).default;
const universal_id = "src/routes/ticket/create/+page.js";
const imports = ["_app/immutable/nodes/21.COoP2vpl.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/CZY_utnm.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/CxuTIO-w.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/VXw6MPMI.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/Bh6hwqBo.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/BBijUeiY.js","_app/immutable/chunks/Bez2mVAd.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/DtQlk9VG.js","_app/immutable/chunks/l_VtGx06.js","_app/immutable/chunks/DNE94s2m.js","_app/immutable/chunks/BSzH7kjz.js"];
const stylesheets = [];
const fonts = [];

var _21 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { TicketCreate as T, _21 as _ };
//# sourceMappingURL=21-CiR-TjkD.js.map
