import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { P as Profile } from './15-m_AK8oFr.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './client-Udtyxk2s.js';
import './ProfileSidebar-BeQAKqS7.js';
import './index-server-DfkY9wgZ.js';
import './stores-D5elBKmu.js';
import './api.util-BOgD0MTi.js';
import './index2-DzcLzHBX.js';
import './PlayerHead-Z7Dscliz.js';
import './attributes-D1BeYJpW.js';
import './Sidebar-D2M2HNzk.js';
import './profile2-TejH8w_X.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Profile($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DjNi-HAC.js.map
