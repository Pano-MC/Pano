import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { C as CategoryPosts } from './CategoryPosts-CNR3ALMg.js';
import './client-Udtyxk2s.js';
import './Pagination-C1SaWYaW.js';
import './attributes-D1BeYJpW.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-B0qfOo5E.js';
import './posts2-aMR0jB6E.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './html-FW6Ia4bL.js';
import './api.util-BOgD0MTi.js';
import './NoContent-y_d6Pngq.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  CategoryPosts($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DlEivDOp.js.map
