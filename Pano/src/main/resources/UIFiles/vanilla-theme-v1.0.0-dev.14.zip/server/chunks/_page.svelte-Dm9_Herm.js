import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { R as RenewPassword } from './17-r7FY_Ukh.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ErrorAlert-DtsYo9BM.js';
import './SuccessAlert-eJ6hQXAr.js';
import './attributes-D1BeYJpW.js';
import './client-Udtyxk2s.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  RenewPassword($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Dm9_Herm.js.map
