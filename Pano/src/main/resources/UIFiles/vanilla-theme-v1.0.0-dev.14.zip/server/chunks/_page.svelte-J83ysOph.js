import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { A as Activate } from './6-Ad6v7RSr.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-D1BeYJpW.js';
import './client-Udtyxk2s.js';
import './ErrorAlert-DtsYo9BM.js';
import './SuccessAlert-eJ6hQXAr.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Activate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-J83ysOph.js.map
