import { a4 as slot, t as pop, p as push } from './index3-gzEcGBsg.js';
import { r as requireLogin } from './Store-CQgMLh7S.js';

async function load({ parent }) {
  const parentData = await parent();
  const { session } = parentData;
  requireLogin(session);
  return parentData;
}
function ProfileLayout($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!---->`;
  pop();
}

var _layout = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Bsi2WVVD.js')).default;
const universal_id = "src/routes/profile/+layout.js";
const imports = ["_app/immutable/nodes/2.DWlb-jjL.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/oGFaUyOy.js","_app/immutable/chunks/DOdLuxr8.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/BSzH7kjz.js"];
const stylesheets = [];
const fonts = [];

var _2 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _layout,
  universal_id: universal_id
});

export { ProfileLayout as P, _2 as _ };
//# sourceMappingURL=2-B8eOzECs.js.map
