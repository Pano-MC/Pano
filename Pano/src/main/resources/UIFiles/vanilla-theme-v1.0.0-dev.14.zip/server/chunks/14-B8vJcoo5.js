import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { c as getPostPreview, P as Post } from './posts2-aMR0jB6E.js';

async function load(event) {
  const { parent } = event;
  const parentData = await parent();
  const { session } = parentData;
  const { user } = session;
  if (!user && !user.panelAccess) {
    return { status: 302, redirect: "/" };
  }
  let data = {
    post: {
      id: -1,
      title: "",
      category: "-",
      writer: { username: "" },
      text: "",
      date: 0,
      status: 1,
      image: "",
      views: 0
    },
    previousPost: "-",
    nextPost: "-"
  };
  await getPostPreview({ id: event.params.id, request: event }).then((body) => {
    if (body.error) {
      data = {};
      return;
    }
    data.post = body;
  });
  return data;
}
function PreviewPost($$payload, $$props) {
  push();
  var $$store_subs;
  let post = $$props["post"];
  $$payload.out += `<h5 class="card-title mb-3">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.preview-post.title", { values: { postTitle: post.title } }))}</h5> `;
  Post($$payload, { post, detail: true });
  $$payload.out += `<!---->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { post });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 14;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BLtF1_KH.js')).default;
const universal_id = "src/routes/preview/post/[id]/+page.js";
const imports = ["_app/immutable/nodes/14.DyZVQVQw.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/B_7vgiKG.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/nu-QtGX9.js","_app/immutable/chunks/Bez2mVAd.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/Dwqoi2xD.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js"];
const stylesheets = [];
const fonts = [];

var _14 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { PreviewPost as P, _14 as _ };
//# sourceMappingURL=14-B8vJcoo5.js.map
