import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { T as TicketCreate } from './21-CiR-TjkD.js';
import './client-Udtyxk2s.js';
import './TicketStatus-CZtEhgsZ.js';
import './api.util-BOgD0MTi.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './ErrorAlert-DtsYo9BM.js';
import './attributes-D1BeYJpW.js';
import './TicketCreateAndDetailSidebar-DvLpd4Hc.js';
import './Sidebar-D2M2HNzk.js';
import './OnlineAdmins-D61cmj5k.js';
import './index2-DzcLzHBX.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  TicketCreate($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cr8hZLdd.js.map
