import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { D as Date_1 } from './Date-B9_gBZcf.js';
import { l as load$1, P as ProfileSidebar } from './ProfileSidebar-BeQAKqS7.js';
import { a as getProfile } from './profile2-TejH8w_X.js';

async function load(event) {
  const { parent } = event;
  await parent();
  let data = { registerDate: 0, lastLoginDate: 0 };
  await load$1(event);
  await getProfile({ request: event }).then((body) => {
    data = body;
  });
  return { ...data, sidebar: ProfileSidebar };
}
function Profile($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  $$payload.out += `<div class="card bg-white"><div class="card-body"><h5 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.title"))}</h5> <table class="table mb-0"><tbody><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.register-date"))}</td><td>`;
  Date_1($$payload, { time: data.registerDate });
  $$payload.out += `<!----></td></tr><tr><td>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.profile.last-login"))}</td><td>`;
  Date_1($$payload, {
    time: data.lastLoginDate,
    relativeFormat: "true"
  });
  $$payload.out += `<!----></td></tr></tbody></table></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DjNi-HAC.js')).default;
const universal_id = "src/routes/profile/+page.js";
const imports = ["_app/immutable/nodes/15.D0w9O4Ia.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/BNonTKtc.js","_app/immutable/chunks/Bez2mVAd.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/oGFaUyOy.js","_app/immutable/chunks/DOdLuxr8.js","_app/immutable/chunks/BSzH7kjz.js","_app/immutable/chunks/Cx0aR08B.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/Bh6hwqBo.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/Dwpz6Acz.js","_app/immutable/chunks/Dwqoi2xD.js"];
const stylesheets = [];
const fonts = [];

var _15 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { Profile as P, _15 as _ };
//# sourceMappingURL=15-m_AK8oFr.js.map
