import { b as ApiUtil } from './api.util-BOgD0MTi.js';
import { p as push, ac as fallback, a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';

const getTickets = async ({ page, pageType, request, csrfToken }) => {
  return ApiUtil.get({
    path: `/api/tickets?page=${page}&pageType=${pageType}`,
    request,
    csrfToken
  }).then((body) => {
    body.page = parseInt(page);
    body.pageType = pageType;
    return body;
  });
};
const getCategoryTickets = async ({ page, url, request, csrfToken }) => {
  return ApiUtil.get({
    path: `/api/tickets?page=${page}&categoryUrl=${url}`,
    request,
    csrfToken
  }).then((body) => {
    body.page = parseInt(page);
    body.url = url;
    return body;
  });
};
const getTicketCategories = async ({ page, request, csrfToken }) => {
  return ApiUtil.get({
    path: `/api/ticket/categories?page=${page}`,
    request,
    csrfToken
  }).then((body) => {
    body.page = parseInt(page);
    return body;
  });
};
const getTicketDetail = async ({ id, request, csrfToken }) => {
  return ApiUtil.get({
    path: `/api/tickets/${id}`,
    request,
    csrfToken
  });
};
const TicketStatuses = Object.freeze({
  NEW: "NEW",
  REPLIED: "REPLIED",
  CLOSED: "CLOSED"
});
function TicketStatus($$payload, $$props) {
  push();
  var $$store_subs;
  let status = fallback($$props["status"], () => TicketStatuses.NEW, true);
  if (status === TicketStatuses.NEW) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="badge text-bg-success rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.new"))}</span>`;
  } else {
    $$payload.out += "<!--[!-->";
    if (status === TicketStatuses.REPLIED) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<span class="badge text-bg-warning rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.replied"))}</span>`;
    } else {
      $$payload.out += "<!--[!-->";
      if (status === TicketStatuses.CLOSED) {
        $$payload.out += "<!--[-->";
        $$payload.out += `<span class="badge text-bg-danger rounded-pill">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("ticket-statuses.closed"))}</span>`;
      } else {
        $$payload.out += "<!--[!-->";
      }
      $$payload.out += `<!--]-->`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]-->`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { status });
  pop();
}

export { TicketStatuses as T, TicketStatus as a, getTicketCategories as b, getCategoryTickets as c, getTickets as d, getTicketDetail as g };
//# sourceMappingURL=TicketStatus-CZtEhgsZ.js.map
