import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { e as escape_html } from './runtime-GPrrNsXa.js';

function SuccessAlert($$payload, $$props) {
  let message = $$props["message"];
  const alwaysVisible = false;
  if (message || alwaysVisible) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="alert alert-primary">${escape_html(message)}</div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { message });
}

export { SuccessAlert as S };
//# sourceMappingURL=SuccessAlert-eJ6hQXAr.js.map
