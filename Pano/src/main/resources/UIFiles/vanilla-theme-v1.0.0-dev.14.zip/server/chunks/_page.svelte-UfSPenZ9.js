import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { S as Support } from './19-zksAld6L.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Sidebar-D2M2HNzk.js';
import './attributes-D1BeYJpW.js';
import './OnlineAdmins-D61cmj5k.js';
import './client-Udtyxk2s.js';
import './api.util-BOgD0MTi.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Support($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-UfSPenZ9.js.map
