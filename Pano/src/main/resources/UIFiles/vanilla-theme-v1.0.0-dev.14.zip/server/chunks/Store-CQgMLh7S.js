import { $ as writable } from './index3-gzEcGBsg.js';
import './client-Udtyxk2s.js';
import { r as redirect } from './index2-DzcLzHBX.js';

const notificationsCount = writable(0);
const quickNotifications = writable([]);
function requireLogin(session) {
  if (!session.user) {
    throw redirect(302, "/");
  }
}
function requireNotLogin(session) {
  if (session.user) {
    throw redirect(302, "/");
  }
}

export { requireNotLogin as a, notificationsCount as n, quickNotifications as q, requireLogin as r };
//# sourceMappingURL=Store-CQgMLh7S.js.map
