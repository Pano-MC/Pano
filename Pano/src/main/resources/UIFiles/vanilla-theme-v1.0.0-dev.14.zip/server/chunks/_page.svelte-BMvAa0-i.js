import { a3 as bind_props } from './index3-gzEcGBsg.js';
import { N as Notifications } from './12-Ba-Xg8fp.js';
import './index-server-DfkY9wgZ.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './language.util-CMeRRGJY.js';
import './client-Udtyxk2s.js';
import './attributes-D1BeYJpW.js';
import './NoContent-y_d6Pngq.js';
import './api.util-BOgD0MTi.js';
import './Store-CQgMLh7S.js';
import './index2-DzcLzHBX.js';
import './formatDistanceToNow-BsAfm890.js';

function _page($$payload, $$props) {
  let data = $$props["data"];
  Notifications($$payload, { data });
  bind_props($$props, { data });
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BMvAa0-i.js.map
