import { a5 as store_get, a6 as unsubscribe_stores, a3 as bind_props, t as pop, p as push, a8 as stringify } from './index3-gzEcGBsg.js';
import { e as escape_html, $ as $format } from './runtime-GPrrNsXa.js';
import { a as attr } from './attributes-D1BeYJpW.js';
import './client-Udtyxk2s.js';
import { E as ErrorAlert } from './ErrorAlert-DtsYo9BM.js';
import { S as SuccessAlert } from './SuccessAlert-eJ6hQXAr.js';

async function load({ parent, url: { searchParams } }) {
  await parent();
  const token = searchParams.get("token") || "";
  return { token };
}
function ActivateNewEmail($$payload, $$props) {
  push();
  var $$store_subs;
  let data = $$props["data"];
  let error;
  let successMessage = null;
  $$payload.out += `<div class="col-lg-4 col-md-6 m-auto"><div class="card bg-white"><div class="card-body"><h3 class="card-title">${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.title"))}</h3> <img alt="Allay" src="https://cdn3.emoji.gg/emojis/8182-allay-dancing.gif"> `;
  ErrorAlert($$payload, { error });
  $$payload.out += `<!----> `;
  SuccessAlert($$payload, { message: successMessage });
  $$payload.out += `<!----> <button${attr("class", `btn btn-secondary w-100 ${stringify([
    ""
  ].filter(Boolean).join(" "))}`)}>${escape_html(store_get($$store_subs ??= {}, "$_", $format)("pages.activate-new-email.activate-button"))}</button></div></div></div>`;
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CCzAAdes.js')).default;
const universal_id = "src/routes/activate-new-email/+page.js";
const imports = ["_app/immutable/nodes/7.Hw8OmyKL.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/DOdLuxr8.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/l_VtGx06.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/BH_3Aa21.js"];
const stylesheets = [];
const fonts = [];

var _7 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  stylesheets: stylesheets,
  universal: _page,
  universal_id: universal_id
});

export { ActivateNewEmail as A, _7 as _ };
//# sourceMappingURL=7-CEhNbZDn.js.map
