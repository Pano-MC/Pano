import { a4 as slot } from './index3-gzEcGBsg.js';
import { T as TicketsLayout } from './TicketsLayout-DmrrfneJ.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './client-Udtyxk2s.js';
import './ErrorAlert-DtsYo9BM.js';
import './attributes-D1BeYJpW.js';
import './Store-CQgMLh7S.js';
import './index2-DzcLzHBX.js';

function _layout($$payload, $$props) {
  TicketsLayout($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-BXDlGRQd.js.map
