import { l as load } from './CategoryPosts-CNR3ALMg.js';
import './index3-gzEcGBsg.js';
import './client-Udtyxk2s.js';
import './Pagination-C1SaWYaW.js';
import './attributes-D1BeYJpW.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './Posts-B0qfOo5E.js';
import './posts2-aMR0jB6E.js';
import './Date-B9_gBZcf.js';
import './language.util-CMeRRGJY.js';
import './html-FW6Ia4bL.js';
import './api.util-BOgD0MTi.js';
import './NoContent-y_d6Pngq.js';
import './index2-DzcLzHBX.js';

var _page = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DLtxRZhZ.js')).default;
const universal_id = "src/routes/blog/category/[url]/+page.js";
const imports = ["_app/immutable/nodes/8.CpAbt3xs.js","_app/immutable/chunks/D_3FCkt2.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/DatJMj3j.js","_app/immutable/chunks/B9EpXuFF.js","_app/immutable/chunks/B_7vgiKG.js","_app/immutable/chunks/Ck3vzfQ7.js","_app/immutable/chunks/nu-QtGX9.js","_app/immutable/chunks/Bez2mVAd.js","_app/immutable/chunks/CExfb1J_.js","_app/immutable/chunks/vhDyJcp-.js","_app/immutable/chunks/ZN-_CbYj.js","_app/immutable/chunks/Dwqoi2xD.js","_app/immutable/chunks/bw36lVAs.js","_app/immutable/chunks/C16x2OpF.js","_app/immutable/chunks/BElaa30_.js","_app/immutable/chunks/BSzH7kjz.js","_app/immutable/chunks/CvYw2efT.js","_app/immutable/chunks/CZY_utnm.js","_app/immutable/chunks/bYCF1mlx.js","_app/immutable/chunks/C4XiSRIL.js","_app/immutable/chunks/Diiev6gu.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets, _page as universal, universal_id };
//# sourceMappingURL=8-DSrjuB8m.js.map
