const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./_error.svelte-BzUWUPkH.js')).default;
const imports = ["_app/immutable/nodes/1.DOktveXW.js","_app/immutable/chunks/5D_58W0O.js","_app/immutable/chunks/BfZtg_Vf.js","_app/immutable/chunks/BH0FS2mV.js","_app/immutable/chunks/Do1PMRWI.js","_app/immutable/chunks/EXTPc5pE.js","_app/immutable/chunks/ZN-_CbYj.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DfnJhtJX.js.map
