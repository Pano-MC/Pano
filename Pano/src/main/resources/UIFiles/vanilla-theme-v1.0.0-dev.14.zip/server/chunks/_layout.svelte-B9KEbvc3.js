import { a3 as bind_props, a4 as slot } from './index3-gzEcGBsg.js';
import { M as MainLayout } from './0-DZcvfrHi.js';
import './index-server-DfkY9wgZ.js';
import './stores-D5elBKmu.js';
import './client-Udtyxk2s.js';
import './runtime-GPrrNsXa.js';
import './_commonjsHelpers-B85MJLTf.js';
import './attributes-D1BeYJpW.js';
import './api.util-BOgD0MTi.js';
import './Store-CQgMLh7S.js';
import './index2-DzcLzHBX.js';
import './NoContent-y_d6Pngq.js';
import './language.util-CMeRRGJY.js';
import './html-FW6Ia4bL.js';
import './ErrorAlert-DtsYo9BM.js';
import './SuccessAlert-eJ6hQXAr.js';
import 'fs';
import './paths-DEXY_3zL.js';
import './formatDistanceToNow-BsAfm890.js';

function _layout($$payload, $$props) {
  let data = $$props["data"];
  MainLayout($$payload, {
    data,
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      slot($$payload2, $$props, "default", {}, null);
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { data });
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-B9KEbvc3.js.map
